$secpasswd = ConvertTo-SecureString "" -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential ("TeamsAutomation@samarbete.onmicrosoft.com", $secpasswd)
Connect-MsolService -Credential $mycreds;

$ITUsers = Get-ADUser -Filter "Office -eq 'ROS'" -Properties * -SearchBase "OU=Users,OU=ROS,OU=Top,DC=kommun,DC=skovde,DC=se"
$HasLicens = @()
$HasNoLicens = @()
$firstObject = New-Object PSObject
Add-Member -InputObject $firstObject -MemberType NoteProperty -Name Mail -Value ""
foreach ($User in $ITUsers) {
    $mail = $user.mail
    $UPN = $user.UserPrincipalName
    $Userlic = Get-MsolUser -UserPrincipalName $UPN
    $Licens = $Userlic.IsLicensed
    $Mailonprem = $user.HomeMDB
    if ($Licens -eq "TRUE" -and $Mailonprem) {
        $firstObject = $mail
        $HasLicens += $firstObject
    }
    Else {
        $firstObject = $mail
        $HasNoLicens += $firstObject
    }
}
Write-Host "$HasLicens" -ForegroundColor Green
Write-Host "$HasNoLicens" -ForegroundColor Yellow

$haslicens | Out-File -FilePath "C:\Temp\ROS\haslicens.csv"
$hasnolicens | Out-File -FilePath "C:\Temp\ROS\hasnolicens.csv"
