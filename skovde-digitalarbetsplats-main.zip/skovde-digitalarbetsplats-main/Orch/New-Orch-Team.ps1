# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
    
# RemoveSpecialCharacters
function RemoveSpecialCharacters ([string] $string) {
    $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
    $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
    $string = $string -replace "[àáåäâã]", "a"
    $string = $string -replace "[óòôöõ]", "o"
    $string = $string -replace "[éèëê]", "e"
    $string = $string -replace "[üûúù]", "u"
    $string = $string -replace "[íìîï]", "i"
    $string = $string -replace "ñ", "n"
    $string
}

# Log function
$LogDate = Get-Date -format yyyy-MM-dd
$LogFile = "C:\Logs\NewTeam\$LogDate-NewTeam.log"
function WriteLog {
    Param ([string]$LogString)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $LogMessage = "$Stamp $LogString"
    Add-content $LogFile -value $LogMessage
}
    
# SP variables
$Kund = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{D71617FA-573F-4DE5-B792-39CCFBF99829}\`d.T.~Ed/"
$Office = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.Office\`d.T.~Ed/"
$UPNN = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.UPN\`d.T.~Ed/"
$SR = "\`d.T.~Ed/{B7E7D93B-983E-4C79-86E2-B2D561AD8A91}.Id\`d.T.~Ed/"
$TeamName = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{84CAF08C-D52B-4162-8169-AB3323ACBA48}\`d.T.~Ed/"
$EDU = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{21564C05-C2B2-4811-9BCA-9D81EE5BDF5C}\`d.T.~Ed/"

# Manual variables for testning
# $TeamName = "TEST0111"
# $Kund = "Skövde Energi"
# $Office = "SEAB"
# $UPNN = "adam.nilsson@skovde.se"
# $EDU = "TRUE"
# $SR = "Manual"

$Date = Get-Date -Format FileDate
# Fix company
switch ($Kund) {
    "Skövde" {
        $Company = "SK"
        $Bolag = $false
    }
    "Tibro Kommun" {
        $Company = "TI"
        $Bolag = $false
    }
    "Hjo Kommun" {
        $Company = "HJ"
        $Bolag = $false
    }
    "Karlsborgs Kommun" {
        $Company = "KBG"
        $Bolag = $false
    }
    "Karlsborg Kommun" {
        $Company = "KBG"
        $Bolag = $false
    }
    "Skövde Energi" {
        $Company = "SEAB"
        $Bolag = $true
    }
    "Räddningstjänsten Östra Skaraborg" {
        $Company = "RS"
        $Bolag = $true
    }
    "Avfall & Återvinning Skaraborg" {
        $Company = "AAS"
        $Bolag = $true
    }
    "Balthazar" {
        $Company = "BALT"
        $Bolag = $true
    }
    "Skaraborgs Kommunalförbund" {
        $Company = "KOMF"
        $Bolag = $true
    }
    "Miljösamverkan Östra Skaraborg" {
        $Company = "MOS"
        $Bolag = $true
    }
}

# Fix Office prefix
switch ($Office) {
    "Kommunledningsförvaltningen" {
        $Office = "KLF"
    }
    "Socialförvaltningen" {
        $Office = "SOF"
    }
} 

# Fix Bolag prefix
If ($Bolag -eq $true) {
    $TeamFullName = 'TM-' + $Company + '-' + $TeamName + $Date
    $TeamNOSpace = $TeamFullName.replace(' ', '')
    $TeamAlias = RemoveSpecialCharacters($TeamNOSpace)
} 
if ($Bolag -eq $false) {
    $TeamFullName = 'TM-' + $Company + '-' + $Office + '-' + $TeamName + $Date
    $TeamNOSpace = $TeamFullName.replace(' ', '')
    $TeamAlias = RemoveSpecialCharacters($TeamNOSpace)
}

$ErrorMessage = $null
$status = $null
# Run on Management server
$return = Invoke-Command -ComputerName "srv-mgmt20.kommun.skovde.se" -Credential $creds -ScriptBlock {
    param($TeamAlias, $TeamName, $UPNN, $EDU)

    Import-Module MicrosoftTeams
    #Nedan används AES-nyckel och Krypterad lösenords-fil - Mer osäkert så se till att ha korrekt ACL-regler på filerna 
    $User = "TeamsAutomation@samarbete.onmicrosoft.com"
    $PasswordFile = "C:\credentials\TeamsAutomation-Samarbete-AESPass.txt"
    $KeyFile = "C:\credentials\TeamsAutomation-Samarbete-AESkey.txt"
    $key = Get-Content $KeyFile
    $MyCredential = New-Object -TypeName System.Management.Automation.PSCredential `
        -ArgumentList $User, (Get-Content $PasswordFile | ConvertTo-SecureString -Key $key)
    Connect-MicrosoftTeams -Credential $MyCredential

    try {       
        if ($EDU -eq "TRUE") {
            $Team = New-Team -MailNickName "$TeamAlias" -Displayname "$TeamName" -Description "$TeamName" -Template "EDU_Class" -Owner $UPNN -ErrorAction Stop | Out-Null
            Start-Sleep 30
            $Status = "Success"
        }
        else {
            $Team = New-Team -MailNickName "$TeamAlias" -Displayname "$TeamName" -Visibility "Private" -Description "$TeamName" -Owner $UPNN -ErrorAction Stop | Out-Null
            Start-Sleep 30
            $Status = "Success"
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        $Status = "Failed"
    }
    finally {
        $return = @($Status, $ErrorMessage, $Team)
        $return
    }
} -ArgumentList ($TeamAlias, $TeamName, $UPNN, $EDU)

$Status = $return.Get(1)
$ErrorMessage = $return.Get(2)
$Team = $return.Get(0)

# Write log file
if ($status -eq "Failed") {
    WriteLog "$SR FAILED: New Team $TeamAlias by $UPNN ErrorMessage: $ErrorMessage"
    $Status = "Failed"
}
else {
    WriteLog "$SR SUCCESS: New Team $TeamAlias by $UPNN"
    $Status = "Success"
}