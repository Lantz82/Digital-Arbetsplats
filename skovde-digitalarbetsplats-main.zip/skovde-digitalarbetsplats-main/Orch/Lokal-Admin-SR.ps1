Import-Module ActiveDirectory
# $User = Get-aduser -id test-adni0303 -prop *
switch ($User.Company) {
    "Avfall & Återvinning Skaraborg" { $SRGroup = "User-Lokal-Admin-AAS-SR" }
    "Balthazar" { $SRGroup = "User-Lokal-Admin-BALT-SR" }
    "Hjo Kommun" { $SRGroup = "User-Lokal-Admin-HJO-SR" }
    "Karlsborgs Kommun" { $SRGroup = "User-Lokal-Admin-KBG-SR" }
    "Skaraborgs Kommunalförbund" { $SRGroup = "User-Lokal-Admin-KOMF-SR" }
    "Skövde Energi" { $SRGroup = "User-Lokal-Admin-SEAB-SR" }
    "Miljösamverkan Östra Skaraborg" { $SRGroup = "User-Lokal-Admin-MOS-SR" }
    "Räddningstjänsten Skaraborg" { $SRGroup = "User-Lokal-Admin-RTJS-SR" }
    Default { $SRGroup = "User-LokalAdminSR" }
}
if ($User.Company -eq "Skövde") {
    switch ($User.Office) {
        "SSV" { $SRGroup = "User-Lokal-Admin-SSV-SR" }
        "SMS" { $SRGroup = "User-Lokal-Admin-SMS-SR" }
        "SSB" { $SRGroup = "User-Lokal-Admin-SSB-SR" }
        "SBU" { $SRGroup = "User-Lokal-Admin-SBU-SR" }
        "SVO" { $SRGroup = "User-Lokal-Admin-SVO-SR" }
        "SSO" { $SRGroup = "User-Lokal-Admin-SSO-SR" }
        "SSE" { $SRGroup = "User-Lokal-Admin-SSE-SR" }
        Default { $SRGroup = "User-LokalAdminSR" }
    }
}
Add-ADGroupMember -Identity $SRGroup \`d.T.~Ed/ -Members { 2BA86EDE-5C05-40D6-91F3-B5D49BA67CC6 }.UserName\`d.T.~Ed/
Add-ADGroupMember -Identity $SRGroup -Members $User