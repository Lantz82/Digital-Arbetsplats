Import-Module adlib
Import-Module ActiveDirectory
Import-Module Tools

$Fornamn = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{56F1875C-DE6A-4DA8-B5B6-8801D9E52EE4}\`d.T.~Ed/"
$Efternamn = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{0B105705-7E8F-493A-82FC-11A6BD1AA960}\`d.T.~Ed/"
$Pnum = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{F31051CC-BA88-44BC-A436-FA27175E93DF}\`d.T.~Ed/"
$Epost = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{946F1C99-9133-406C-A100-F23F2FF330C6}\`d.T.~Ed/"
$Telefon = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{5C238DE2-539F-4000-B62A-D340EABFE7CF}\`d.T.~Ed/"
$Foretag = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{B6C3C98B-D683-4507-8368-81DBCC251FA0}\`d.T.~Ed/"
$Password = "\`d.T.~Ed/{B40F0249-1ABC-4A4F-9251-B84E68DCA335}.stringResult\`d.T.~Ed/"
$Server = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{D2017E2E-C87D-4065-AA6A-ED76EF2073D7}\`d.T.~Ed/"
$RDP = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{FEDDD4F5-0AAB-410D-8FA4-DDB49586DA08}\`d.T.~Ed/"
$Konsol = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{F8E1100A-1F25-4F80-BCEE-182D2596BC86}\`d.T.~Ed/"

function UtilFilterSwedish ([string] $string) {

    $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
    $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
    $string = $string -replace "[àáåäâã]", "a"
    $string = $string -replace "[óòôöõ]", "o"
    $string = $string -replace "[éèëê]", "e"
    $string = $string -replace "[üûúù]", "u"
    $string = $string -replace "[íìîï]", "i"
    $string = $string -replace "ñ", "n"

    $string
}

function ADLibCreateExternalPartner ([string] $UserID, [string] $FNamn, [string] $ENamn, [string] $Phone, [string] $Epost, [string] $Foretag, [string] $InitialPwd) {
    new-aduser -name $UserID -Path "OU=Users,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -accountPassword (ConvertTo-SecureString -AsPlainText $InitialPwd -Force) -OtherAttributes @{
        'userPrincipalName'          = $UserID + "@kommun.skovde.se";
        'name'                       = $UserID;
        'displayName'                = $("$FNamn $ENamn").Trim();
        'givenName'                  = $FNamn;
        'sn'                         = $ENamn;
        'PhysicalDeliveryOfficeName' = "$Foretag";
        'department'                 = "Konsult";
        'Description'                = "$FNamn $ENamn på $Foretag - konsult";
        'homeDirectory'              = "\\kommun.skovde.se\dfs\Hemmakatalog\$UserID";
        'homeDrive'                  = "O:";
        'extensionAttribute1'        = "Konsult";
        'mobile'                     = $Phone;
        'mail'                       = $Epost
    }

    Set-ADAccountControl $userid -PasswordNeverExpires $true -CannotChangePassword $true -Enabled $true #=='userAccountControl'=544
}

<#
function Create-Home ([string] $UserID, [switch] $Change) {

    $user = $UserID
    $is_personnel = ($user.extensionAttribute1 -eq "Personnel" -or $user.extensionAttribute1 -eq "Emp" -or $user.extensionAttribute1 -eq "konsult");
    $homeDirectory = "\\kommun.skovde.se\dfs\Hemmakatalog\$UserID";

    # Vi försöker läsa in information om vilken hemmakatalog användaren skall ha via homeDirectory attributet.
    if ($user.homeDirectory -eq $null -or $Change) {
        # Kolla först om det är en student eller personal.
        if (-not $is_personnel) {
            # Studerande. Då sätter vi homepath till fs02
            $homeDirectory = "\\kommun.skovde.se\dfs\Hemmakatalog\$UserID";
        }
    }
    else {
        $homeDirectory = $user.homeDirectory.ToString();
    }

    # If the directory doesn't exist, create it..
    if (-not $(Test-Path $homeDirectory)) { [void] (New-Item -type Directory -Path $homeDirectory); }

    # Set rättigheter
    [void](Set-Owner -userid $user.name);
    $user;
}
#>

$UserID = UtilFilterSwedish -string ("EXT-" + ($Fornamn.Substring(0, 2) + $Efternamn.Substring(0, 2) + $Pnum))
ADLibCreateExternalPartner $UserID $Fornamn $Efternamn $Telefon $Epost $Foretag $Password;

Start-Sleep 45

Add-ADGroupMember -Identity User-EXT-Konsulter -Members $UserID
Add-ADGroupMember -Identity User-MFA-Users -Members $UserID
# Create-Home $UserID


