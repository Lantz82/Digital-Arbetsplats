# $secPasswordServiceAccount = ConvertTo-SecureString "" -AsPlainText -Force
# $serviceAccount = "SKOVDE\SRVC-ORCH-Service"
# $creds = New-Object System.Management.Automation.PSCredential($serviceAccount, $secPasswordServiceAccount) 
# $computer = "srv-mgmt20.kommun.skovde.se"
# $session = New-PSSession -Credential $creds -ComputerName $computer

# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$return = Invoke-Command -Session $session -ScriptBlock {

    $DistlistName = "\`d.T.~Ed/{11EE290E-64A9-46C4-BB99-901B5ED1CB24}.{661F9592-08E7-4024-ABDC-B42C0263C062}\`d.T.~Ed/"
    $Owner = "\`d.T.~Ed/{11A0541D-AB45-49DA-B6E6-7C0D89F03405}.UPN\`d.T.~Ed/"
    $UserCompany = "\`d.T.~Ed/{11A0541D-AB45-49DA-B6E6-7C0D89F03405}.Company\`d.T.~Ed/"
    $Office = "\`d.T.~Ed/{11A0541D-AB45-49DA-B6E6-7C0D89F03405}.Office\`d.T.~Ed/"

    Set-ExecutionPolicy Unrestricted

    if ($DistlistName -match '^[A-Z0-9_\-.]+@[A-Z0-9.-]+$') {
        $DistlistName = $DistlistName.split('@')[0]
    }

    # Start-Transcript -Path "C:\Temp\NewKBGDL.txt"

    $Owner | Out-File -FilePath "C:\Temp\variabel.txt"

    function Remove-DiacriticsAndSpaces {
        Param(
            [String]$inputString
        )
        #replace diacritics
        $sb = [Text.Encoding]::ASCII.GetString([Text.Encoding]::GetEncoding("Cyrillic").GetBytes($inputString))

    
        #remove spaces and anything the above function may have missed
        
        $sb = $sb -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $sb = $sb -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $sb = $sb -replace "[àáåäâã]", "a"
        $sb = $sb -replace "[óòôöõ]", "o"
        $sb = $sb -replace "[éèëê]", "e"
        $sb = $sb -replace "[üûúù]", "u"
        $sb = $sb -replace "[íìîï]", "i"
        $sb = $sb -replace "ñ", "n"
        $sb = $sb -replace ' ', '-'
        $sb = $sb -replace ',', '-'
                
        return $sb  

    }

    function Connect-Exo {
        #Nedan är om vi använder Credfil utan nyckel, kräver isf att 
        #$User = "srvc-exchange@karlsborgskommun.onmicrosoft.com"
        #$PasswordFile = "C:\Credentials\srvc-exchange-karlsborg.txt"
        #$Pass = Get-content $PasswordFile | ConvertTo-SecureString
        #$MyCredential = New-Object -Typename System.Management.Automation.PsCredential ($User, $Pass)    
        
        #Nedan används AES-nyckel och Krypterad lösenords-fil - Mer osäkert så se till att ha korrekt ACL-regler på filerna 
        $User = "TeamsAutomation@samarbete.onmicrosoft.com"
        $PasswordFile = "C:\credentials\TeamsAutomation-Samarbete-AESPass.txt"
        $KeyFile = "C:\credentials\TeamsAutomation-Samarbete-AESkey.txt"
        $key = Get-Content $KeyFile
        $MyCredential = New-Object -TypeName System.Management.Automation.PSCredential `
            -ArgumentList $User, (Get-Content $PasswordFile | ConvertTo-SecureString -Key $key)

        $SessionOption = New-PSSessionOption -Culture "en-US"

        Connect-ExchangeOnline -credential $MyCredential -PSSessionOption $SessionOption
    }

    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewDistList\$LogDate-NewDistList.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }

    $CleanDistListName = Remove-DiacriticsAndSpaces $DistListName

    # Karlsborg fix
    if ($UserCompany -eq "Karlsborgs Kommun") {
        $UserCompany = "Karlsborg Kommun"
    }

    If ($Office -eq "Kommunledningsförvaltningen") {
        $Office = "KLF"
    }
    If ($Office -eq "Socialförvaltningen") {
        $Office = "SOF"
    }

    switch ($UserCompany) {
        'Skövde' { $Name = "DL-SK-$Office-$CleanDistListName"; $Email = $Name + "@skovde.se" }
        'Hjo Kommun' { $Name = "DL-HJ-$Office-$CleanDistListName"; $Email = $Name + "@hjo.se" }
        'Tibro Kommun' { $Name = "DL-TI-$Office-$CleanDistListName"; $Email = $Name + "@tibro.se" }
        'Skövde Energi' { $Name = "DL-SEAB-$CleanDistListName"; $Email = $Name + "@skovdeenergi.se" }
        'Skaraborgs Kommunalförbund' { $Name = "DL-KOMF-$CleanDistListName"; $Email = $Name + "@skaraborg.se" }
        'Miljösamverkan Östra Skaraborg' { $Name = "DL-MOS-$CleanDistListName"; $Email = $Name + "@miljoskaraborg.se" }
        'Avfall & Återvinning Skaraborg' { $Name = "DL-AAS-$CleanDistListName"; $Email = $Name + "@avfallskaraborg.se" }
        'Räddningstjänsten Skaraborg' { $Name = "DL-RS-$CleanDistListName"; $Email = $Name + "@rtjskaraborg.se" }
        'Balthazar' { $Name = "DL-BALTHAZAR-$CleanDistListName"; $Email = $Name + "@skovde.se" }
        'Karlsborg Kommun' { $Name = "DL-KBG-$CleanDistListName"; $Email = $Name + "@karlsborg.se" }
    }

    Connect-Exo

    New-DistributionGroup -Name $Name -DisplayName $Name -PrimarySmtpAddress $Email -ManagedBy $Owner
    WriteLog "New Distlist name: $Name by user: $Owner"
    Return $Name
}
$Name = $Return
