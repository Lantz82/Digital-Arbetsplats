# $secPasswordServiceAccount = ConvertTo-SecureString "" -AsPlainText -Force
# $serviceAccount = "SKOVDE\SRVC-ORCH-Service"
# $creds = New-Object System.Management.Automation.PSCredential($serviceAccount, $secPasswordServiceAccount) 
# $computer = "srv-mgmt20.kommun.skovde.se"
# $session = New-PSSession -Credential $creds -ComputerName $computer

# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$Return = Invoke-Command -Session $session -ScriptBlock {

    import-module activedirectory
    Set-Executionpolicy Unrestricted

    $SharedMailboxName = "\`d.T.~Ed/{5B373839-584E-4636-8830-AE25A0456EF5}.{0C092CCC-E113-4A49-A4EF-CE8B69CDC4E1}\`d.T.~Ed/"
    $UserCompany = "\`d.T.~Ed/{482BE13B-479E-4AD3-9A71-192A539C2F28}.Company\`d.T.~Ed/"
    $UsersFullAccess = "\`d.T.~Ed/{577C4590-9420-4968-A52D-AE614C7741EA}.noarrayusers\`d.T.~Ed/"
    $Office = "\`d.T.~Ed/{482BE13B-479E-4AD3-9A71-192A539C2F28}.Office\`d.T.~Ed/"

    $UsersFullAccess = $UsersFullAccess.split(",")

    if ($SharedMailboxName -match '^[A-Z0-9_\-.]+@[A-Z0-9.-]+$') {
        $SharedMailboxName = $SharedMailboxName.split('@')[0]
    }

    Set-ExecutionPolicy Unrestricted

    # Start-Transcript -Path "C:\Temp\NewResourceScript.txt"

    function Remove-DiacriticsAndSpaces {
        Param(
            [String]$inputString
        )
        #replace diacritics
        $sb = [Text.Encoding]::ASCII.GetString([Text.Encoding]::GetEncoding("Cyrillic").GetBytes($inputString))

    
        #remove spaces and anything the above function may have missed
        
        $sb = $sb -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $sb = $sb -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $sb = $sb -replace "[àáåäâã]", "a"
        $sb = $sb -replace "[óòôöõ]", "o"
        $sb = $sb -replace "[éèëê]", "e"
        $sb = $sb -replace "[üûúù]", "u"
        $sb = $sb -replace "[íìîï]", "i"
        $sb = $sb -replace "ñ", "n"
        $sb = $sb -replace ' ', '-'
        $sb = $sb -replace ',', '-'
                
        return $sb  

    }

    function Connect-Exo {
        #Nedan är om vi använder Credfil utan nyckel, kräver isf att 
        #$User = "srvc-exchange@karlsborgskommun.onmicrosoft.com"
        #$PasswordFile = "C:\Credentials\srvc-exchange-karlsborg.txt"
        #$Pass = Get-content $PasswordFile | ConvertTo-SecureString
        #$MyCredential = New-Object -Typename System.Management.Automation.PsCredential ($User, $Pass)    
        
        #Nedan används AES-nyckel och Krypterad lösenords-fil - Mer osäkert så se till att ha korrekt ACL-regler på filerna 
        $User = "TeamsAutomation@samarbete.onmicrosoft.com"
        $PasswordFile = "C:\credentials\TeamsAutomation-Samarbete-AESPass.txt"
        $KeyFile = "C:\credentials\TeamsAutomation-Samarbete-AESkey.txt"
        $key = Get-Content $KeyFile
        $MyCredential = New-Object -TypeName System.Management.Automation.PSCredential `
            -ArgumentList $User, (Get-Content $PasswordFile | ConvertTo-SecureString -Key $key)

        $SessionOption = New-PSSessionOption -Culture "en-US"

        Connect-ExchangeOnline -credential $MyCredential -PSSessionOption $SessionOption 
    }

    # Log Function
    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewSharedMailbox\$LogDate-NewSharedMailbox.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }

    $CleanMailBoxName = Remove-DiacriticsAndSpaces $SharedmailboxName
    
    # KBG FIX
    if ($UserCompany -eq "Karlsborgs Kommun") {
        $UserCompany = "Karlsborg Kommun"
    }

    If ($Office -eq "Kommunledningsförvaltningen") {
        $Office = "KLF"
    }
    If ($Office -eq "Socialförvaltningen") {
        $Office = "SOF"
    }

    switch ($UserCompany) {
        'Skövde' { $Name = "FN-SK-$Office-$CleanMailBoxName"; $Email = $Name + "@skovde.se" }
        'Hjo Kommun' { $Name = "FN-HJ-$Office-$CleanMailBoxName"; $Email = $Name + "@hjo.se" }
        'Tibro Kommun' { $Name = "FN-TI-$Office-$CleanMailBoxName"; $Email = $Name + "@tibro.se" }
        'Skövde Energi' { $Name = "FN-SEAB-$CleanMailBoxName"; $Email = $Name + "@skovdeenergi.se" }
        'Skaraborgs Kommunalförbund' { $Name = "FN-KOMF-$CleanMailBoxName"; $Email = $Name + "@skaraborg.se" }
        'Miljösamverkan Östra Skaraborg' { $Name = "FN-MOS-$CleanMailBoxName"; $Email = $Name + "@miljoskaraborg.se" }
        'Avfall & Återvinning Skaraborg' { $Name = "FN-AAS-$CleanMailBoxName"; $Email = $Name + "@avfallskaraborg.se" }
        'Räddningstjänsten Östra Skaraborg' { $Name = "FN-RS-$CleanMailBoxName"; $Email = $Name + "@rtjskaraborg.se" }
        'Balthazar' { $Name = "FN-BALTHAZAR-$CleanMailBoxName"; $Email = $Name + "@skovde.se" }
        'Karlsborg Kommun' { $Name = "FN-KBG-$CleanMailBoxName"; $Email = $Name + "@karlsborg.se" }
    }

    Connect-Exo
    New-Mailbox -Name $Name -Alias $Name -PrimarySmtpAddress $Email -Shared

    foreach ($UserFull in $UsersFullAccess) {

        Add-MailboxPermission $Email -User $Userfull -AccessRights FullAccess -InheritanceType all
        Add-RecipientPermission $Email -Trustee $Userfull -AccessRights SendAs -confirm:$False

    }
    WriteLog "New Sharemailbox name: $Name by users: $UsersFullAccess"
    Return $Name
}

$Name = $Return