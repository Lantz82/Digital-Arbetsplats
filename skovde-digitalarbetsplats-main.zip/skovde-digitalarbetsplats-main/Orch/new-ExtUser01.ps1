Import-Module adlib
Import-Module ActiveDirectory
Import-Module Tools

$Fornamn = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{56F1875C-DE6A-4DA8-B5B6-8801D9E52EE4}\`d.T.~Ed/"
$Efternamn = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{0B105705-7E8F-493A-82FC-11A6BD1AA960}\`d.T.~Ed/"
$Pnum = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{F31051CC-BA88-44BC-A436-FA27175E93DF}\`d.T.~Ed/"
$Epost = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{946F1C99-9133-406C-A100-F23F2FF330C6}\`d.T.~Ed/"
$Telefon = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{5C238DE2-539F-4000-B62A-D340EABFE7CF}\`d.T.~Ed/"
$Foretag = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{B6C3C98B-D683-4507-8368-81DBCC251FA0}\`d.T.~Ed/"
$Password = "\`d.T.~Ed/{B40F0249-1ABC-4A4F-9251-B84E68DCA335}.stringResult\`d.T.~Ed/"
$Server = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{D2017E2E-C87D-4065-AA6A-ED76EF2073D7}\`d.T.~Ed/"
$RDP = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{FEDDD4F5-0AAB-410D-8FA4-DDB49586DA08}\`d.T.~Ed/"
$Konsol = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{F8E1100A-1F25-4F80-BCEE-182D2596BC86}\`d.T.~Ed/"

function UtilFilterSwedish ([string] $string) {
    $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
    $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
    $string = $string -replace "[àáåäâã]", "a"
    $string = $string -replace "[óòôöõ]", "o"
    $string = $string -replace "[éèëê]", "e"
    $string = $string -replace "[üûúù]", "u"
    $string = $string -replace "[íìîï]", "i"
    $string = $string -replace "ñ", "n"
    $string
}

function ADLibCreateExternalPartner ([string] $UserID, [string] $FNamn, [string] $ENamn, [string] $Phone, [string] $Epost, [string] $Foretag, [string] $InitialPwd) {
    new-aduser -name $UserID -Path "OU=Users,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -accountPassword (ConvertTo-SecureString -AsPlainText $InitialPwd -Force) -OtherAttributes @{
        'userPrincipalName'          = $UserID + "@kommun.skovde.se";
        'name'                       = $UserID;
        'displayName'                = $("$FNamn $ENamn").Trim();
        'givenName'                  = $FNamn;
        'sn'                         = $ENamn;
        'PhysicalDeliveryOfficeName' = "$Foretag";
        'department'                 = "Konsult";
        'Description'                = "$FNamn $ENamn på $Foretag - konsult";
        'homeDirectory'              = "\\kommun.skovde.se\dfs\Hemmakatalog\$UserID";
        'homeDrive'                  = "O:";
        'extensionAttribute1'        = "Konsult";
        'mobile'                     = $Phone;
        'mail'                       = $Epost
    }

    Set-ADAccountControl $userid -PasswordNeverExpires $true -CannotChangePassword $true -Enabled $true #=='userAccountControl'=544
}
$UserID = UtilFilterSwedish -string ("EXT-" + ($Fornamn.Substring(0, 2) + $Efternamn.Substring(0, 2) + $Pnum))
ADLibCreateExternalPartner $UserID $Fornamn $Efternamn $Telefon $Epost $Foretag $Password;
Start-Sleep 45
Add-ADGroupMember -Identity User-EXT-Konsulter -Members $UserID
Add-ADGroupMember -Identity User-MFA-Users -Members $UserID

# Part 2
If ($RDP -eq "TRUE") {
    Add-ADGroupMember -Identity User-RDS-RDP-$server -Members $UserID
}

If ($Konsol -eq "TRUE") { 
    Add-ADGroupMember -Identity User-RDS-RC-$server -Members $UserID
}

If ($Server -eq "Raindance") {
    Add-ADGroupMember User-EXT-CGI-Support $UserID
}
Else {

}

# Part 3

$Server = "\`d.T.~Ed/{9ABC31A0-8A44-4BD9-903C-0E00CB3F492F}.Servernamn\`d.T.~Ed/"
$connBroker = "srv-rdw01.kommun.skovde.se"
$RDSCollection = "Skövde Extern Åtkomst 02"

if ($RDP -eq "TRUE") {
    $ADGroup = "User-RDS-RDP-$Server"

    $appsett = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "RDS-template" -ConnectionBroker $connBroker
    try {
        $CheckGroup = Get-ADGroup -Identity $ADGroup 
    }
    catch {}

    if (!$CheckGroup) {
        New-ADGroup -Path "OU=Groups,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -Name "User-RDS-RDP-$server" -GroupScope Global
    }
    Add-ADGroupMember -Identity Srv-RDS-RemotedServers -Members $ADGroup
    Add-ADGroupMember -Identity User-RDS-SkovdeExternÅtkomst -Members $ADGroup
    Start-Sleep -Seconds 60
    try {
        $CheckRDSApp = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "RDP till $Server" -ConnectionBroker $connBroker
    }
    catch {}

    if (!$CheckRDSApp) {
        New-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "RDP till $Server" -FilePath $appsett.FilePath -FolderName $appsett.FolderName -CommandLineSetting Require -RequiredCommandLine "/v:$server" -UserGroups "User-RDS-RDP-$server" -ConnectionBroker $connBroker
        Start-Sleep -Seconds 60
    }
    ([ADSI]"WinNT://$server/Administrators,group").Add("WinNT://kommun.skovde.se/User-RDS-RDP-$($server)")
    Add-ADGroupMember -Identity $ADGroup -Members $UserID
}

if ($Konsol -eq "TRUE") {
    $ADGroup = "User-RDS-RC-$Server"
    $appsett = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "Console-template" -ConnectionBroker $connBroker
    try {
        $CheckGroup = Get-ADGroup -Identity $ADGroup 
    }
    catch {}
    
    if (!$CheckGroup) {
        New-ADGroup -Path "OU=Groups,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -Name $ADGroup -GroupScope Global
    }
    Add-ADGroupMember -Identity Srv-RDS-RemotedServers -Members $ADGroup
    Add-ADGroupMember -Identity User-RDS-SkovdeExternÅtkomst -Members $ADGroup
    Start-Sleep -Seconds 60
    try {
        $CheckRDSApp = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "Konsoll till $Server" -ConnectionBroker $connBroker
    }
    catch {}
    
    if (!$CheckRDSApp) {
        New-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "Konsoll till $Server" -FilePath $appsett.FilePath -FolderName $appsett.FolderName -CommandLineSetting Require -RequiredCommandLine "/v:$server" -UserGroups "User-RDS-RDP-$server" -ConnectionBroker $connBroker
        Start-Sleep -Seconds 60
    }
    ([ADSI]"WinNT://$server/Administrators,group").Add("WinNT://kommun.skovde.se/User-RDS-RDP-$($server)")
    Add-ADGroupMember -Identity $ADGroup -Members $UserID
}
