# $secPasswordServiceAccount = ConvertTo-SecureString "" -AsPlainText -Force
# $serviceAccount = "SKOVDE\SRVC-ORCH-Service"
# $creds = New-Object System.Management.Automation.PSCredential($serviceAccount, $secPasswordServiceAccount) 
# $computer = "srv-mgmt20.kommun.skovde.se"
# $session = New-PSSession -Credential $creds -ComputerName $computer

# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$Return = Invoke-Command -Session $session -ScriptBlock {

    $ResourceName = "\`d.T.~Ed/{2C04A461-955E-4832-B0CD-0AF41847A538}.{56E112D4-DD40-4D72-8D39-887E62F4D832}\`d.T.~Ed/"
    $Type = "\`d.T.~Ed/{2C04A461-955E-4832-B0CD-0AF41847A538}.{11008823-DEF4-4460-9262-8FD5FB187B1F}\`d.T.~Ed/"
    $UserCompany = "\`d.T.~Ed/{09D9227C-2806-4937-B973-D0C7142B6531}.Company\`d.T.~Ed/"
    $Office = "\`d.T.~Ed/{09D9227C-2806-4937-B973-D0C7142B6531}.Office\`d.T.~Ed/"

# Manual params
# $ResourceName = "kbg-testar"
# $Type = "eq"
# $UserCompany = "karlsborgs kommun"
# $Office = "Kommunledningsförvaltningen"

    Set-ExecutionPolicy Unrestricted

    if ($ResourceName -match '^[A-Z0-9_\-.]+@[A-Z0-9.-]+$') {
        $ResourceName = $ResourceName.split('@')[0]
    }

    function Remove-DiacriticsAndSpaces {
        Param(
            [String]$inputString
        )
        #replace diacritics
        $sb = [Text.Encoding]::ASCII.GetString([Text.Encoding]::GetEncoding("Cyrillic").GetBytes($inputString))

    
        #remove spaces and anything the above function may have missed
        
        $sb = $sb -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $sb = $sb -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $sb = $sb -replace "[àáåäâã]", "a"
        $sb = $sb -replace "[óòôöõ]", "o"
        $sb = $sb -replace "[éèëê]", "e"
        $sb = $sb -replace "[üûúù]", "u"
        $sb = $sb -replace "[íìîï]", "i"
        $sb = $sb -replace "ñ", "n"
        $sb = $sb -replace ' ', '-'
        $sb = $sb -replace ',', '-'
                
        return $sb   

    }

    function Connect-Exo {
        #Nedan är om vi använder Credfil utan nyckel, kräver isf att 
        #$User = "srvc-exchange@karlsborgskommun.onmicrosoft.com"
        #$PasswordFile = "C:\Credentials\srvc-exchange-karlsborg.txt"
        #$Pass = Get-content $PasswordFile | ConvertTo-SecureString
        #$MyCredential = New-Object -Typename System.Management.Automation.PsCredential ($User, $Pass)    
        
        #Nedan används AES-nyckel och Krypterad lösenords-fil - Mer osäkert så se till att ha korrekt ACL-regler på filerna 
        $User = "TeamsAutomation@samarbete.onmicrosoft.com"
        $PasswordFile = "C:\credentials\TeamsAutomation-Samarbete-AESPass.txt"
        $KeyFile = "C:\credentials\TeamsAutomation-Samarbete-AESkey.txt"
        $key = Get-Content $KeyFile
        $MyCredential = New-Object -TypeName System.Management.Automation.PSCredential `
            -ArgumentList $User, (Get-Content $PasswordFile | ConvertTo-SecureString -Key $key)

        $SessionOption = New-PSSessionOption -Culture "en-US"

        Connect-ExchangeOnline -credential $MyCredential -PSSessionOption $SessionOption 
    }

    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewEXOResurs\$LogDate-NewEXOResurs.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }

    $ResourceName = $ResourceName.ToUpper()
    $CleanResourceName = Remove-DiacriticsAndSpaces $ResourceName

    # Karlsborg fix
    if ($UserCompany -eq "Karlsborgs Kommun") {
        $UserCompany = "Karlsborg Kommun"
    }

    If ($Office -eq "Kommunledningsförvaltningen") {
        $Office = "KLF"
    }
    If ($Office -eq "Socialförvaltningen") {
        $Office = "SOF"
    }

    switch ($UserCompany) {
        'Skövde' { $Name = "RS-SK-$Office-$Type-$CleanResourceName"; $Email = $Name + "@skovde.se" }
        'Hjo Kommun' { $Name = "RS-HJ-$Office-$Type-$CleanResourceName"; $Email = $Name + "@hjo.se" }
        'Tibro Kommun' { $Name = "RS-TI-$Office-$Type-$CleanResourceName"; $Email = $Name + "@tibro.se" }
        'Skövde Energi' { $Name = "RS-SEAB-$Type-$CleanResourceName"; $Email = $Name + "@skovdeenergi.se" }
        'Skaraborgs Kommunalförbund' { $Name = "RS-KOMF-$Type-$CleanResourceName"; $Email = $Name + "@skaraborg.se" }
        'Miljösamverkan Östra Skaraborg' { $Name = "RS-MOS-$Type-$CleanResourceName"; $Email = $Name + "@miljoskaraborg.se" }
        'Avfall & Återvinning Skaraborg' { $Name = "RS-AAS-$Type-$CleanResourceName"; $Email = $Name + "@avfallskaraborg.se" }
        'Räddningstjänsten Skaraborg' { $Name = "RS-RS-$Type-$CleanResourceName"; $Email = $Name + "@rtjskaraborg.se" }
        'Balthazar' { $Name = "RS-BALTHAZAR-$Type-$CleanResourceName"; $Email = $Name + "@skovde.se" }
        'Karlsborg Kommun' { $Name = "RS-KBG-$Type-$CleanResourceName"; $Email = $Name + "@karlsborg.se" }
    }

    Connect-Exo

    if ($Type -match "Rum") {
        New-Mailbox -Room -Name $Name  -DisplayName $Name -Alias $Name -FirstName $Name -LastName "" -Initial "" -PrimarySmtpAddress $Email
    }

    else {
        New-Mailbox -Equipment -Name $Name -DisplayName $Name -Alias $Name -FirstName $Name -LastName "" -Initial "" -PrimarySmtpAddress $Email
    }

    Start-Sleep 15

    $Calendar = "$($Name):\Calendar"

    Start-Sleep 30

    if (Get-Mailbox -Identity $Name) {
        Set-MailboxFolderPermission -Identity $Calendar -AccessRights Reviewer -User "Default"
        Set-MailboxFolderPermission -identity $Calendar -AccessRights Reviewer -User "Anonymous"
        Set-CalendarProcessing -Identity $Name -AutomateProcessing 'AutoAccept' -ForwardRequestsToDelegates $false -BookingWindowInDays '400' -MaximumDurationInMinutes '2880' -AllBookInPolicy $true
    }
    WriteLog "New EXO Resurs name: $name"
    Return $Name

}

$Name = $Return