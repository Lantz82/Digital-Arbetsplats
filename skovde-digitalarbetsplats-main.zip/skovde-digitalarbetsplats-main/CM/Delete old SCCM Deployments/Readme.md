This PowerShell script deletes old SCCM Deployments.

The script will prompt the user to enter the desired date and the script will list all deployment older than the specified date.

The user will be prompt before each deployment deletion before going to the next one.

The script support deletion of the following deployment type :

Applications
Packages
Task Sequence
Configuration Baseline
Software Update
Use this script if you are using SCCM for a couple of years and have completed / old deployments that are still active.

Info or questions: www.systemcenterdudes.com
