This PowerShell script will copy SCCM User/Device Collection Membership to another SCCM User/Device

This can be useful in a PC replace scenario or then a new employee comes in and needs to be member of the same collection as another employee (Ex: software installation assignment)

Before running the script, enter the right Server name, site code and domain name.

The script will prompt for confirmation before adding the Device/User in each collection.

Question or comments : www.systemcenterdudes.com
