Import-Module -Name ActiveDirectory
# Import-Module -Name ImportExcel
# Simple send mail function from Onprem-Exchange
function Send-Mail {
    param (
        [Parameter(Mandatory)]
        [string] $Body,
        
        [Parameter(Mandatory)]
        [string] $Subject,
        
        [Parameter(Mandatory)]
        [string] $Recipient,
        
        [Parameter(Mandatory)]
        [string] $From,
        
        [string] $CC,
        
        [string] $File
    )
    
    $options = @{
        SmtpServer  = "smtp.skovde.se"
        To          = $Recipient
        From        = $From
        Subject     = $Subject
        Body        = $Body
        Encoding    = [System.Text.Encoding]::UTF8
    }
    if ($CC) {
        $options.CC = $CC
    }
    if ($File) {
        $options.Attachments = $File
    }
    
    Send-MailMessage @options
}
# Formaterar / städar .csv från CM
function Get-PC-Lista {
    $files = Get-childitem -Path "\\srv-sc-orch02\Reports\CMReports\Raw\"
    foreach ($file in $files) {
        $csv = Get-Content -Path "\\srv-sc-orch02\Reports\CMReports\Raw\$file" | Select-Object -Skip 3 | ConvertFrom-Csv
        $lista = @()
        $lista = foreach ($user in $csv) {
            $Split = $User.Details_Table0_TopConsoleUser.split('\')
            $Domain = $Split[0]
            $ADuser = $Split[1]
            If ($ADuser -eq "local_users") {
                # Local account
                $Displayname = "Datorkonto"
                $Userprincipalname = "Datorkonto"
                $Userprincipalname = "Datorkonto"
                $Office = "Datorkonto"
                $Company = "Datorkonto"
            }
            elseIf ($Domain -eq "Unknown") {
                # Unknown account
                $Displayname = "Saknas"
                $Userprincipalname = "Saknas"
                $Userprincipalname = "Saknas"
                $Office = "Saknas"
                $Company = "Saknas"
            }
            else {
                $ADU = Get-aduser -Identity $ADuser -Properties Office, Company, DisplayName, Userprincipalname
                if ($ADU) {
                    $Displayname = $ADU.DisplayName
                    $Userprincipalname = $ADU.UserPrincipalName
                    $Office = $ADU.Office
                    $Company = $ADU.Company
                }
                else {
                    $Displayname = "Saknas"
                    $Userprincipalname = "Saknas"
                    $Userprincipalname = "Saknas"
                    $Office = "Saknas"
                    $Company = "Saknas"
                }
            }
            [PSCustomObject]@{
                Datornamn = $User.Details_Table0_ComputerName
                Modell    = $User.Details_Table0_Model
                Användare = $DisplayName
                UPN       = $Userprincipalname
                Sektor    = $Office
                Kund      = $Company
            }
        }
        $Date = Get-date -Format yyyy-MM-dd
        $OutFile = $File.Name
        $lista  | Export-Csv -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-$OutFile" -Encoding UTF8 -NoTypeInformation
        $lista  | Export-Csv -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-Alla.csv" -Encoding UTF8 -NoTypeInformation -Append
        # $lista  | Export-Excel -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-$OutFile"
        # $lista  | Export-Excel -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-Alla.xlsx" -Append -AutoSize -TableName Dator
    }
}

function Remove-Old-Lista {
    # Remove old reports
    Get-ChildItem -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\" -Recurse | Where-Object { ($_.LastWriteTime -lt (Get-Date).AddDays(-60)) } | Remove-Item
}
function Fix-All-Lista {
    $Date = Get-date -Format yyyy-MM-dd
    $CSVin = Import-CSV "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-Alla.csv" | Sort-Object "Datornamn" -Unique
    $CSVin | Export-Csv -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-Alla.csv" -Encoding UTF8 -NoTypeInformation
}
Remove-Old-Lista
Get-PC-Lista
Fix-All-Lista
$Date = Get-date -Format yyyy-MM-dd
# Send-Mail -Body "Här kommer månadens datorrapport" -Subject "Datorrapport" -Recipient "Johan.Videll@skovde.se" -CC "Adam.Nilsson@skovde.se" -From "rapport@skovde.se" -File "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-Alla.csv"

