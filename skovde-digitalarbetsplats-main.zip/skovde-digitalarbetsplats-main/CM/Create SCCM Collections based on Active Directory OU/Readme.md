The script will :

List all Organisational Unit (OU)
Prompt the Administrator to select the topmost OU where they want to start creating
Prompt the Administrator for a folder name
The script will create the folder in SCCM
The script will create 1 collection per OU from the start OU and will create 1 collection for all OU under the start OU. See the example below if it's unclear.
The script will move collection in the specified folder

For more information about this script, refer to my blog post on www.systemcenterdudes.com
