$server = "SRV-MAP-INT02"
$Application = Get-WmiObject -Namespace "root\ccm\clientSDK" -Class CCM_SoftwareUpdate -ComputerName $server
Invoke-WmiMethod -Namespace "root\ccm\clientsdk" -Class CCM_SoftwareUpdatesManager -Name InstallUpdates -ArgumentList (,$Application)



Function Get-FileName($InitialDirectory) {
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

 

  $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
  $OpenFileDialog.initialDirectory = $initialDirectory
  $OpenFileDialog.filter = "CSV (*.csv) | *.csv"
  $OpenFileDialog.ShowDialog() | Out-Null
  $OpenFileDialog.filename
}

 

$File = Get-FileName
$Allcomputers = Import-Csv -Path $File

$Computers = $Allcomputers.Details_Table0_ComputerName0


foreach ($Computer in $Computers) {
$Application = Get-WmiObject -Namespace "root\ccm\clientSDK" -Class CCM_SoftwareUpdate -ComputerName $Computer
Invoke-WmiMethod -Namespace "root\ccm\clientsdk" -Class CCM_SoftwareUpdatesManager -Name InstallUpdates -ArgumentList (,$Application) -ComputerName $Computer
}