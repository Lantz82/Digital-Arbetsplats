This script will detect and delete SCCM Collections that have no members and no deployment assigned to it.

This can be useful to delete unused/unneeded collections.

The script will detect the targeted collections
The script will prompt the user for a confirmation before each deletion
The script will not delete collections which have custom security scope

More information: https://www.systemcenterdudes.com/sccm-script-delete-collection/
