function ConnectSCCM {
    # Site configuration
    $SiteCode = "P02" # Site code 
    $ProviderMachineName = "srv-sc-cm02.kommun.skovde.se" # SMS Provider machine name

    # Customizations
    $initParams = @{}
    #$initParams.Add("Verbose", $true) # Uncomment this line to enable verbose logging
    #$initParams.Add("ErrorAction", "Stop") # Uncomment this line to stop the script on any errors

    # Do not change anything below this line

    # Import the ConfigurationManager.psd1 module 
    if ((Get-Module ConfigurationManager) -eq $null) {
        Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" @initParams 
    }

    # Connect to the site's drive if it is not already present
    if ((Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue) -eq $null) {
        New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $ProviderMachineName @initParams
    }

    # Set the current location to be the site code.
    Set-Location "$($SiteCode):\" @initParams
}

$computers = Import-Csv -Path "C:\Users\jqpublic\computers.csv"

foreach ( $computer in $computers ) {
    $uda = Get-CMUserDeviceAffinity -DeviceName $computer.Name
  
    if ( ($uda.UniqueUserName).count -gt 1 ) {
        foreach ( $user in $uda.UniqueUserName ) {
            Write-Host $uda.ResourceName[1] $user
        }
    }
    else {
        write-host $uda.ResourceName $uda.UniqueUserName
    }
}


$win10 = ""

$collMem = Get-CMCollectionMember -CollectionId P0201077 | Select-Object Name, LastLogonUser, DeviceOSBuild
$collMem | ConvertTo-Csv -NoTypeInformation | Out-File -FilePath "C:\temp\210310_SSB_pre_1909.csv" -Append


$Admembers = Get-adgroupmember -Identity "Org-SSB" -Recursive -prop * | select 


$GrpMembers = Get-ADGroupMember -id "Org-SSB" -Recursive | Select-Object -ExpandProperty SamAccountName

$GrpMembers = Import-Csv C:\temp\WH-SBU01.csv

foreach ($member in $GrpMembers) {
    $user = $member.name
    $device = Get-CMUserDeviceAffinity -UserName SKOVDE\$user | Select-Object -ExpandProperty ResourceName
    $device | out-file -Path C:\temp\WH-SBUComp01.csv -Append
}


Set-Location "$($SiteCode):"

$GrpMembers = Get-ADGroupMember $SourceGroup | Select-Object -ExpandProperty SamAccountName
ForEach ($Member in $GrpMembers) {
    Write-Host "$($Member):"
    Get-CMUserDeviceAffinity -UserName "$($SourceDomain)\$($Member)" | Select-Object -ExpandProperty ResourceName
}