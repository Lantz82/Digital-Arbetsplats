param(
    [Parameter(Mandatory=$true,Position=1)]
    # [ValidateSet("User", "Computer")]
    [String]$CMCollectionName

    # [Parameter(Mandatory=$true,Position=2)]
    # [string]$CMCollectionName
    ) #end param

#  = "P0201374" #replace with the CollectionID that you want to generate the report for
[String]$SiteCode = "P02" #This is the site code for the SCCM
# [String]$path= "C:\Temp\$CMCollectionName.txt" #Location where you want to drop the file.
$delimiter = ','

Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1"

Set-Location "$SiteCode`:"
$Kunder = get-content c:\temp\kunder.txt
foreach ($kund in $kunder) {
    $CMCollection = Get-CMCollection -Name $kund
    $Members = Get-CMCollectionMember -CollectionId $CMCollection.CollectionID  | Select-Object Name,LastLogonUser,PrimaryUser
    $Members | Export-Csv -Path C:\temp\"$kund".csv -NoTypeInformation 
}
$CMCollection = Get-CMCollection -Name $CMCollectionName
$Members = Get-CMCollectionMember -CollectionId $CMCollection.CollectionID  | Select-Object Name,LastLogonUser,PrimaryUser

# $Servers | ConvertTo-Csv -Delimiter $delimiter -NoTypeInformation | out-file $Outfile -encoding ascii
$Members #| Out-File $path -Force | notepad $path
cd C:


