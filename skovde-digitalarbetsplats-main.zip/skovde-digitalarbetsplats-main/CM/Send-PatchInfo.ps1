# Skickar ut information 7 dagar innan månadspatch
$SendinfoDay = Get-content "C:\Logs\ServerPatch\SendInfoDay.txt"
$Today = Get-Date -Format "yyyy-MM-dd"

if ($Today -eq $SendinfoDay) {
    $dateFormat = "yyyy-MM-dd"
    $DateAdd = (Get-Date).AddDays(+1)
    $date = Get-Date -Date $DateAdd -Format $dateFormat

    $body = "Hej, nästa tillfälle för systemunderhåll i Skövde kommuns IT-miljö är den $date 18:00 - 02:00.
Systemunderhållet kan innebära begränsad funktionalitet och eventuellt kortare avbrott i Skövde kommuns IT-tjänster.  

Ta gärna kontakt med Servicedesk IT om du har några frågor.
0500-49 85 01"

    $To = "service@zafe.se", "peter.legendi@tibro.se", "elisabeth.funck@grastorp.se", "sandra.peters@karlsborg.se", "Peter.Jonsson@hjo.se", "Theres.Ahlberg@skovde.se", "tefdriftinfo.fastigheter@skovde.se", "par.bladh@skovde.se", "info@skovdeenergi.se", "Raindance-support@skovde.se"
    # $To = "adam.nilsson@skovde.se"
    $CC = "adam.nilsson@skovde.se", "peter.lantz@skovde.se", "marcus.setterstrom@skovde.se"
    $options = @{
        'SmtpServer' = "smtp.skovde.se" 
        'To'         = $To
        'CC'         = $CC
        'From'       = "Servicedesk-IT@skovde.se"
        'Subject'    = "Systemunderhåll i Skövde kommuns IT-miljö $date" 
        'Body'       = "$body"
    }

    Send-MailMessage @options -Encoding UTF8
}
else {
    Exit
}