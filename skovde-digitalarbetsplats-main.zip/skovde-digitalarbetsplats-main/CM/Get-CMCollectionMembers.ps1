param(
    [Parameter(Mandatory = $true, Position = 1)]
    # [ValidateSet("User", "Computer")]
    [String]$CMCollectionName

    # [Parameter(Mandatory=$true,Position=2)]
    # [string]$CMCollectionName
) #end param

[String]$SiteCode = "P02" #This is the site code for the SCCM
Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1"
Set-Location "$SiteCode`:"
$CMCollection = Get-CMCollection -Name $CMCollectionName
$Members = Get-CMCollectionMember -CollectionId $CMCollection.CollectionID  | Select-Object Name
$Members
Set-Location C: