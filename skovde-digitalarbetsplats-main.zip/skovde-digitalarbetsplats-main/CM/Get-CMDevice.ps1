function Get-CMDevicesToCSV {
    param(
        [Parameter(Mandatory=$true)]
        [string]$OutputPath
    )
    
    # Import the Configuration Manager PowerShell module
    # Import-Module "$($SiteServer)\AdminUI\bin\ConfigurationManager.psd1"
    Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1"
    Set-Location "P02`:"
    
    # Connect to the Configuration Manager site

    # $Site = Get-CMSite -SiteCode $SiteCode -Server $SiteServer
    
    # Get all devices from the site
    $Devices = Get-CMDevice 
    
    # Export the devices to a CSV file
    $Devices | Export-Csv -Path $OutputPath -NoTypeInformation
}

Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1"
Get-CMDevicesToCSV -SiteServer "CM01" -SiteCode "PS02" -OutputPath "C:\temp\Devices.csv"

Get-CMDevicesToCSV -SiteServer "srv-sc-cm02.kommun.skovde.se" -SiteCode "P02" -OutputPath "C:\temp\Devices.csv"

$SiteServer = "srv-sc-cm02.kommun.skovde.se"
$SiteCode = "P02"
$OutputPath = "C:\temp\Devices.csv"

$Members = Get-CMCollectionMember -CollectionId "P0201189"  | Select-Object Name,PrimaryUser,LastLogonUser,LastActiveTime,DeviceOS,DeviceOSBuild
$members | Export-Csv -Path C:\temp\Comp-SEAB.csv -NoTypeInformation

Export-CMCollection -Name "Comp-SEAB" -ExportFilePath "C:\temp\comp-SEAB.csv"

$CMDevices = Get-CMDevice -CollectionName "comp-seab" | Select-Object Name,PrimaryUser,LastLogonUser,LastActiveTime,DeviceOS,DeviceOSBuild 
# | Export-Csv -Path "$PSSCriptroot\CMDevices.csv" -NoTypeInformation -Encoding Unicode
