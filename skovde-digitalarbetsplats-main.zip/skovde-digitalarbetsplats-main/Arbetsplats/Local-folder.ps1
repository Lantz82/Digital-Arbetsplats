Import-Module ActiveDirectory

$path = "\\share-secure\secure\"
$user = "\`d.T.~Ed/{3A619F3A-E8EC-408E-B3C5-D250D4676B76}.UserName\`d.T.~Ed/"
$fullPath = $path + $user

if (-not (Test-Path -LiteralPath $fullPath)) {

    try {
        New-Item -Path $fullPath -ItemType Directory 
    }

    catch {
        "Cannot create foler", "fullPath = $fullPath" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber 
        break
    }

    try {
        $acl = Get-Acl $fullPath
        $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("SKOVDE\$user", "Modify", "ContainerInherit,Objectinherit", "none", "Allow")
        $acl.SetAccessRule($accessRule)
        Set-Acl -Path $fullPath -Aclobject $acl
    }

    catch {
        "Cannot set ACL", "user= $user", "fullPath = $fullPath" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber
        break
    }

    try {
        Add-ADGroupMember -Identity User-Netshare-Secure -Members $user
    }

    catch {
        "Cannot add $user to group" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber
        break
    }

}
else {
    "Folder exists", "fullPath = $fullPath" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber 
}