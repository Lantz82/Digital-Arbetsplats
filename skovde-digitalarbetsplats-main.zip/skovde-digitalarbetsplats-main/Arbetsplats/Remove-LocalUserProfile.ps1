param(
    [Parameter(Mandatory = $true)]
    [string] $User,
    [Parameter(Mandatory = $true)]
    [string] $Computer
)

If ($user -eq "All") {   
    $Confirm = Read-Host "Do you want to remove all userprofiles on computer $computer ? [Y/N]"
    Switch ($Confirm) {
        Y {
            Write-Host -ForegroundColor Yellow "Removing all userprofile on hostname $computer ..."
            Get-WMIObject -ComputerName $Computer -class Win32_UserProfile | Where-Object { (!$_.Special) -and (!$_.Loaded) } | Remove-WmiObject -ErrorAction SilentlyContinue
        }
        N {
            Write-Host -ForegroundColor Yellow "Aborted by user"
            Exit
        }
    }
}
else {
    Write-Host -ForegroundColor Yellow "Removing userprofile $user on hostname $computer ..."
    Get-CimInstance -ComputerName $Computer -Class Win32_UserProfile | Where-Object { $_.LocalPath.split('\')[-1] -eq "$User" } | Remove-CimInstance -ErrorAction SilentlyContinue
}