Import-Module MicrosoftTeams
$cred = Get-Credential

$session = New-CsOnlineSession -Credential $cred -Verbose
Import-PSSession -Session $session -AllowClobber
$UserToMove = Get-ADGroupMember "ORG-HJO-VOO-Resursochbistandsenhet" -Recursive | Where-Object objectClass -eq user
foreach ($User in $UserToMove) {
    $UserToAdd = Get-ADUser -Identity $User -Properties *
    $Username = $UserToAdd.SamAccountName
    Move-CsUser -Identity $Username -Target sipfed.online.lync.com -Credential $mycreds -Confirm:$False -force
    Write-Host "$Username Flyttad till Skype Online" -ForegroundColor Green
}

Move-CsUser -Identity $Username -Target sipfed.online.lync.com -Credential $mycreds -Confirm:$False -force
Write-Host "$Username Flyttad till Skype Online" -ForegroundColor Green