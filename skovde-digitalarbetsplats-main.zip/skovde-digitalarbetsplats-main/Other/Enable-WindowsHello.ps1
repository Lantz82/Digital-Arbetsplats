
function Enable-WindowsHelloUser {
    param(
        [Parameter(Mandatory = $true)]
        [string] $File
    )
    $File = Import-Csv -path $file
    foreach ($Member in $File) {
        # Beroende på hur filen med users ser ut
        # $US = Get-aduser -filter {UserPrincipalName -eq "$member.UserPrincipalName"}
        Add-ADGroupMember -Identity 'User-WindowsHello' -Members $member.name
        Write-Host Adding member $Member.PrimarySmtpAddress
    }
}


function Enable-WindowsHelloComputer {
    param(
        [Parameter(Mandatory = $true)]
        [string] $File
    )
    $File = get-content -Path $File
    foreach ($comp in $computers) {
        $Comp = Get-Adcomputer -id $comp
        Add-ADGroupMember -Identity 'Comp-WindowsHello' -Members $Comp
        Add-ADGroupMember -Identity 'Comp-DirectAccess-SITHS' -Members $Comp
        Remove-ADGroupMember -Identity 'Comp-DirectAccess' -Members $Comp -Confirm:$false
        Remove-ADGroupMember -Identity 'Comp-DirectAccess-Basic' -Members $Comp -Confirm:$false
        Write-Host $comp.name
    }
}