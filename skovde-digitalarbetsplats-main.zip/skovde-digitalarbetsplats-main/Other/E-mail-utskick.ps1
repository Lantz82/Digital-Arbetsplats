$body = "Hej!
Vi vill informera dig om en förändring som kommer att inträffa som en del av våra åtgärder för att höja IT-säkerheten.

Som en del av vårt ständiga arbete för att förbättra säkerheten kommer permanenta lokala administratörsbehörigheter att tas bort. Finns det fortsatt behov av administratörsbehörigheter kan du beställa detta via formuläret (Temporär lokal admin) på serviceportalen.

Tack för din förståelse och samarbete när vi strävar efter att förbättra vår IT-säkerhet.

Med vänliga hälsningar,
Servicedesk IT
0500-49 85 01"
$recipiens = @()
$recipiens = Get-content C:\temp\lokaladmins.txt
# $recipiens = Get-content C:\temp\new7.txt

foreach ($res in $recipiens) {
    $To = $res
    # $CC = ""
    $options = @{
        'SmtpServer' = "smtp.skovde.se" 
        'To'         = $To
        # 'CC'         = $CC
        'From'       = "Servicedesk-IT@skovde.se"
        'Subject'    = "Viktig Information angående Lokal Administratörsbehörighet" 
        'Body'       = "$body"
    }

    Send-MailMessage @options -Encoding UTF8
}
