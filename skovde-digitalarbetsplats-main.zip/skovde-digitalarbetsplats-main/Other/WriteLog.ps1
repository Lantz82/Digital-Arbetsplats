# Simple log function
# Example
# WriteLog "New log post"

$LogDate = Get-Date -format yyyy/MM/dd
$LogFile = "C:\Logs\$LogDate-LOGNAME.log"
function WriteLog {
    Param ([string]$LogString)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $LogMessage = "$Stamp $LogString"
    Add-content $LogFile -value $LogMessage
}