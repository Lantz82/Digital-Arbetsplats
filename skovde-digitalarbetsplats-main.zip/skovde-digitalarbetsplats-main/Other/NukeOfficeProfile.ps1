# NUKE EM
Get-Process -ProcessName EXCEL -ErrorAction SilentlyContinue | Stop-Process -Force 
Get-Process -ProcessName WINWORD -ErrorAction SilentlyContinue | Stop-Process -Force 
Get-Process -ProcessName POWERPNT -ErrorAction SilentlyContinue | Stop-Process -Force 
Get-Process -ProcessName ONENOTE -ErrorAction SilentlyContinue | Stop-Process -Force 
Get-Process -ProcessName MSACCESS -ErrorAction SilentlyContinue | Stop-Process -Force 
Get-Process -ProcessName MSPUB -ErrorAction SilentlyContinue | Stop-Process -Force
Get-Process -ProcessName Outlook -ErrorAction SilentlyContinue | Stop-Process -Force 
Get-Process -ProcessName OneDrive -ErrorAction SilentlyContinue | Stop-Process -Force
Get-Process -ProcessName Teams -ErrorAction SilentlyContinue | Stop-Process -Force 


# Nuke Outlook profile
Remove-Item -Path HKCU:\SOFTWARE\Microsoft\Office\16.0\Outlook\Profiles\* -Recurse

# Nuke Team cache
$path = $env:APPDATA + "\Microsoft\teams\"
Get-ChildItem -Path $path | Remove-Item -Confirm:$false -Recurse

# Nuke OneDrive
$path = $env:LOCALAPPDATA + "\Microsoft\IdentityCache" 
Get-ChildItem -Path $path | Remove-Item -Confirm:$false -Recurse
Remove-Item -Path HKCU:\Software\Microsoft\OneDrive\Accounts\ -Recurse

# Sign out Office

$OfficeCommon = Get-Item Registry::HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\Common
Write-Host "****** Clearing Registry Begin ******"
Write-Host "OfficeCommon Acquired"
Write-Host $OfficeCommon

#Get the Any  Identities of users.
#Iterate through each of the Identities under Common\Identity\Identities
#From each Identity, grab the ProviderID value, Put each into  the Identity Keys Value : SignedOutWAMUsers, seperate using semicolons
$IdentityKey = Get-Item Registry::$OfficeCommon\Identity

Write-Host "IdentityKey Acquired"
Write-Host $IdentityKey


$UserIdentityKeys = Get-ChildItem Registry::$IdentityKey\Identities 

if (!($UserIdentityKeys)) {
    Write-Host "It appears no users were logged in. Cannot Clear  Identity Registry";	
}
else {
    Write-Host "`n-- Identities -- `n" $UserIdentityKeys
    Write-Host "`n-- Listing Identities Provider IDs -- :"
    ##Iterates each Key under the Identity, and pulls the ProviderID which is an ID for each user logged in.
    $UserIdentityKeys | foreach {
        $CurrentProviderID = (Get-ItemProperty Registry::$_ -Name ProviderID).ProviderID
        Write-Host $CurrentProviderID
        if ([string]::IsNullOrWhiteSpace($SignedOutWAMUsers)) {
            $SignedOutWAMUsers = $CurrentProviderID
        }
        else {
            $SignedOutWAMUsers = $SignedOutWAMUsers + ";" + $CurrentProviderID
        }
        #Optionally, we can set a DWORD =1 for the value SignedOut on Identity SubKey
        #But they get removed next time you launch an Office program (the whole Subkey is removed)
    }
    Write-Host "-- End List --"
    Write-Host "`n-- Generated SignedOutWAMUsers --: "$SignedOutWAMUsers


    #Compare the WAM to whats in the IdentityKey
    $ExistingWAM = $IdentityKey.GetValue("SignedOutWAMUsers")
    if (!($ExistingWAM -eq $null)) {

        if (!($ExistingWAM)) {
            #With the above null check, being here means empty
            $NewWam = ($SignedOutWAMUsers)

        }
        else {
            $NewWam = (($ExistingWAM + ';' + $SignedOutWAMUsers) -split ';' | Select -Unique) -join ';'
        }
        Write-Host "-- Prior WAM Existed --:           "$ExistingWAM
        Write-Host "-- New WAM --:                     "$NewWam
        Write-Host "New WAM Created with Appended Generated SignedOutWAMUsers and Removed duplicates"
        Set-ItemProperty Registry::$IdentityKey -Name SignedOutWAMUsers -Value $NewWam
    }
    else {
        # there wasnt one here before, so we create a new registry value and put our SignedOutWAMUsers in it.
        New-ItemProperty Registry::$IdentityKey -Name SignedOutWAMUsers -Value $SignedOutWAMUsers
        Write-Host "No Prior WAM, Creating new Value From Generated SignOutWAMUsers"
    }
}

Write-Host "Removing Indentities Registry Key"
#Finally we delete the Identities SubKey (Even if they didnt exist), recurse means dont prompt user for permission
Remove-Item Registry::$IdentityKey\Identities -Recurse 
Remove-Item Registry::$IdentityKey\Profiles -Recurse 

#This one, I noticed starts to populate with URLS if you save to OneDrive
#It also creates keys when Outlook the app is logged into and you select "Remember My Credentials".
Remove-Item Registry::$IdentityKey\DocToIdMapping\* -Recurse 
Write-Host "Task Complete"


#Start Clearing out  remanants that the user was logged in before#
Write-Host "-- Clearing Cloud Policy --"
$CloudPolicy = Get-Item Registry::$OfficeCommon\CloudPolicy
Remove-Item Registry::$CloudPolicy\* -Recurse
Write-Host "-- Task Complete --"
Write-Host "-- Clearing Licensing --"
$LicensingNext = Get-Item Registry::$OfficeCommon\Licensing\LicensingNext
Remove-Item Registry::$LicensingNext\* -Exclude "CIDtoLicenseIdsMapping" -Recurse
Write-Host "-- Task Complete --"

Write-Host "-- Clearing OfficeStart Web Templates --"
$WebTemplates = Get-Item Registry::$OfficeCommon\OfficeStart\Web\Templates
Remove-Item Registry::$WebTemplates\* -Exclude "Anonymous" -Recurse
Write-Host "-- Task Complete --"

Write-Host "-- Clearing Privacy SettingsStore --"
$SettingsStore = Get-Item Registry::$OfficeCommon\Privacy\SettingsStore
Remove-Item Registry::$SettingsStore\* -Recurse
Write-Host "-- Task Complete --"

Write-Host "-- Clearing Roaming Identities --"
$RoamId = Get-Item Registry::$OfficeCommon\Roaming\Identities
Remove-Item Registry::$RoamId\* -Recurse
Write-Host "-- Task Complete --"

Write-Host "-- Clearing ServicesManagerCache Identities --"
$SerManCache = Get-Item Registry::$OfficeCommon\ServicesManagerCache
Remove-Item Registry::$SerManCache\Identities\* -Recurse
Remove-Item Registry::$SerManCache\OnPremises\* -Recurse
Write-Host "-- Task Complete --"

Write-Host "-- Clearing TargetMessaging --"
$TargetedMsgServ = Get-Item Registry::$OfficeCommon\TargetedMessagingService
Remove-Item Registry::$TargetedMsgServ\MessageData\* -Recurse
Remove-Item Registry::$TargetedMsgServ\MessageMetaData\* -Recurse
Write-Host "-- Task Complete --"

Write-Host "-- Clearing UrlReputation UserPolicies --"
$UrlRep = Get-Item Registry::$OfficeCommon\UrlReputation\UserPolicy
Remove-Item Registry::$UrlRep\* -Recurse
Write-Host "-- Task Complete --"


#There are Registry Keys inside Office\16.0 (above Common) for each individual Office software.
#The following is used to clear user data each of these may have stored of a previous user.
Write-Host "-- Clearing App Specific Keys  --"
$Apps = "Access;Excel;PowerPoint;Publisher;Word;OneNote"
$Apps -split ";" | foreach {
    Write-Host "-- -- Processing $_ -- --"
    $CurAppKey = Get-Item Registry::"HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\"$_
    $FMRU = Get-Item Registry::$CurAppKey\'File MRU'
    $UMRU = Get-Item Registry::$CurAppKey\'User MRU'
    $PMRU = Get-Item Registry::$CurAppKey\'Place MRU'
	
    Remove-ItemProperty Registry::$FMRU -Name *
    Remove-ItemProperty Registry::$PMRU -Name *
    Remove-Item Registry::$UMRU\* -Recurse

    if ($_ -eq "Word") {
        Remove-Item Registry::$CurAppKey\"Reading Locations"\* -Recurse
    }
    if ($_ -eq "OneNote") {
        Remove-Item Registry::$CurAppKey\"OpenNotebooks"\* -Recurse
        Remove-Item Registry::$CurAppKey\"RecentNotebooks"\* -Recurse
    }
}
Write-Host "-- Task Complete --"
Write-Host "****** Clearing Registry: Complete ******"

#Clear  Files Associated with Cached  User  data inside LocalAppData
Write-Host "`n`n****** Clearing LocalAppData ******"

$OfficeDataDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0"
Write-Host "Acquired Local App Data for Office"
Write-Host "        "$OfficeDataDir

#Most of these folders will be completely emptied, a few will have a single sub folder left behind.
$Folders = "aggmru;BackstageInAppNavCache;TapCache;MruServiceCache;Personalization\Content;Personalization\Governance"
$Folders -split ";" | foreach {
    Write-Host "-- Clearing $_ --"
    if ($_ -like "Personalization\*") {
        Remove-Item "$OfficeDataDir\$_\*" -Recurse -Exclude "Anonymous"
    }
    else {	
        Remove-Item "$OfficeDataDir\$_\*" -Recurse
    }
    Write-Host "-- Task Complete --`n"
}

Write-Host "****** Clearing LocalAppData : Complete ******"

if ($RmOneNoteFiles.IsPresent) {
    Write-Host "`n`n****** Deleting OneNote Local Folder ******"
    $ONRegKey = Get-Item Registry::"HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\OneNote\Options\Save"
    $ONFolder = (Get-ItemProperty Registry::$ONRegKey).'Last Local Notebook Path'
    Write-Host "       Deleting contents of: "$ONFolder
    ##From the path we got from the registry, delete the folder.
    Remove-Item $ONFolder\* -Recurse -Force
	
    Write-Host "****** Delete OneNote Folder -- Complete ******"
}


Write-Host "`n`n****** Clearing AppData Roaming ******"

Write-Host "-- Clearing Recent Folder --"
$OfficeDataDir = "$env:APPDATA\Microsoft\Office\Recent"
Remove-Item $OfficeDataDir\* -Recurse 
Write-Host "-- Task Complete --`n"

Write-Host "****** Clearing AppData Roaming : Complete ******"

Write-Host "`n`n****** Clearing Windows Credentials ******"
$Credentials = (cmdkey /list | Where-Object { $_ -like "*Target=MicrosoftOffice16_Data*" })
Foreach ($Target in $Credentials) {
    $Target = ($Target -split (":", 2) | Select-Object -Skip 1).substring(1)
    $Argument = "/delete:" + $Target
    Start-Process Cmdkey -ArgumentList $Argument -NoNewWindow -RedirectStandardOutput $False
}
Write-Host "****** Clearing Windows Credentials : Complete ******"

# Nuke CredManager
cmd.exe /c "For /F "tokens=1, 2 delims= " %G in ('cmdkey /list ^| findstr Target') do  cmdkey /delete %H"
cmdkey /list | ForEach-Object{if($_ -like "*Target:*"){cmdkey /del:($_ -replace "    ","" -replace "Target: ","")}}

Shutdown -r -t 5