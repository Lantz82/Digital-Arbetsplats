# Save Creds
$ServiceAccount = "SKOVDE\"
$credential = Get-Credential $ServiceAccount
$credential.Password | ConvertFrom-SecureString | Set-Content "C:\Credentials\$ServiceAccount.txt"

# Import Creds
$secPassword = Get-Content "C:\Credentials\$ServiceAccount.txt" | ConvertTo-SecureString
$MyCreds = New-Object System.Management.Automation.PSCredential ($ServiceAccount, $secPassword)