Import-Module -Name ActiveDirectory
function Get-PC-Lista {
    $files = Get-childitem -Path "\\srv-sc-orch02\Reports\CMReports\Raw\"
    foreach ($file in $files) {
        $csv = Get-Content -Path "\\srv-sc-orch02\Reports\CMReports\Raw\$file" | Select-Object -Skip 3 | ConvertFrom-Csv
        $lista = @()
        $lista = foreach ($user in $csv) {
            $Split = $User.Details_Table0_TopConsoleUser.split('\')
            $Domain = $Split[0]
            $ADuser = $Split[1]
            If ($ADuser -eq "local_users") {
                # Local account
                $Displayname = "Datorkonto"
                $Userprincipalname = "Datorkonto"
                $Userprincipalname = "Datorkonto"
                $Office = "Datorkonto"
                $Company = "Datorkonto"
            }
            elseIf ($Domain -eq "Unknown") {
                # Unknown account
                $Displayname = "Saknas"
                $Userprincipalname = "Saknas"
                $Userprincipalname = "Saknas"
                $Office = "Saknas"
                $Company = "Saknas"
            }
            else {
                $ADU = Get-aduser -Identity $ADuser -Properties Office, Company, DisplayName, Userprincipalname
                if($ADU) {
                    $Displayname = $ADU.DisplayName
                    $Userprincipalname = $ADU.UserPrincipalName
                    $Office = $ADU.Office
                    $Company = $ADU.Company
                } else {
                    $Displayname = "Saknas"
                    $Userprincipalname = "Saknas"
                    $Userprincipalname = "Saknas"
                    $Office = "Saknas"
                    $Company = "Saknas"
                }
            }
            [PSCustomObject]@{
                Datornamn = $User.Details_Table0_ComputerName
                Modell    = $User.Details_Table0_Model
                Användare = $DisplayName
                UPN       = $Userprincipalname
                Sektor    = $Office
                Kund      = $Company
            }
        }
        $Date = Get-date -Format yyyy-MM-dd
        $OutFile = $File.Name
        $lista  | Export-Csv -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\$Date-$OutFile" -Encoding UTF8 -NoTypeInformation
    }
}

function Remove-Old-Lista {
    # Remove old reports
    Get-ChildItem -Path "\\srv-sc-orch02\Reports\CMReports\Fixed\" -Recurse | Where-Object { ($_.LastWriteTime -lt (Get-Date).AddDays(-60)) } | Remove-Item
}

Remove-Old-Lista
Get-PC-Lista