function Export-IntuneReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$OS,
        [Parameter(Mandatory = $false)]
        [string]$OutputPath
    )
        Import-Module -name Microsoft.Graph.Intune
        Connect-MSGraph
        # $Date = Get-date -format yyyy-MM-dd
        Get-IntuneManagedDevice | Get-MSGraphAllPages | where{$_.operatingSystem -eq "Android" -or $_.operatingSystem -eq "ios" } | select userPrincipalName,serialNumber,imei,deviceCategoryDisplayName,operatingSystem,model,manufacturer,enrolledDateTime | Sort-Object deviceCategoryDisplayName | Export-CSV $OutputPath\IntuneDevices.csv -NoTypeInformation
        # Start $OutputPath\$date-$OS.csv
}