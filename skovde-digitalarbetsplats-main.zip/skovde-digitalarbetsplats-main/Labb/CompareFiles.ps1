$dir1 = "C:\tmp"
$dir2 = "C:\tmp2"
$d1 = get-childitem -path $dir1 -recurse
$d2 = get-childitem -path $dir2 -recurse
$results = @(compare-object $d1 $d2)

if($results){ 
    Write-Host -fore yellow "These files are missing!"
    foreach($result in $results){
    $result.InputObject
    }
    Write-Host -fore yellow "Starting Robocopy!"
    Robocopy $dir1 $dir2 /S /NP 
    Write-Host -fore green "Done!"
}
else{
    Write-Host -fore green "All files are copied!"
}