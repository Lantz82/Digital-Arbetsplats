Import-Module CredentialManager
$adni0510 =  (Get-StoredCredential -Target adni0510-adm)

#Connect Exchange Online
$exchSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $o365admin -Authentication Basic -AllowRedirection
Import-PSSession $exchSession -DisableNameChecking -AllowClobber

# Connect Exchange Online MFA
Import-Module $((Get-ChildItem -Path $($env:LOCALAPPDATA+"\Apps\2.0") -Filter Microsoft.Exchange.Management.ExoPowershellModule.dll -Recurse ).FullName | ?{$_ -notmatch "_none_"} | select -First 1)
$EXOSession = New-ExoPSSession -Credential $adni0510

Import-PSSession $EXOSession