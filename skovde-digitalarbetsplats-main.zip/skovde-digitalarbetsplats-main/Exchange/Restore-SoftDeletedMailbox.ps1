$oldGUID = get-mailbox "yasa1268" -SoftDeletedMailbox
$newGUID = get-mailbox "yasa120801"
New-MailboxRestoreRequest -SourceMailbox "bba1a93b-b4ff-4cf1-bad6-f6479021e39f" -TargetMailbox "d1d79f57-f945-42c9-8495-0de2eb48a647" -AllowLegacyDNMismatch -verbose
Get-MailboxRestoreRequest