ConnectExO
ConnectMSOL
$us = get-mailuser -ResultSize Unlimited | ?{$_.ExternalEmailAddress -like "*@samarbete.mail.onmicrosoft.com"} | %{Get-MsolUser -UserPrincipalName $_.UserPrincipalName} | ?{$_.islicensed -eq "True"}
$body = $us | foreach-object {Get-aduser -filter {UserPrincipalName -eq $_.UserPrincipalName}} | select UserPrincipalName,Enabled | Out-String
# $body = $us | Select-Object UserPrincipalName | Out-String
$options = @{
    'SmtpServer' = "smtp.skovde.se" 
    'To' = "adam.nilsson@skovde.se" 
    'From' = "tst-adni0510@skovde.se" 
    'Subject' = "External SMTP" 
    'Body' = "Users with ExternalEmailAddress like @samarbete.mail.onmicrosoft.com
    
    $body" 
    # 'Attachments' = $file  
}

If($us){
    Send-MailMessage @options
} 

