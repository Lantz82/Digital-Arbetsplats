$mailboxes = Get-Content -Path "C:\temp\svo.txt" -Encoding UTF8
# $mailboxes = "TI-FN-Socialnämnden"
$file = "C:\temp\TI-FN-Socialnamnden.csv"
foreach ($mailbox in $mailboxes){
    $users = Get-MailboxPermission $mailbox | Where {($_.AccessRights -eq "FullAccess") -and ($_.User -like 'skovde\*')} | Select Identity,User 
    $mailbox | out-file $file -Append -Encoding UTF8
    $users | foreach {($_.user -split "skovde\\")[1]} | foreach {get-aduser $_ -prop mail} | select mail | out-file $file -Append -Encoding UTF8
}