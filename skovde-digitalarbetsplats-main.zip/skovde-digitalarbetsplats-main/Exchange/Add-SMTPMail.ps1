# $Users = Get-ADGroupMember "SPO-HJO-VOO-Hemvården" -Recursive | Where-Object objectClass -eq user
# $User = "test-adni05101"

# foreach ($User in $Users) {
#     $U = Get-ADUser -Identity $User -Properties Mail
#     $OldSMTP = $U.mail.split("{@}")
#     $MailTo = ($OldSMTP[0]) + '@samarbete.mail.onmicrosoft.com'
#     Set-Mailbox "$User" -EmailAddresses @{add = "$MailTo" }
#     Write-Host "Lagt till $MailTo för användare $User" -ForegroundColor Green
# }

# $user = "SK-RS-SOF-LAPTOP-NYA ROSENHAGA"
# Set-Mailbox $user -EmailAddress @{add = "SMTP:SK-RS-SOF-LAPTOP-NYA-ROSENHAGA@samarbete.mail.onmicrosoft.com" }
# Set-Mailbox -Identity $user -WindowsEmailAddress "SK-RS-SOF-LAPTOP-NYA-ROSENHAGA@samarbete.mail.onmicrosoft.com"

# $Domain = "samarbete.mail.onmicrosoft.com"
# foreach ($User in $Users) {
#     if ($User.Proxyaddresses -like "*$Domain*") {
#         Write-Host "$User.SamAccountName has an alias matching $Domain..." -ForegroundColor Yellow 
#     }
#     else {
#         $Alias = "smtp:" + $User.SamAccountName + "@" + $Domain
#         Set-ADUser $User -Add @{Proxyaddresses = "$Alias" }
#         Write-Host "Alias addded to $User.SamAccountName..." -ForegroundColor Green
#     }
# }
# Write-Host "Done" -ForegroundColor Green

#Add Domain samarbete
$ITUsers = Get-ADGroupMember "Org-SSV" -Recursive | select -ExpandProperty name

# $ITUsers = "tirogu13","maro0618","soer021501","maad1225","tijeha07","emsl0725"
$ITUsers = Get-content "C:\temp\svo\svo.txt"

foreach ($User in $ITUsers) {
    $UserToAdd = Get-ADUser -filter { name -like $user } -Properties *
    $Username = $UserToAdd.SamAccountName
    $proxyAddresses = $UserToAdd.proxyAddresses
    if ($proxyAddresses -like "*samarbete*") {
        Write-Host "$username har redan samarbete mail" -ForegroundColor Yellow
    }
    Else {           
        $MailTo = $username + '@samarbete.mail.onmicrosoft.com'
        Set-Mailbox "$Username" -EmailAddresses @{add = "$MailTo" }
        Write-Host "Lagt till $MailTo för användare $Username" -ForegroundColor Green
    }
}

Start-Transcript -Path C:\temp\RTJS-SMTP-Address.log -Append
$rtos = Get-ADGroupMember "Org-ROS" -Recursive | select -ExpandProperty name
# $rtjusers = $rtos | ForEach-Object { Get-aduser -filter { name -like $_ } -Properties mail }
# $rtjMail = $rtjusers | ForEach-Object { $_.mail -replace "rtos.se", "rtjskaraborg.se"}

foreach ($user in $rtos) {
    $rtosUser = Get-aduser -filter { name -like $user -and Enabled -eq $true} -Properties mail
    $rtjMail = $rtosUser.mail -replace "rtos.se", "rtjskaraborg.se"
    # Set-remotemailbox -identity $rtosUser.Userprincipalname -EmailAddresses @{add = $rtjMail}
    Write-Host -ForegroundColor Yellow "$($rtosUser.mail) -> $rtjmail"
    Set-RemoteMailbox -Identity $rtosUser.mail -EmailAddresses @{add = "$rtjMail" }
    Sleep 2
    Set-RemoteMailbox -Identity $rtosUser.mail -PrimarySmtpAddress $rtjMail
}
Stop-Transcript


Get-ADObject -Filter {emailaddress -eq $_.emailaddress distinguishedName -eq $_.distinguishedName -and objectClass -eq 'user' -and Enabled -eq $true} |
Select-Object emailaddress
}


# $rtjMail = $rtjusers | foreach-object {($_.givenname)+"."+($_.surname)+"@rtjskaraborg.se"}
# Set-RemoteMailbox "$Username" -EmailAddresses @{add = "$MailTo" }
$user = "rosm1007"
$rtosUser = Get-aduser -filter { name -like $user } -Properties mail
$rtjMail = $rtosUser.mail -replace "rtos.se", "rtjskaraborg.se"
Set-RemoteMailbox -Identity $rtosUser.name -EmailAddresses @{add = "$rtjMail" }
Set-RemoteMailbox -Identity $rtosUser.name -PrimarySmtpAddress $rtjMail


Start-Transcript -Path C:\temp\RTJS-SMTP-Address.log -Append
$csv = Import-csv -Path "C:\temp\RTJSkaraborg.csv"
# $csv = Import-csv -Path "C:\temp\RTJ02.csv"
$rtos = Get-ADGroupMember "Org-ROS" -Recursive | select -ExpandProperty name
# $rtjusers = $rtos | ForEach-Object { Get-aduser -filter { name -like $_ } -Properties mail }
# $rtjMail = $rtjusers | ForEach-Object { $_.mail -replace "rtos.se", "rtjskaraborg.se"}

$csv = get-aduser -Filter {displayname -like "253*"} | %{get-aduser $_ -prop mail}
foreach ($user in $csv) {
    # $rtosUser = Get-aduser -filter {name -like $user -and Enabled -eq $true} -Properties mail
    # $rtjMail = $rtosUser.mail -replace "rtos.se", "rtjskaraborg.se"
    # $UPN = $rtosUser.Userprincipalname
    # Set-remotemailbox -identity $rtosUser.Userprincipalname -EmailAddresses @{add = $rtjMail}
    $UPN = $user.UserPrincipalName
    Write-Host -ForegroundColor Yellow "$($user.mail) -> $($UPN)"
    Set-remoteMailbox -Identity $user.mail -EmailAddresses @{add = "$UPN" }
    Sleep 1
    Set-remoteMailbox -Identity $user.mail -PrimarySmtpAddress $UPN
}
Stop-Transcript