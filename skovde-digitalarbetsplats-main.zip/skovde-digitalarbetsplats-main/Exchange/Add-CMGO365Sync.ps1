#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
# Fix CMGsync
# 2019-10-25 Adam Nilsson - Initial coding
Param(
    [Parameter(Mandatory=$True)]
        [string]$Mailbox
)
Connect-ExchangeOnline
# $Mailbox = "ingemar.gustafsson@hjo.se"
Get-MailboxFolderPermission $Mailbox":\Calendar"
Get-MailboxFolderPermission $Mailbox":\Kalender"
Add-MailboxFolderPermission $Mailbox":\Calendar" -User "CMGO365Sync" -AccessRights Reviewer
Add-MailboxFolderPermission -Identity $Mailbox":\Kalender" -User "CMGO365Sync" -Accessrights Reviewer

# Add for everyone
$Mailboxes = Get-Mailbox -ResultSize Unlimited -Filter {(userprincipalname -like "*@karlsborg.se") -and (RecipientTypeDetails -eq 'UserMailbox')}
Foreach ($Mailbox in $Mailboxes) {
    Write-Host -ForegroundColor Yellow $Mailbox
    Add-MailboxFolderPermission -Identity $Mailbox":\Calendar" -User "CMGO365Sync" -Accessrights Reviewer -erroraction SilentlyContinue
    Add-MailboxFolderPermission -Identity $Mailbox":\Kalender" -User "CMGO365Sync" -Accessrights Reviewer -erroraction SilentlyContinue
    # Set-MailboxFolderPermission -Identity $Mailbox":\Calendar" -User Default -Accessrights Reviewer
    # Set-MailboxFolderPermission -Identity $Mailbox":\Kalender" -User Default -Accessrights Reviewer
}



# $CalFolder += [string](Get-Mailboxfolderstatistics $Mbx -folderscope calendar).Name
# $cal = Get-MailboxFolderStatistics "adam.nilsson@skovde.se" | Where-Object {$_.foldertype -eq 'Calendar'}
# Add-MailboxFolderPermission $cal -User "CMGO365Sync" -AccessRights Reviewer

# $userRequiringAccess = "CMGO365Sync@samarbete.onmicrosoft.com"
# $accessRight = "Reviewer" 
# $Mailboxes = Get-Mailbox -ResultSize Unlimited -Filter {(RecipientTypeDetails -eq 'UserMailbox')}
# $userRequiringAccess = Get-Mailbox $userRequiringAccess
# foreach ($Mailbox in $Mailboxes) {
#     $accessRights = $null
#     $accessRights = Get-MailboxFolderPermission "$($Mailbox.primarysmtpaddress):\calendar" -User $userRequiringAccess.PrimarySmtpAddress -erroraction SilentlyContinue
         
#     if ($accessRights.accessRights -notmatch $accessRight -and $Mailbox.primarysmtpaddress -notcontains $userRequiringAccess.primarysmtpaddress -and $Mailbox.primarysmtpaddress -notmatch "DiscoverySearchMailbox") {
#         Write-Host "Adding or updating permissions for $($Mailbox.primarysmtpaddress) Calendar" -ForegroundColor Yellow
#         try {
#             Add-MailboxFolderPermission "$($Mailbox.primarysmtpaddress):\calendar" -User $userRequiringAccess.PrimarySmtpAddress -AccessRights $accessRight -ErrorAction SilentlyContinue    
#         }
#         catch {
#             Set-MailboxFolderPermission "$($Mailbox.primarysmtpaddress):\calendar" -User $userRequiringAccess.PrimarySmtpAddress -AccessRights $accessRight -ErrorAction SilentlyContinue    
#         }        
#         $accessRights = Get-MailboxFolderPermission "$($Mailbox.primarysmtpaddress):\calendar" -User $userRequiringAccess.PrimarySmtpAddress
#         if ($accessRights.accessRights -match $accessRight) {
#             Write-Host "Successfully added $accessRight permissions on $($Mailbox.displayname)'s calendar for $($userrequiringaccess.displayname)" -ForegroundColor Green
#         }
#         else {
#             Write-Host "Could not add $accessRight permissions on $($Mailbox.displayname)'s calendar for $($userrequiringaccess.displayname)" -ForegroundColor Red
#         }
#     }else{
#         Write-Host "Permission level already exists for $($userrequiringaccess.displayname) on $($Mailbox.displayname)'s calendar" -foregroundColor Green
#     }
# }
