$rum =  Get-mailbox -ResultSize Unlimited | where {$_.name -like 'TI-RS-RUM-Socialkontoret-*'}
$rum = "SK-RS-KOMF-KONFUTR-MeetUp 2"
Get-CalendarProcessing -id $rum | FL AllB*,AllR*,Book*

# Define the Calendar Processing Properties
$CalProcProp = @{
    AutomateProcessing = 'AutoAccept'
    AllBookInPolicy = $true
    AllRequestInPolicy = $false
    AllRequestOutOfPolicy = $false
    ResourceDelegates = $null
    BookInPolicy = $null
    RequestInPolicy = $null
    RequestOutOfPolicy = $null
}
# Set the Calendar Processing Properties
Set-CalendarProcessing $rum @CalProcProp

$rum = Get-mailbox -ResultSize Unlimited | where {$_.name -like 'TI-RS-RUM-Socialkontoret-*'}
$rum | %{Set-CalendarProcessing $_.Alias @CalProcProp}
$rum | Get-CalendarProcessing | fl Identity,AutomateProcessing,AllB*,AllR*,BookInP*,Req*,Res*

