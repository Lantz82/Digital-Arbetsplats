
# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$return = Invoke-Command -Session $session -ScriptBlock {
    $DistlistName = "\`d.T.~Ed/{256C5500-4D04-484F-B89E-E8DBC4D02BB7}.{50CCC952-BA5E-4247-B023-E1F1F200E30A}\`d.T.~Ed/"
    $Owner = "\`d.T.~Ed/{D95474E6-BBA5-4F27-9FDF-369B9EA1C7B0}.UPN\`d.T.~Ed/"
    Set-ExecutionPolicy Unrestricted
    if ($DistlistName -match '^[A-Z0-9_\-.]+@[A-Z0-9.-]+$') {
        $DistlistName = $DistlistName.split('@')[0]
    }
    Start-Transcript -Path "C:\Temp\NewKBGDL.txt"
    $Owner | Out-File -FilePath "C:\Temp\variabel.txt"
    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewDistList\$LogDate-NewDistList-KBG.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }
    function Remove-DiacriticsAndSpaces {
        Param(
            [String]$inputString
        )
        #replace diacritics
        $sb = [Text.Encoding]::ASCII.GetString([Text.Encoding]::GetEncoding("Cyrillic").GetBytes($inputString))
        #remove spaces and anything the above function may have missed
        $sb = $sb -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $sb = $sb -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $sb = $sb -replace "[àáåäâã]", "a"
        $sb = $sb -replace "[óòôöõ]", "o"
        $sb = $sb -replace "[éèëê]", "e"
        $sb = $sb -replace "[üûúù]", "u"
        $sb = $sb -replace "[íìîï]", "i"
        $sb = $sb -replace "ñ", "n"
        $sb = $sb -replace ' ', '-'
        $sb = $sb -replace ',', '-'      
        return $sb  
    }

    function Connect-Exo-KB {
        $Admin = "srvc-exchange@samarbete.onmicrosoft.com"
        $secPassword = Get-Content "C:\Credentials\srvc-exchange-samarbete.txt" | ConvertTo-SecureString
        $myCreds = New-Object System.Management.Automation.PSCredential ($Admin, $secPassword)
        Connect-ExchangeOnline -Credential $myCreds
    }
    $CleanDistListName = Remove-DiacriticsAndSpaces $DistListName
    if ($CleanDistListName -notmatch "^DL-KBG*") {
        $CleanDistListName = "DL-KBG-" + $CleanDistListName
        $CleanDistListName = $CleanDistListName.ToUpper()
    }

    $Email = $CleanDistListName + "@karlsborg.se"
    Connect-Exo-KB
    New-DistributionGroup -Name $CleanDistListName -DisplayName $CleanDistListName -PrimarySmtpAddress $Email -ManagedBy $Owner
    WriteLog "New Distributionlist  $Email by $Owner"
    Return $CleanDistListName
}
$Name = $Return