# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$Return = Invoke-Command -Session $session -ScriptBlock {

    $ResourceName = "\`d.T.~Ed/{0ED34C87-1E89-48F6-B197-840BFC857809}.{D7C14FBB-D433-4545-B7FD-55912457BC0B}\`d.T.~Ed/"
    $Type = "\`d.T.~Ed/{0ED34C87-1E89-48F6-B197-840BFC857809}.{B23A719E-FAC8-40FB-B792-33C41E27887F}\`d.T.~Ed/"

    Set-ExecutionPolicy Unrestricted

    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewResource\$LogDate-NewResource-KBG.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }

    if ($ResourceName -match '^[A-Z0-9_\-.]+@[A-Z0-9.-]+$') {
        $ResourceName = $ResourceName.split('@')[0]
    }

    function Remove-DiacriticsAndSpaces {
        Param(
            [String]$inputString
        )
        #replace diacritics
        $sb = [Text.Encoding]::ASCII.GetString([Text.Encoding]::GetEncoding("Cyrillic").GetBytes($inputString))
        #remove spaces and anything the above function may have missed
        $sb = $sb -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $sb = $sb -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $sb = $sb -replace "[àáåäâã]", "a"
        $sb = $sb -replace "[óòôöõ]", "o"
        $sb = $sb -replace "[éèëê]", "e"
        $sb = $sb -replace "[üûúù]", "u"
        $sb = $sb -replace "[íìîï]", "i"
        $sb = $sb -replace "ñ", "n"
        $sb = $sb -replace ' ', '-'
        $sb = $sb -replace ',', '-'       
        return $sb   
    }

    function Connect-Exo-KB {
        $Admin = "srvc-exchange@samarbete.onmicrosoft.com"
        $secPassword = Get-Content "C:\Credentials\srvc-exchange-samarbete.txt" | ConvertTo-SecureString
        $myCreds = New-Object System.Management.Automation.PSCredential ($Admin, $secPassword)
        Connect-ExchangeOnline -Credential $myCreds
    }


    if ($ResourceName -match "^RS-KBG*") {
        $ResourceName = $ResourceName.ToUpper()
        $CleanResourceName = $ResourceName.Replace("RS-KBG-", "")
        $CleanResourceName = Remove-DiacriticsAndSpaces $CleanResourceName
        $CleanResourceName = "RS-KBG-$Type-$CleanResourceName"
        $CleanResourceName = $CleanResourceName.ToUpper()
    }

    else {
        $CleanResourceName = Remove-DiacriticsAndSpaces $ResourceName
        $CleanResourceName = "RS-KBG-$Type-$CleanResourceName"
        $CleanResourceName = $CleanResourceName.ToUpper()
    }

    Connect-Exo-KB

    if ($Type -match "Rum") {
        New-Mailbox -Name $CleanResourceName -Room
        WriteLog "New Room $CleanResourceName"
    }

    else {
        New-Mailbox -Name $CleanResourceName -Equipment
        WriteLog "New Equipment $CleanResourceName"
    }

    Start-Sleep 15

    $Calendar = "$($CleanResourceName):\Calendar"


    Set-MailboxFolderPermission -Identity $Calendar -AccessRights Reviewer -User "Default"
    Set-MailboxFolderPermission -identity $Calendar -AccessRights Reviewer -User "Anonymous"	
    Set-CalendarProcessing $CleanResourceName -AutomateProcessing 'AutoAccept' -ForwardRequestsToDelegates $false -BookingWindowInDays '400' -MaximumDurationInMinutes '2880' -AllBookInPolicy $true

    Return $CleanResourceName
}

$Name = $Return