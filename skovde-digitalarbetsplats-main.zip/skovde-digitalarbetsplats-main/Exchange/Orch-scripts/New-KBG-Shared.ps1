
# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$Return = Invoke-Command -Session $session -ScriptBlock {
    $SharedMailboxName = "\`d.T.~Ed/{4ED85F71-B27B-4460-93C2-33AA1AB8F754}.{EF8D8B36-0203-4949-BD97-ED4FD146E4D9}\`d.T.~Ed/"
    $UsersFullAccess = "\`d.T.~Ed/{700E5F81-8C6C-4A57-8758-405E5C5BB5E6}.noarrayusers\`d.T.~Ed/"

    $UsersFullAccess = $UsersFullAccess.split(",")

    if ($SharedMailboxName -match '^[A-Z0-9_\-.]+@[A-Z0-9.-]+$') {
        $SharedMailboxName = $SharedMailboxName.split('@')[0]
    }
    Set-ExecutionPolicy Unrestricted
    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewShared\$LogDate-NewShared-KBG.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }
    function Remove-DiacriticsAndSpaces {
        Param(
            [String]$inputString
        )
        #replace diacritics
        $sb = [Text.Encoding]::ASCII.GetString([Text.Encoding]::GetEncoding("Cyrillic").GetBytes($inputString))
        #remove spaces and anything the above function may have missed
        $sb = $sb -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $sb = $sb -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $sb = $sb -replace "[àáåäâã]", "a"
        $sb = $sb -replace "[óòôöõ]", "o"
        $sb = $sb -replace "[éèëê]", "e"
        $sb = $sb -replace "[üûúù]", "u"
        $sb = $sb -replace "[íìîï]", "i"
        $sb = $sb -replace "ñ", "n"
        $sb = $sb -replace ' ', '-'
        $sb = $sb -replace ',', '-'      
        return $sb  
    }

    function Connect-Exo-KB {
        $Admin = "srvc-exchange@samarbete.onmicrosoft.com"
        $secPassword = Get-Content "C:\Credentials\srvc-exchange-samarbete.txt" | ConvertTo-SecureString
        $myCreds = New-Object System.Management.Automation.PSCredential ($Admin, $secPassword)
        Connect-ExchangeOnline -Credential $myCreds
    }

    $CleanMailBoxName = Remove-DiacriticsAndSpaces $SharedmailboxName
    if ($CleanMailBoxName -notmatch "^FN-KBG*") {
        $CleanMailBoxName = "FN-KBG-$CleanMailBoxName"
        $CleanMailBoxName = $CleanMailBoxName.ToUpper()
    }

    $Email = $CleanMailBoxName + "@karlsborg.se"
    Connect-Exo-KB
    New-Mailbox -Name $CleanMailBoxName -PrimarySmtpAddress $Email -Shared

    foreach ($UserFull in $UsersFullAccess) {
        Add-MailboxPermission $Email -User $UserFull -AccessRights FullAccess -InheritanceType all
        Add-RecipientPermission $Email -Trustee $UserFull -AccessRights SendAs -confirm:$False
    }
    WriteLog "New Sharedmailbox $Email by $UsersFullAccess"
    Return $CleanMailBoxName
}

$Name = $Return