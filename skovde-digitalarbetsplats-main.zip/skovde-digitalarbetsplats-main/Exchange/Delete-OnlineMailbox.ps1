﻿#requires -version 3.0
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
#
# 2019-03-01 Fredrik Lindberg - Inital Coding
# 2019-07-02 Adam Nilsson - Added functions n stuff
param([string] $File);

if (!$File) {
    $Users = Read-Host("Please provide a UPN")
} 
Else { 
    $Users = Get-Content $File;
}

# Connect Exchange Online
ConnectExO
ConnectMSOL
Clear-Host
$licenseByUsers = @{};
foreach($username in $users) {
    try {
        $user = Get-MSOLUser -UserPrincipalName $username -ErrorAction Stop; 
    } 
    catch {
        Write-Host " "
        Write-Host -ForegroundColor red "An error occurred:"
        Write-Host -ForegroundColor red $_
    }
    if ($user.isLicensed) {
        $licenseByUsers[$username] = $user; 
        $License = $User.Licenses.AccountSkuId;
        Write-Host "$username Removing $License" -ForegroundColor Yellow;
        Set-MsolUserLicense -UserPrincipalName $user.userPrincipalName -RemoveLicenses $License;
    }
}
Write-Host "Please wait..."
CountDown 240
#Start-Sleep 240;

foreach ($username in $licenseByUsers.Keys) {
    if ($licenseByUsers.ContainsKey($username)) {
        Write-Host "$Username PermanentlyClear" -ForegroundColor Yellow;
        Set-User $Username -PermanentlyClearPreviousMailboxInfo -Force -Confirm:$false
    }
}
Write-Host "Please wait..."
CountDown 240
#Start-Sleep 240

foreach ($username in $licenseByUsers.Keys) {
    $License = $licenseByUsers[$username].Licenses.AccountSkuId; 
    Write-host -ForegroundColor Yellow "$username Restoring $License";
    Set-MsolUserLicense -UserPrincipalName $username -AddLicenses $License
}

Write-Host "Exchange Online mailbox deleted for $username" -ForegroundColor Green
Write-Host -ForegroundColor Yellow "Disconnecting Exchange Online.."
Get-PSSession | Remove-PSSession
Write-Host -ForegroundColor Yellow  "DONE!"