

$Resources = Get-Mailbox -resultsize unlimited | where-object {($_.isresource -eq 'true') -and ($_.displayname -like "HJ-RS*")}
$Distlist = Get-DistributionGroup -resultsize unlimited | where-object {$_.displayname -like "HJ-DL*"}

$box = Get-DistributionGroup SK-DL-AdniTest001
$box = Get-mailbox SK-RS-AdniTest001

foreach ($box in $Distlist) {
    $Displayname = $box.displayname
    $NewDisplayname = $Displayname.replace('SK-DL','DL-SK')
    Set-DistributionGroup $box -DisplayName $NewDisplayname
}

foreach ($box in $Resources) {
    $Displayname = $box.displayname
    $NewDisplayname = $Displayname.replace('SK-RS','RS-SK')
    Set-Mailbox $box -DisplayName $NewDisplayname
}
