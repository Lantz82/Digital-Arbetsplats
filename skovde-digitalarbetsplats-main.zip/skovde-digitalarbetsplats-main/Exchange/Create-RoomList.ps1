
# Create
 New-DistributionGroup -Name Bldg_HUB -DisplayName "Student Union Building Conf Rooms" –PrimarySmtpAddress Bldg_HUB@contoso.edu –RoomList

# Add
$roomlist = "SK-DG-Stadshusrum01"
$room = "Arkitekten"
foreach($room in $members) {
    Add-DistributionGroupMember –Identity $roomlist -Member $room
}

Add-DistributionGroupMember –Identity $roomlist -Member $room
Add-DistributionGroupMember –Identity Bldg_HUB -Member Room_HUB1002


# The following command will list the Room List Distribution Groups.
Get-DistributionGroup | Where {$_.RecipientTypeDetails -eq "RoomList"} | Format-Table DisplayName,Identity,PrimarySmtpAddress
Get-DistributionGroupMember -Identity $roomlist

