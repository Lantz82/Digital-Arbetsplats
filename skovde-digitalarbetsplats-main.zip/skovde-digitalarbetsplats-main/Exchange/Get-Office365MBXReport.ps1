﻿<#
.SYNOPSIS
Get-Office365MBXReport.ps1 - Enumerate the membership of Exchange RBAC groups

.DESCRIPTION 
This powershell script provides information about Exchange Online mailboxes. It includes following 
attributes: FirstName, LastName, DisplayName, Alias, UserPrincipalName, EmailAddress, MBX Size (MB),  
WhenCreated, LastLogonTime, Days MBX Inactive, LastPasswordChangeTimestamp and basic licensing information.

.OUTPUTS
Results are output to CSV. Each mailbox's details are presented in a single file.

.EXAMPLE
.\Get-Office365MBXReport.ps1 Generates the CSV file.

.NOTES
Written by: Joey Hornick
https://gallery.technet.microsoft.com/Exchange-Online-Mailbox-ff59e2c4?redir=0

Change Log
V1.00, 03/24/2017 - Initial version
V1.01, 04/05/2014 - Adjusted variable names
v1.02, 04/10/2017 - Added tenant name to Summary file, files dropped in C:\Temp
v1.03, 05/30/2017 - Updated progress bar UI
#>
 
#Establish Variables 
$outputpath = 'C:\Temp\Office365MBXReport'
$summaryFile = "$outputpath"+"$tenant"+"-O365Report_$TimeStamp.csv"
$TimeStamp = Get-Date -Format 'MM:dd:yyyy - H:mm' | foreach {$_ -replace ":", "."} 
$tenant = (((Get-MsolDomain | Where-Object {$_.IsInitial -EQ $true}).Name).Split(".",3) | Select-Object -Index 0)
$usersProcessed = 0 
$ErrorActionPreference= 'silentlycontinue' 
 
 
#Initialize output file 
$Report=@() 
$Mailboxes = Get-Mailbox -ResultSize Unlimited 
$numusers = $Mailboxes.Count 
$usersProcessed = 1 
$StartDate = Get-Date 
 
foreach ($mailbox in $Mailboxes) { 
$usersProcessed ++ 
$DisplayName = $mailbox.DisplayName 
$UPN  = $mailbox.UserPrincipalName 
$UserDomain = $UserPrincipalName.Split('@')[1] 
$Alias = $mailbox.alias 
$Email = $mailbox.PrimarySmtpAddress 
$WhenCreated = $mailbox.WhenCreated 
$MailboxStat = Get-MailboxStatistics $UserPrincipalName 
$LastLogonTime = $MailboxStat.LastLogonTime  
$EndDate = Get-Date -Date $LastLogonTime 
$Difference = New-TimeSpan -Start $StartDate -End $EndDate 
$Inactive = $Difference.Days 
$TotalItemSize = $MailboxStat | select @{name="TotalItemSize";expression={[math]::Round(($_.TotalItemSize.ToString().Split("(")[1].Split(" ")[0].Replace(",","")/1MB),2)}} 
$TotalItemSize = $TotalItemSize.TotalItemSize 
$RecipientTypeDetails = $mailbox.RecipientTypeDetails 
$MSOLUSER = Get-MSOLUSER -UserPrincipalName $UPN 
$Information = $MSOLUSER | select FirstName,LastName,DisplayName,@{Name='Alias';Expression={$Alias.ToString()}},UserPrincipalName,@{Name='EmailAddress';Expression={$Email.ToString()}},@{Name='MBX Size (MB)';Expression={$TotalItemSize.ToString()}},@{Name='WhenCreated';Expression={$WhenCreated.ToString()}},@{Name='LastLogonTime';Expression={$LastLogonTime.ToString()}},@{Name='Days MBX Inactive';Expression={$Inactive.ToString()}},LastPasswordChangeTimestamp,@{Name="Licenses";Expression={$_.Licenses.AccountSkuId}}  
$Report = $Report+$Information 

##### DO NOT REMOVE ######
$percentage = [math]::Round($usersProcessed/$numusers *100)
$message = "Processing User Account: $DisplayName  ($usersProcessed of $numusers)" -f $percentage
Write-Progress -Activity $message -PercentComplete ($percentage) -Status "$percentage % Complete:  "
$usersProcessed++
##### DO NOT REMOVE ######
} 
 
$Report | Export-Csv  $summaryFile -NoTypeInformation 