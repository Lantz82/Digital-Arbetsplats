#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
# 
param(
    [Parameter(Mandatory=$True)]
        [string] $Displayname,
    [Parameter(Mandatory=$True)]
        [string] $Kommun
)

ConnectEx
$CleanName = RemoveDiacritics $Displayname
switch ($Kommun){
    'skovde' {$Name = "SK-DL-$Displayname";$Alias = "SK-DL-$CleanName";$Email = $Alias+"@skovde.se";$OU = "kommun.skovde.se/Top/Skovde/Exchange"}
    'hjo'    {$Name = "HJ-DL-$Displayname";$Alias = "HJ-DL-$CleanName";$Email = $Alias+"@hjo.se";$OU = "kommun.skovde.se/Top/Hjo/Exchange"}
    'tibro'  {$Name = "TI-DL-$Displayname";$Alias = "TI-DL-$CleanName";$Email = $Alias+"@tibro.se";$OU = "kommun.skovde.se/Top/Tibro/Exchange"}
}

New-DistributionGroup -name $Name -DisplayName $Name -Alias $Name -PrimarySmtpAddress $Email -OrganizationalUnit $OU