$userlist = Import-Excel -Path .\InData\Migration_20201112.xlsx 

foreach ($users in $userlist){
    $username = $users.name
    Set-Mailbox -id $username -EmailAddresses @{add="$username@samarbete.mail.onmicrosoft.com"}
}