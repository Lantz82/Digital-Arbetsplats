#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
#
# 2019-06-03 Adam Nilsson - Initial coding
# 2019-06-26 Adam Nilsson - Added prompts
# 2019-07-02 Adam Nilsson - Added parameter
# 2019-10-16 Adam Nilsson - Added Skövde Energi & Function RemoveDiacritics
param(
    [Parameter(Mandatory = $True)]
    [string] $Displayname,
    [Parameter(Mandatory = $True)]
    [string] $Kommun,
    [Parameter(Mandatory = $True)]
    [string] $Type,
    [string] $Capacity
)

Write-Host "Connecting to Exchange Online..."
Connect-ExchangeOnline

If (!$Displayname) {
    $Displayname = Read-Host ("Please provide a name")
} 
If (!$Kommun) {
    $Kommun = Read-Host ("Enter skovde, hjo or tibro?")
} 
$CleanName = RemoveDiacritics $Displayname
switch ($Kommun) {
    'skovde' { $Name = "SK-RS-$CleanName"; $Email = $name + "@skovde.se" }
    'hjo' { $Name = "HJ-RS-$CleanName"; $Email = $name + "@hjo.se" }
    'tibro' { $Name = "TI-RS-$CleanName"; $Email = $name + "@tibro.se" }
    'SEAB' { $Name = "SEAB-RS-$CleanName"; $Email = $name + "@skovdeenergi.se" }
}

If (Get-mailbox -Identity $Displayname -ErrorAction SilentlyContinue) {
    Write-Warning "$Displayname already exists, aborting." -ErrorAction Stop 
}
else {
    If (!$Type) {
        Write-Host 'Do you want to provision a Room or Equipment?'
        $Type = Read-host -Prompt "Enter room or equipment"
    }
    If ($Type -eq 'room' -and (!$Capacity)) {
        $Capacity = Read-Host -Prompt "Capacity?"
    }
    Write-Host -ForegroundColor Yellow  "Creating new resource $Name, please wait..."
    If ($type -eq 'room') {
        New-Mailbox -Room -Name $Name -ResourceCapacity $Capacity -DisplayName $Displayname -Alias $Name -FirstName $Name -LastName "" -Initial "" -PrimarySmtpAddress $Email | Out-Null
    }
    else {
        New-Mailbox -Equipment -Name $Name -DisplayName $Displayname -Alias $Name -FirstName $Name -LastName "" -Initial "" -PrimarySmtpAddress $Email | Out-Null
    }
    # switch ($type) {
    #     'room' { New-Mailbox -Room -Name $Name -ResourceCapacity $Capacity -DisplayName $Displayname -Alias $Name -FirstName $Name -LastName "" -Initial "" -PrimarySmtpAddress $Email | Out-Null } 
    #     'equipment' { New-Mailbox -Equipment -Name $Name -DisplayName $Displayname -Alias $Name -FirstName $Name -LastName "" -Initial "" -PrimarySmtpAddress $Email | Out-Null } 
    # }
    Start-Sleep 15
    $Calendar = "$($Name):\Calendar"
    Write-Host -ForegroundColor Yellow  "Setting MailboxFolderPermissions, please wait..."
    Start-Sleep 30
    If (Get-Mailbox -Identity $name) {
        Set-MailboxFolderPermission -Identity $Calendar -AccessRights Reviewer -User "Default"
        Set-MailboxFolderPermission -identity $Calendar -AccessRights Reviewer -User "Anonymous"
        Set-CalendarProcessing -Identity $Name -AutomateProcessing 'AutoAccept' -ForwardRequestsToDelegates $false -BookingWindowInDays '400' -MaximumDurationInMinutes '2880' -AllBookInPolicy $true
        Write-Host -ForegroundColor Green "$Displayname is now created."
        Write-Host -ForegroundColor Green "Email address: $Name"
    }
    Else {
        Write-Warning "Something went wrong! Could not find resource $name"
    }
}