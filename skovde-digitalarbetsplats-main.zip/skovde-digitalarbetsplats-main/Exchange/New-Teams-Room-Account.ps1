# Connect to Office365
Import-Module CredentialManager
$o365admin =  (Get-StoredCredential -Target o365admin)
$exchSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $o365admin -Authentication Basic -AllowRedirection
Import-PSSession $exchSession -DisableNameChecking -AllowClobber

Connect-MsolService
Import-Module SkypeOnlineConnector
$skype = New-CsOnlineSession -UserName 'adni0510-adm@samarbete.onmicrosoft.com'
Import-PSSession $skype -AllowClobber

# Create new Teams-Room-Account
$newRoom = "SEAB-RS-RUM-TEAMSRUM@samarbete.onmicrosoft.com" 
$name = "SEAB-RS-RUM-TEAMSRUM" 
$pass = "ebKGFT9y!" 
$license ="samarbete:STANDARDPACK"
$mailtip = "This room is equipped to support Teams and Skype Meetings"
$regpool = "sippoolDB41E03.infra.lync.com"

New-Mailbox -MicrosoftOnlineServicesID $newRoom -Name $name -Room -RoomMailboxPassword (ConvertTo-SecureString -String $pass -AsPlainText -Force) -EnableRoomMailboxAccount $true
Start-Sleep -Seconds 30
Set-MsolUser -UserPrincipalName $newRoom -PasswordNeverExpires $true -UsageLocation "SE"
Set-MsolUserLicense -UserPrincipalName $newRoom -AddLicenses $license
#Set-Mailbox -Identity $newRoom -MailTip $mailtip
Start-Sleep -Seconds 600
Enable-CsMeetingRoom -Identity $newRoom -SipAddressType "EmailAddress" -RegistrarPool $regpool
