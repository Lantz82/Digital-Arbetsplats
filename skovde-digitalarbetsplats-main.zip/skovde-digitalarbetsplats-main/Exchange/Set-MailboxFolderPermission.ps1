ConnectExO

$resurs = "Stensättaren:\kalender"
Get-MailboxFolderPermission $resurs

# Set Default user
Set-MailboxFolderPermission $resurs -User Default -AccessRights Reviewer
Add-MailboxFolderPermission $resurs -User "anno0104" -AccessRights Editor

# Add single user
Add-MailboxFolderPermission $resurs -User "EORG-HJO-VOO-Resursochbistandsenhet" -AccessRights Editor

# Add group of users
$users = Get-ADGroupMember -Identity "ID" -Recursive | Get-ADUser -Properties Mail | Select-Object -ExpandProperty Mail
$users | ForEach-Object {Add-MailboxFolderPermission $resurs -User $_ -AccessRights Editor}
Get-MailboxFolderPermission $resurs

# Set Default Reviewer
$mailboxes = Get-mailbox -Filter {EmailAddresses -like "*"}
$mailboxes | ForEach-Object {Set-MailboxFolderPermission $_”:\kalender” -User Default -AccessRights LimitedDetails}
$mailboxes | ForEach-Object {Set-MailboxFolderPermission $_”:\calendar” -User Default -AccessRights LimitedDetails}

Get-MailboxFolderPermission "olol0331:\calendar"

Get-DistributionGroupMember -Identity "SK-DL-SSV-Kontaktcenter" | %{Add-DistributionGroupMember -Identity "SK-DL-SSV-Kontaktcenter2" -Member $_.name}