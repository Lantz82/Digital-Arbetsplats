#requires -version 3.0
# New-Migration.ps1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
#
# 2019-06-27 Adam Nilsson - Initial coding
# 2019-07-02 Adam Nilsson - Added parameter
param(
    [Parameter(Mandatory=$True)]
        [string] $User
)
$adniadm =  (Get-StoredCredential -Target adni0510-adm)

ConnectExO
ConnectMSOL

$ADUser = Get-ADUser -Identity $User
$MSOLUser = Get-MsolUser -UserPrincipalName $ADUser.UserPrincipalName

If (Get-mailbox -Identity $User -ErrorAction SilentlyContinue){
    Write-Output "$User is already in Exchange Online, aborting."
    Exit
}
Else {
    If (!($MSOLUser.IsLicensed -eq 'True')) {
        Write-Warning "$User is missing license, aborting."
        Exit
}
    Else {
        try {
            New-MoveRequest -Identity $User -Remote -RemoteHostName webmail.skovde.se -TargetDeliveryDomain samarbete.mail.onmicrosoft.com -RemoteCredential $adniadm -BadItemLimit 50 -ErrorAction Stop
            Write-Output "Migration started for user $User"
        }
        catch {
            $ErrorMessage = $Error[0]
            Write-Warning "Something went wrong"
            Write-WarningMessage $ErrorMessage
            Exit
        }
    }
}
Get-MoveRequest -MoveStatus Inprogress | Get-MoveRequestStatistics | ft alias, statusdetail, TotalmailboxSize, percentcomplete, bytestrans* -AutoSize
Write-Output "Disconnecting Exchange Online ..."
Get-PSSession | Remove-PSSession