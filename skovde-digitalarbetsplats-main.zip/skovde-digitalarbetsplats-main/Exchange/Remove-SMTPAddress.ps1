$users = get-aduser -Filter {mail -like "*@skovdeenergi.se"} -prop mail

foreach ($user in $users) {
    $email = (Get-samarbeteMailbox $user.mail).EmailAddresses | Where-Object {$_ -like '*@skovde.se'}
    Set-RemoteMailbox $user.mail -EmailAddresses @{remove="$($email)"}
    Write-Host -ForegroundColor Yellow "Removed $email from user "$user.mail""
}