Param(
    [Parameter(Mandatory=$True)]
        [string]$File,
    [Parameter(Mandatory=$False)]
        [switch]$CreatePlaceHolder,
    [Parameter(Mandatory=$False)]
        [switch]$Finalize
)
$groups = Get-Content $file
If ($CreatePlaceHolder.IsPresent){
    Foreach ($group in $groups) {
        .\Recreate-DistributionGroup.ps1 -Group $group -CreatePlaceHolder  
    }
}
ElseIf ($Finalize.IsPresent){
    Foreach ($group in $groups) {
        .\Recreate-DistributionGroup.ps1 -Group $group -Finalize  
    }
}