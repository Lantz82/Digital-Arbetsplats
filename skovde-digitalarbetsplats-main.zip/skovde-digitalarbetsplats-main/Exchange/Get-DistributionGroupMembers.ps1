#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
# 2019-11-05 Adam Nilsson - Initial coding
Param(
    [Parameter(Mandatory=$True)]
        [string]$Group,
    [Parameter(Mandatory=$True)]
        [string]$File
)
$DistGroup = Get-DistributionGroup $Group
if (!$DistGroup){
    Write-Warning -Message "Could not find the group $group"
}
else {
    Get-DistributionGroupMember -Identity $Group | ForEach-Object {Get-ADUser $_.name -Properties Mail,Description,Office} | Select-Object Mail,Description,Office | Export-Csv -Path $File -NoTypeInformation -Encoding UTF8 -Delimiter ';'
    Write-Host -ForegroundColor Green "The file $file is now done!"
}