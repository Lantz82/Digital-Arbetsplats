$name = "irfan.kovacevic"
New-ComplianceSearch -Name $name -ExchangeLocation All -ContentMatchQuery 'subject:"Skovde"'

# Granska resultatet så scope't ser OK ut.
(Get-ComplianceSearchAction -Identity "irfan.kovacevic_Preview" | Select-Object -ExpandProperty Results) -split ","

# Ser allt OK ut, kör en purge för att rensa bort meddelandet.
New-ComplianceSearchAction -SearchName irfan.kovacevic -Purge -PurgeType SoftDelete

irfan.kovacevic@skovde.se