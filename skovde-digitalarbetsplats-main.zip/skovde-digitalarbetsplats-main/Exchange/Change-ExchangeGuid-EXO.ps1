$Userlist = Import-Csv -Path .\InData\Users_ExGuid_201112.csv -Encoding UTF8

foreach ($user in $Userlist){
    $username = $User.Name
    $GUID = $User.ExchangeGuid
    Set-MailUser -Identity $username -ExchangeGUID $GUID
}

