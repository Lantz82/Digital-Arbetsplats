$Mailboxes = Get-EXOMailbox -filter { Emailaddresses -like "*skovde.se" } -resultsize unlimited 

ForEach ($Mailbox in $Mailboxes) {
    $Mail = $Mailbox.PrimarySmtpAddress
    $CalendarBox = Get-EXOMailboxFolderStatistics -Identity $Mail -FolderScope Calendar | Where-Object { $_.FolderType -eq 'Calendar' }
    $CalendarIdentity = $Mail + ":" + $CalendarBox.FolderId
    $CalendarInfo = Get-EXOMailboxFolderPermission $CalendarIdentity  -user Default
    $output = [ordered]@{
        'Mailbox'      = $Mailbox.PrimarySmtpAddress
        'User'         = $CalendarInfo.User
        'AccessRights' = $CalendarInfo.AccessRights
    }
    new-object psobject -Property $output | Out-File c:\temp\SEAB005.txt -Append
    # Export-Csv -Path C:temp\KBG-Shared_AccessRights.csv -Encoding UTF8 -Append
}
################
# $Mail = "FN-KB-GUIDETURER"
# $Mail = "FN-KB-KONFERENSRUM-INFOCENTER"
# Export Mailbox FullAccess permissions
# $Mailboxes = Import-Csv -Path C:\temp\KBGMIG\mail-shared02.csv
$OutFile = "C:\temp\KBGMIG\Shared-$Mail.csv"
ForEach ($Mailbox in $Mailboxes) {
    $Mail = $Mailbox.SourceEmail
    Get-MailboxPermission $mail | Where-Object { ($_.IsInherited -eq $False) -and -not ($_.User -like "NT AUTHORITY\SELF") } | Select-Object Identity, user, AccessRights | Export-Csv -Path $OutFile -Encoding UTF8 -Append -Force -NoTypeInformation  
}

# Set Mailbox FullAccess permissions
$ImportFile = "C:\temp\KBGMIG\Shared-$Mail.csv"
$permissions = Import-Csv -Path $ImportFile
foreach ($permission in $permissions) {
    Add-MailboxPermission -Identity $permission.identity -User $permission.user -AccessRights $permission.accessrights
}

# Set Mailbox FullAccess permissions
$ImportFile = "C:\temp\KBGMIG\Shared-$Mail.csv"
$permissions = Import-Csv -Path $ImportFile
foreach ($permission in $permissions) {
    Add-RecipientPermission $permission.identity -AccessRights SendAs -Trustee $permission.user -Confirm:$false
}