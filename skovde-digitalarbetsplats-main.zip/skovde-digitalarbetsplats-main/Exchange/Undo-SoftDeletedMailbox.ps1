Get-Mailbox -SoftDeletedMailbox | Select-Object Name,Displayname,ExchangeGuid
Undo-SoftDeletedMailbox -SoftDeletedObject "ID"