Set-AzureADUser -ObjectId "skvdtest@samarbete.onmicrosoft.com" -UserPrincipalName "skvdtest@mig.samarbete.onmicrosoft.com"
# Get-mailbox -resultsize unlimited | %{Set-Mailbox $_ -EmailAddresses $_.UserPrincipalName}
Get-mailbox "skvdtest" | % { Set-Mailbox $_ -EmailAddresses $_.UserPrincipalName }
Set-Mailbox skvdtest -EmailAddresses "skvdtest@samarbete.onmicrosoft.com"

Get-mailbox -resultsize unlimited | % { Set-Mailbox $_ -EmailAddresses $_.UserPrincipalName }
$kbg = Get-mailbox -resultsize unlimited -Filter {EmailAddresses -like "*karlsborg.se"}
$kbg | select name, PrimarySmtpAddress, Emailaddresses | Export-Csv -Path c:\temp\kbgmig\rest.csv -NoTypeInformation -Encoding UTF8
foreach ($user in $kbg) {
    $NewSMTP = $user.userprincipalname
    Set-Mailbox $user.userprincipalname -EmailAddresses $NewSMTP
    Write-Host $user.userprincipalname -> $NewSMTP
}


$kbgedu = Get-mailbox -resultsize unlimited -Filter {EmailAddresses -like "*edu.karlsborg.se"}
$kbgedu | select name, PrimarySmtpAddress, Emailaddresses | Export-Csv -Path c:\temp\kbgmig\rest.csv -NoTypeInformation -Encoding UTF8
foreach ($user in $kbgedu) {
    $NewSMTP = $user.userprincipalname
    Set-Mailbox $user.userprincipalname -EmailAddresses $NewSMTP
    Write-Host $user.userprincipalname -> $NewSMTP
}

# Get-EXOMailbox -Filter * -RecipientTypeDetails -eq Room
$Date = Get-date -format yyyy-MM-dd
# SHARED
$AllShared = Get-Mailbox -RecipientTypeDetails SharedMailbox -ResultSize Unlimited
$AllShared | select Name, UserPrincipalName, PrimarySmtpAddress |  Export-Csv -Path "C:\temp\KBGMIG\LOG\$date-shared.csv" -NoTypeInformation -Encoding UTF8
foreach ($Shared in $AllShared) {
    $OldSMTP = $Shared.PrimarySmtpAddress
    $NewSMTP = $OldSMTP -replace "karlsborg.se", "Karlsborgskommun.onmicrosoft.com"
    Write-Host "$oldSMTP -> $NewSMTP"
    Set-AzureADUser -ObjectId $Shared.UserPrincipalName -UserPrincipalName $NewSMTP
    Set-Mailbox -Identity $Shared.Identity -EmailAddresses $NewSMTP
}

# $Shared = Get-Mailbox -id LFBK
# Get-AzureADUser -ObjectId $Shared.UserPrincipalName

# DIST
$AllDist = Get-DistributionGroup -ResultSize Unlimited
$AllDist | select Name, PrimarySmtpAddress |  Export-Csv -Path "C:\temp\KBGMIG\LOG\$date-Dist.csv" -NoTypeInformation -Encoding UTF8
foreach ($Dist in $AllDist) {
    $OldSMTP = $Dist.PrimarySmtpAddress
    $NewSMTP = $OldSMTP -replace "karlsborg.se", "Karlsborgskommun.onmicrosoft.com"
    Write-Host "$oldSMTP -> $NewSMTP"
    Set-DistributionGroup -Identity $Dist.Identity -EmailAddresses $NewSMTP
}

$AllEDUDist = Get-DistributionGroup -ResultSize Unlimited | ? { $_.PrimarySmtpAddress -like "*edu.karlsborg.se" }
$AllEDUDist | select Name, PrimarySmtpAddress |  Export-Csv -Path "C:\temp\KBGMIG\LOG\$date-EDUDist.csv" -NoTypeInformation -Encoding UTF8
foreach ($EDUDist in $AllEDUDist) {
    $OldSMTP = $EDUDist.PrimarySmtpAddress
    $NewSMTP = $OldSMTP -replace "edu.karlsborg.se", "Karlsborgskommun.onmicrosoft.com"
    Write-Host "$oldSMTP -> $NewSMTP"
    Set-DistributionGroup -Identity $EDUDist.Identity -EmailAddresses $NewSMTP
}
# $Dist = Get-DistributionGroup -id "Media - Sändlista"

# ROOM
$AllRoom = Get-Mailbox -Filter '(RecipientTypeDetails -eq "RoomMailBox")'
$AllRoom | select Name, UserPrincipalName, PrimarySmtpAddress |  Export-Csv -Path "C:\temp\KBGMIG\LOG\$date-Room.csv" -NoTypeInformation -Encoding UTF8
foreach ($Room in $AllRoom) {
    $OldSMTP = $Room.PrimarySmtpAddress
    $NewSMTP = $OldSMTP -replace "karlsborg.se", "Karlsborgskommun.onmicrosoft.com"
    Write-Host "$OldSMTP -> $NewSMTP"
    Set-AzureADUser -ObjectId $Room.UserPrincipalName -UserPrincipalName $NewSMTP
    Set-Mailbox -Identity $Room.Identity -EmailAddresses $NewSMTP
}
# $Room = Get-Mailbox -Identity "Carl Johan hemkunskap Sal45 Bokning"


# foreach ($Dist in $AllDist) {
#     $Dist.EmailAddresses | where { $_.AddressString -like '*@karlsborg.se' } | foreach {
#         Set-mailbox $Dist -EmailAddresses @{remove = $_ }
#     }
# }


Get-AzureADUser -all $true -Filter {UserPrincipalName -like *edu.Karlsborgskommun.onmicrosoft.com}
Get-AzureADUser -all $true | where{$_.UserPrincipalName -like "*edu.Karlsborgskommun.onmicrosoft.com" -and $_.AssignedLicenses.Count -eq 0}

$kbgedu = Get-AzureADUser -all $true | where{$_.UserPrincipalName -like "*edu.Karlsborgskommun.onmicrosoft.com" -and $_.ProxyAddresses -like "*edu.karlsborg.se"}
$kbgedu | Remove-AzureADUser

SMO-UtbildningOffice365@edu.Karlsborgskommun.onmicrosoft.com

Get-AzureADUser -ObjectId "enaz.alruba@edu.Karlsborgskommun.onmicrosoft.com"

Get-AzureADUser -All $true -Filter "dirSyncEnabled eq true"


Get-AzureADUser | where {$_.Manager -ne $null -and $_.AssignedLicenses.Count -eq 0 -and $_.UserType -eq "Member"}


foreach ($FixdMailbox in $FixdMailboxes) {
    $ADuser = Get-ADuser -filter { mail -eq skvdtest@karlsborg.se }
    $ADuser = Get-ADuser skvdtest
    $Sam = $ADuser.SamAccountName
    Enable-RemoteMailbox -Identity $Sam -RemoteRoutingAddress "$Sam@samarbete.mail.onmicrosoft.com"
    Write-Host -ForegroundColor Green "Remotemailbox $mailbox is now enabled!"
}

Set-RemoteMailbox -Identity $UPN -PrimarySmtpAddress $upn EmailAddressPolicyEnabled $false

# ENABLE REMOTEMAILBOX
$KBGUsers = Get-ADUser -Filter 'enabled -eq $true' -SearchBase "OU=Personnel,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se" -prop *
$KBGUsers = Get-ADUser -Filter 'enabled -eq $true' -SearchBase "OU=Politician,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se" -prop *
$KBGUsers = Get-ADUser -Filter 'enabled -eq $true' -SearchBase "OU=Azure User,OU=Users,OU=Karlsborgs Turism AB,OU=Top,DC=kommun,DC=skovde,DC=se" -prop *

foreach ($mailbox in $KBGUsers){
    $SamAccountName = $mailbox.samaccountname
    $UPN = $mailbox.userprincipalname
    $RemoteMailbox = get-remotemailbox -identity $UPN
    if (!$RemoteMailbox) {
        Enable-RemoteMailbox -Identity $UPN -RemoteRoutingAddress "$SamAccountName@samarbete.mail.onmicrosoft.com" -PrimarySmtpAddress $upn
        Set-RemoteMailbox $upn -EmailAddresses @{add="$SamAccountName@samarbete.mail.onmicrosoft.com"}
        Write-Host "$upn -"$SamAccountName@samarbete.mail.onmicrosoft.com""
    }
    else {
        Write-host -ForegroundColor Green "Remotemailbox $upn already exists"
    }

}


# Get-RecoverableItems -Identity rolf.andersson@Karlsborgskommun.onmicrosoft.com

# Set-RemoteMailbox -identity $upn -RemoteRoutingAddress "$SamAccountName@samarbete.mail.onmicrosoft.com"



Disable-RemoteMailbox -Identity $UPN -Confirm:$false

$mailbox = get-aduser KBGSM56 -prop *


$ADUser = Get-ADUser -Filter {UserPrincipalName -eq $mailbox}
$SamAccountName = $ADUser.SamAccountName


Set-mailbox -UserPrincipalName $._PrimarySMTPAddress -PrimarySMTPAddress $._PrimarySMTPAddress}


KBG-visit.csv

# $users = Import-Csv -Path "C:\temp\KBG-visit.csv"
# $Users = Get-content -Path "C:\temp\KBG-personell.csv"
$Users = Get-content -Path "C:\temp\KBG-rest.csv"
$from = "noreply@skovde.se"
$Body = "Hejsan,
fredag den 31/3 kommer Karlsborgs gamla Office365-miljö att stängas. Det innebär att du efter detta datum inte längre kan nå den gamla miljön för att återfå saknade filer. Om du behöver hjälp med att flytta över filer (word, excel m.fl.) från till exempel Teams eller Sharepoint lägg ett ärende hos Servicedesk IT (https://support/) eller ring på 0500-49 8501 innan den 24e mars.

Guide hur du sparar ner filer från ett Team
https://guider.skovde.se/6102.guide

Länk till guideportalen
https://guider.skovde.se/portal/Karlsborgs%20migrering

Länk till Serviceportalen
https://support/

Hälsningar  
Karlsborgs kommun i samarbete med IT-avdelningen i Skövde"

foreach ($user in $users) {
    $To = $user
    # $To = $user.OldUPN
    # $CC = "adam.nilsson@skovde.se"
    # $File = ""
    $options = @{
        'SmtpServer' = "smtp.skovde.se" 
        'To'         = "$To"
        # 'CC'          = "$CC"
        'From'       = "$From"
        'Subject'    = "Information gällande Office 365 migrering"
        'Body'       = "$Body"
        # 'Attachments' = "$File"
    }
    Send-MailMessage @options -Encoding UTF8
    Write-Host -ForegroundColor Yellow "Sending to $To"
}
