#requires -version 3.0
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
#
# 2019-06-28 Adam Nilsson - Initial coding

param(
    [Parameter(Mandatory=$true)]
    [string] $File
)

$adniadm =  (Get-StoredCredential -Target adni0510-adm)
ConnectExO
ConnectMSOL
Clear-Host
$Users = Get-Content -Path $File
foreach ($user in $users) {
    $ADUser = Get-ADUser -Identity $User -Credential $adniadm
    $UPN = Get-MsolUser -UserPrincipalName $ADUser.UserPrincipalName
    If (Get-mailbox -Identity $User -ErrorAction SilentlyContinue){
        Write-Host -ForegroundColor Yellow "$User is already in Exchange Online." -ErrorAction Stop
    }
    Else {
        If (!($UPN.IsLicensed -eq 'True')) {
        Write-host -ForegroundColor Yellow "$User is missing license, aborting." -ErrorAction Stop
    }
        Else {
            New-MoveRequest -Identity $user -Remote -RemoteHostName webmail.skovde.se -TargetDeliveryDomain samarbete.mail.onmicrosoft.com -RemoteCredential $adniadm -BadItemLimit 50
            Write-host -ForegroundColor Yellow "Migrating $user to Exchange Online."
        }
    }
}
Get-MoveRequest -MoveStatus Inprogress | Get-MoveRequestStatistics | Format-Table alias, statusdetail, TotalmailboxSize, percentcomplete, bytestrans* -AutoSize
Write-Host " "
Write-Host -ForegroundColor Yellow "Disconnecting Exchange Online..."
Get-PSSession | Remove-PSSession