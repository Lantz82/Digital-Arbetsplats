$myUsers = @("")
$myDistList = @("")

foreach ($user in $myUsers) {
    foreach ($dist in $myDistList) {
        Add-DistributionGroupMember -Identity $dist -Member $user
    }
}