############ Under uppbyggnad! 

param (	
	[string]$Displayname,
	[string]$Bolag,
	[string]$Email,
	[switch]$Hidden,
	[bool] $online = $false
)

if ($online -eq $true) {
	Write-Host -ForegroundColor Yellow "Connecting to Exchange Online..."
	if (!(Get-PSSession | Where-Object { $_.ConfigurationName -eq "Microsoft.Exchange" })) { 
		Connect-ExchangeOnline
	}
}
else {
	# Connect onprem
}

# function ValidateEmail {
# 	param([string]$Address)
# 	($Address -as [System.Net.Mail.MailAddress]).Address `
# 		-eq $Address -and $Address -ne $null
# }

if (($Name.Length -gt 64) -or ($Name.Length -lt 6)) {
	Write-Host "Namnet för maximalt vara 64 tecken långt och som kortast, inklusive 'Prefix' 6 tecken."
	exit
}

If ($Bolag -eq 'skövde') {
	$Bolag = 'skovde'
}
If ($Bolag -eq 'skovde' -or $Bolag -eq 'hjo' -or $Bolag -eq 'tibro' -or $Bolag -eq 'karlsborg' -and (!$Sektor)) {
	$Sektor = Read-Host -Prompt "Sektor?"
}
$CleanName = RemoveDiacritics $Displayname
switch ($Bolag) {
	'skovde' { $Name = "SK-FN-$Sektor-$CleanName"; $Email = $name + "@skovde.se" }
	'hjo' { $Name = "HJ-FN-$Sektor-$CleanName"; $Email = $name + "@hjo.se" }
	'tibro' { $Name = "TI-FN-$Sektor-$CleanName"; $Email = $name + "@tibro.se" }
	'karlsborg' { $Name = "KB-FN-$Sektor-$CleanName"; $Email = $name + "@karlsborg.se" }
	'SEAB' { $Name = "SEAB-FN-$CleanName"; $Email = $name + "@skovdeenergi.se" }
	'RÖS' { $Name = "SK-FN-ROS-$CleanName"; $Email = $name + "@rtos.se" }
	'MOS' { $Name = "SK-FN-MOS-$CleanName"; $Email = $name + "@miljoskaraborg.se" }
	'KOMF' { $Name = "SK-FN-KOMF-$CleanName"; $Email = $name + "@skaraborg.se.se" }
}
If (Get-Mailbox -Identity $Name -ErrorAction SilentlyContinue) {
	Write-Warning "$Name already exists, aborting." -ErrorAction Stop 
}
Else {
	Write-Host -ForegroundColor Yellow  "Creating new Distribution list $Name, please wait..."
	New-Mailbox -Name $Name -DisplayName $Name -PrimarySmtpAddress $Email -ManagedBy $Manager -MemberDepartRestriction Closed -MemberJoinRestriction Closed -Shared
	if ($Hidden) {
		Start-Sleep 10
		Set-Mailbox -Identity $Name -HiddenFromAddressListsEnabled $true
	}
	Start-Sleep 30
	If (Get-Mailbox -Identity $Name) {
		Write-Host -ForegroundColor Green "$Displayname is now created."
		Write-Host -ForegroundColor Green "Email address: $Email"
	}
	Else {
		Write-Warning "Something went wrong! Could not find resource $Displayname"
	}
}


<# Giltig epostadress eller? Loopa tills vi f�r en.
if (!($Email) -or !(ValidateEmail -Address $Email)) {
	Write-Host "Du måste ange en giltig e-postadress för FUNK-lådan." -fore Yellow;
	$alldone = $false;
	while (!($alldone)) {	
		$Email = Read-host "Ange önskad e-postadress för FUNK-Lådan: ";
		$tmp = @(Get-Mailbox -identity $Email -erroraction silentlycontinue);
		if ($tmp.Count -gt 0) {
			Write-Host "E-postadressen du angav finns redan." -fore Yellow;
			$alldone = $false;
		}
		else {
			if (ValidateEmail -Address $Email) {
				$alldone = $true;
			}
			else {
				Write-Host "E-postadressen du angav �r inte giltig." -fore Yellow;
				$alldone = $false;
			}
		}
	}
}

$Pre = ($Name.ToUpper()).Substring(0, 5)
$Post = ($Name.Substring(5, $Name.Length - 5))
$Name = $Pre + $Post;
$NameAlias = UtilFilterSwedish -string $(($Name -replace " ", "") -replace ",", "")
$Sam = $("FUNK" + $((Get-Date).ToString("yyMMddhhmmssff")))
$Secure_String_Pwd = ConvertTo-SecureString Generate-Password -asplaintext -force

if (!($Confirm)) {
	"
F�jande funktionsbrevl�da kommer att skapas i n�sta steg:

Namn:        {0}
Alias:       {1}
SAM:         {2}
Email:       {3}
Description: {4}
Dold:        {5}
" -f $Name, $NameAlias, $Sam, $Email, $Description, $Hidden
	if (!(Get-YesNo -Prompt "`nSkapa FUNK-l�dan med ovanst�ende v�rden? (y/n)")) {
		exit;
	}
}

New-Mailbox -Shared -Name $Name -Alias $NameAlias -OrganizationalUnit 'kommun.skovde.se/Top/Skovde/Exchange' -UserPrincipalName "$Name@kommun.skovde.se" -SamAccountName $Sam -FirstName "$Name" -Initials '' -LastName '' -PrimarySmtpAddress $Email -Password $Secure_String_Pwd -ResetPasswordOnNextLogon $false

#Routines for making sure AD object exists before proceeding. Waits a maximum of 60 seconds.
$nr_tries = 0;
Write-Host "`nSetting mailbox properties." -nonewline;
while ($nr_tries -lt 60) {
	$myerror = $false;
	# We'll try to get the group.. if it dont exist, wait 1 sec and try again
	if (!(Find-Objects -user $Name)) {
		$myerror = $true;
	}
	if (!(Get-Mailbox -Identity $Name -ErrorAction SilentlyContinue)) {
		$myerror = $true;
	}
	Write-Host "." -nonewline;

	# Paint a dot, or make counter fat and move on
	if (!($myerror)) {
		$nr_tries += 60;
	}
	else {
		$nr_tries ++;
		Sleep -seconds 1;
	}
}
Write-Host "`n"
Sleep 3
#>

