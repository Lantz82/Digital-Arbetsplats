# Simple send mail function from Onprem-Exchange
function Send-Mail {
    param (
        [Parameter(Mandatory)]
        [string] $Body,
        
        [Parameter(Mandatory)]
        [string] $Subject,
        
        [Parameter(Mandatory)]
        [string] $Recipient,
        
        [Parameter(Mandatory)]
        [string] $From,
        
        [string] $CC,
        
        [string] $File
    )
    
    $options = @{
        SmtpServer  = "smtp.skovde.se"
        To          = $Recipient
        From        = $From
        Subject     = $Subject
        Body        = $Body
        Encoding    = [System.Text.Encoding]::UTF8
    }
    if ($CC) {
        $options.CC = $CC
    }
    if ($File) {
        $options.Attachments = $File
    }
    
    Send-MailMessage @options
}
