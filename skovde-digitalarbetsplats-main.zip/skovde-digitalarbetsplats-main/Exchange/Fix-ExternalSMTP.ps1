ConnectExO
ConnectMSOL
$us = get-mailuser -ResultSize Unlimited | ? { $_.ExternalEmailAddress -like "*@samarbete.mail.onmicrosoft.com" } | % { Get-MsolUser -UserPrincipalName $_.UserPrincipalName } | ? { $_.islicensed -eq "True" }
$mailboxes = $us | Select -ExpandProperty UserPrincipalName

DCSession
ConnectEx

foreach ($mailbox in $mailboxes) {
    $Aduser = Get-ADuser -filter { emailaddress -eq $mailbox }
    If ($Aduser.Enabled -eq "true") {
        Disable-RemoteMailbox -Identity $mailbox -Confirm:$false
        Set-ADUser -Identity $Aduser.Name -EmailAddress $mailbox
        Write-Host -ForegroundColor Green "Remotemailbox $mailbox is now disabled"
        $FixdMailboxes += $mailbox
    }
    Else {
        Write-Host -ForegroundColor Yellow "ADUser $mailbox is not enabled"
    }
}
# Run delta sync
foreach ($FixdMailbox in $FixdMailboxes) {
    $ADuser = Get-ADuser -filter { emailaddress -eq $FixdMailbox }
    $Sam = $ADuser.SamAccountName
    Enable-RemoteMailbox -Identity $Sam -RemoteRoutingAddress "$Sam@samarbete.mail.onmicrosoft.com"
    Write-Host -ForegroundColor Green "Remotemailbox $mailbox is now enabled!"
}

# Enable remote-mailbox again
