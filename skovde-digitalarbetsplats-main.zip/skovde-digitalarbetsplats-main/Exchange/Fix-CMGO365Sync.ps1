#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
# Fix CMGsync
# 2019-10-25 Adam Nilsson - Initial coding
Param(
    [Parameter(Mandatory=$True)]
        [string]$Mailbox
)
ConnectExO
try {
    Get-mailbox -Identity $Mailbox -ErrorAction Stop
    Add-MailboxFolderPermission -Identity $Mailbox":\Calendar" -User "CMGO365Sync" -AccessRights Reviewer -ErrorAction SilentlyContinue
    Add-MailboxFolderPermission -Identity $Mailbox":\Kalender" -User "CMGO365Sync" -Accessrights Reviewer -ErrorAction SilentlyContinue
    Set-MailboxFolderPermission -Identity $Mailbox":\Calendar" -User Default -Accessrights LimitedDetails -ErrorAction SilentlyContinue
    Set-MailboxFolderPermission -Identity $Mailbox":\Kalender" -User Default -Accessrights LimitedDetails -ErrorAction SilentlyContinue
}
catch {
    Write-Warning "The mailbox $mailbox doesn't exist!"
    Exit
}