#requires -version 3.0
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
#
# 2019-11-26 Adam Nilsson - Initial coding
Param(
    [Parameter(Mandatory = $True)]
    [string]$Resurs,
    [Parameter(Mandatory = $False)]
    [string]$User,
    [Parameter(Mandatory = $False)]
    [string]$Group
)
$mailbox = Get-Mailbox -Identity $Resurs -ErrorAction SilentlyContinue
If (!$mailbox) {
    Write-Warning "$resurs not found"
    Exit
}
Else {
    $Kalender = Get-MailboxFolderStatistics $mailbox.primarysmtpaddress | where-object { $_.FolderType -eq "Calendar" } | select-Object Name
    Switch ($Kalender.name) {
        "Kalender" { $name = $resurs + ":\Kalender" }
        "Calendar" { $name = $resurs + ":\Calendar" }
    }
}
If ($User) { 
    Add-MailboxFolderPermission $name -User $User -AccessRights Editor | Out-Null
}
If ($Group) {
    $users = Get-ADGroupMember -Identity $group -Recursive | Get-ADUser -Properties Mail | Select-Object -ExpandProperty Mail
    $users | ForEach-Object { Add-MailboxFolderPermission $name -User $_ -AccessRights Editor } | Out-Null
}
Get-mailboxfolderpermission -Identity $name