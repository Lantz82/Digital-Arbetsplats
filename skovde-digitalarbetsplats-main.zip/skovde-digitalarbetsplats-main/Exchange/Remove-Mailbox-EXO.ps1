[CmdletBinding()]
param (
    [Parameter(Mandatory = $True)]
    [string]$user
)
ConnectMSOL
ConnectExO

# $User = "stwa1201@kommun.skovde.se"
$License = (Get-MsolUser -UserPrincipalName $user).Licenses.AccountSkuId
write-host "$License" -ForegroundColor Yellow
Set-MsolUserLicense -UserPrincipalName $user -RemoveLicenses $License
Start-Sleep 100
Set-User $user -PermanentlyClearPreviousMailboxInfo -Force -Confirm:$false
Start-Sleep 80
Set-MsolUserLicense -UserPrincipalName $user -AddLicenses $License
write-host "$user KLAR!" -ForegroundColor Green
