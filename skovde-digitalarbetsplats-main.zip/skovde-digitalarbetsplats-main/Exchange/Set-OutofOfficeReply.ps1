param(
    [Parameter(Mandatory = $true)]
    [string] $id,
    [Parameter(Mandatory = $true)]
    [string] $Message,
    [string] $StartDate,
    [string] $EndDate
)
Import-Module ExchangeOnlineManagement
Connect-ExchangeOnline

if (!$EndDate){
    $StartDate = Read-Host "Start date? (use the short date format mm/dd/yyyy, enter 09/01/2018 to specify September 1, 2018)"
    $EndDate = Read-Host "End date? (use the short date format mm/dd/yyyy, enter 09/01/2018 to specify September 1, 2018)"
}
$Confirm = Read-Host "Do you want to set auto reply message '$Message' between date $StartDate - $EndDate on mailbox '$id' ? [Y/N]"
Switch ($Confirm) {
    Y {
        Set-MailboxAutoReplyConfiguration -Identity $id -AutoReplyState Scheduled -StartTime $StartDate -EndTime $EndDate -InternalMessage $Message -ExternalMessage $Message
        Get-MailboxAutoReplyConfiguration -id $id
    }
    N {
        Write-Host -ForegroundColor Yellow "Aborted by user"
        Exit
    }
}