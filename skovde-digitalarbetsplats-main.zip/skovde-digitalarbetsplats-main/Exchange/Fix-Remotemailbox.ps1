#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
Param(
    [Parameter(Mandatory=$True)]
        [string]$File
)
$mailboxes = Get-Content -Encoding UTF8 $file
ConnectEx
foreach ($mailbox in $mailboxes) {
    $ADUser = Get-ADUser -Filter {UserPrincipalName -eq $mailbox}
    $SamAccountName = $ADUser.SamAccountName
    If (Get-Remotemailbox $mailbox){
        Disable-RemoteMailbox -Identity $mailbox -Confirm:$false
        Write-Host -ForegroundColor Yellow "Disableing RemoteMailbox for user $mailbox"
        Start-Sleep -Seconds 10
        Enable-RemoteMailbox -Identity $mailbox -RemoteRoutingAddress "$SamAccountName@samarbete.mail.onmicrosoft.com"
        Write-Host -ForegroundColor Yellow "Enabled RemoteMailbox for user $mailbox"
    }
    Else {
        Enable-RemoteMailbox -Identity $mailbox -RemoteRoutingAddress "$SamAccountName@samarbete.mail.onmicrosoft.com"
        Write-Host -ForegroundColor Yellow "Enabled RemoteMailbox for user $mailbox"
    }
}
Write-Host -ForegroundColor Green "Done! New RemoteMailbox for users 
$mailboxes"