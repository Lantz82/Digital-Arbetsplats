Param(
        [string]$File,
        [string]$Group
)
if ($file) {
    $groups = Get-Content $file
    Foreach ($group in $groups) {
        Get-ADGroup -Filter {name -eq $group} -Properties "extensionAttribute5" | Set-ADGroup -Add @{"extensionAttribute5"="NOSYNC"}
        Get-ADGroup -Filter {name -eq $group} -Properties "extensionAttribute5"
    }
}
else {
    Get-ADGroup -Filter {name -eq $group} -Properties "extensionAttribute5" | Set-ADGroup -Add @{"extensionAttribute5"="NOSYNC"}
    Get-ADGroup -Filter {name -eq $group} -Properties "extensionAttribute5"
}
