$boxes = Get-aduser -filter {displayname -like "253-*"} -Properties mail
$boxes | foreach {set-mailbox $_.mail -HiddenFromAddressListsEnabled $true}


#Connect to Exchange Online
Connect-ExchangeOnline -ShowBanner:$False
 
#Get All Microsoft 365 Groups created as part of Teams
$TeamsGroups = Get-UnifiedGroup -Filter {ResourceProvisioningOptions -eq "Team"} -ResultSize Unlimited
 
#Hide the gropus from GAL
ForEach ($Group in $TeamsGroups)
{
    If($Group.HiddenFromAddressListsEnabled -eq $False)
    {
        Set-UnifiedGroup -Identity $Group.ExternalDirectoryObjectId -HiddenFromExchangeClientsEnabled:$True -HiddenFromAddressListsEnabled:$True
        Write-Host "Group Set to Hidden from GAL:" $Group.DisplayName -f Green
    }
    If($Group.AccessType -eq "Public"){
        Set-UnifiedGroup -Identity $Group.ExternalDirectoryObjectId –AccessType Private
    }
}

# Get-UnifiedGroup -ResultSize Unlimited | Where-Object { $_.AccessType -eq 'Private' } | Set-UnifiedGroup -HiddenFromAddressListsEnabled $true
# Get-UnifiedGroup -ResultSize Unlimited | Where-Object {$_.AccessType -eq "Public"} | Set-UnifiedGroup –AccessType Private