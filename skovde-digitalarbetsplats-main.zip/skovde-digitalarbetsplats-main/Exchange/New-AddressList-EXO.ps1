$name = 'Skövde kommun'
$company = 'Hjo kommun'

New-AddressList –Name $name –RecipientFilter {((Department -eq "$company") -and (((((RecipientType -eq 'UserMailbox') -and (ResourceMetaData -like 'ResourceType:*'))) -and (ResourceSearchProperties -ne $null))))}
New-AddressList -Name $name -RecipientFilter {((Company -eq 'Skövde kommun') -and (RecipientType -eq 'UserMailbox'))}
Get-AddressList -Identity $name
Set-AddressList -Identity $name -RecipientFilter {((Department -eq "Skövde Stadshus") -and (((((RecipientType -eq 'UserMailbox') -and (ResourceMetaData -like 'ResourceType:*'))) -and (ResourceSearchProperties -ne $null))))}

Get-Recipient -Filter {((Company -eq 'Hjo kommun') -and (RecipientType -eq 'UserMailbox'))}