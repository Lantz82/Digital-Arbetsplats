# $mailbox = "anders.green@skovde.se"
$mailboxes = get-content "C:\temp\SSV-rest01.csv"

foreach ($mailbox in $mailboxes) {
    ConnectEx
    $onpremGUID = Get-Mailbox $mailbox | select ExchangeGUID
    DCSession
    # Get-MailUser -Identity $mailbox | fl displayname,ExchangeGuid
    ConnectExO
    Set-MailUser -Identity $mailbox -ExchangeGUID $onpremGUID.ExchangeGuid
    DCSession
}
