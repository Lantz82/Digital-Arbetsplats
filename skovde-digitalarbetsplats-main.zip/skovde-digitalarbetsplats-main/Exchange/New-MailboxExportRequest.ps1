#requires -version 3.0
param(
    [string] $user
)

ConnectEx
if(!$user){
    $user = Read-Host("Please provide a User")
}
# $user = 'test-adni0808'
$path = "\\tst-adni0510\share$\PST\$user.pst"
New-MailboxExportRequest -Mailbox $user -FilePath $path
Get-MailboxExportRequest -Mailbox $user | Format-List Name,FilePath,Mailbox,Status