Import-Module CredentialManager
$adni0510 =  (Get-StoredCredential -Target adni0510)

#Connect Exchange Online
$exchSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $adni0510 -Authentication Basic -AllowRedirection
Import-PSSession $exchSession -DisableNameChecking -AllowClobber
# $owner = Foreach ($manager in $managers) {Get-mailbox $manager | select DisplayName,PrimarySMTPAddress}

$id = "adni-dl-labb01"
$group = Get-DistributionGroup -Identity $id
$members = Get-DistributionGroupMember -Identity $id | select DisplayName,PrimarySMTPAddress
$managers = $group.ManagedBy
$owner = $managers | ForEach-Object {Get-mailbox $_ | select DisplayName,PrimarySMTPAddress}
$newgroup = "new-"+$group.Name
$newsmtp = "new-"+$group.PrimarySmtpAddress

New-DistributionGroup -Name $newgroup -DisplayName $newgroup -Alias $newgroup -PrimarySmtpAddress $newsmtp
$members | ForEach-Object {Add-DistributionGroupMember -Identity $newgroup -Member $_.PrimarySMTPAddress}
$owner | ForEach-Object {Set-DistributionGroup -Identity $newgroup -ManagedBy $_.PrimarySMTPAddress}
Remove-DistributionGroup -Identity $id
#Remove-ADGroup -Identity $id -WhatIf
Start-Sleep -Seconds 900
Set-DistributionGroup -Identity $newgroup -Name $group.Name -DisplayName $group.Name -Alias $group.Name -PrimarySmtpAddress $group.PrimarySmtpAddress
