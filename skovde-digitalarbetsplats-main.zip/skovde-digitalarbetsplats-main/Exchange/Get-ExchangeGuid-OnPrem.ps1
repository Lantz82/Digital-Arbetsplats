$userlist = Import-Excel -Path .\InData\20201126.xlsx

foreach ($users in $userlist){
    $username = $users.name
    Get-Mailbox -id $username | Select-Object Name, ExchangeGuid | Export-Csv -Path .\InData\Users_ExGuid_201126.csv -Append -Encoding UTF8
}