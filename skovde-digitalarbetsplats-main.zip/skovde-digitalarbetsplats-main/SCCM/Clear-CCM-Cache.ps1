#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
#
# 2019-08-16 Adam Nilsson - Initial coding
param(
    [Parameter(Mandatory = $True)]
    [string] $computer
)
function DeleteCCMCache {
    $resman = New-Object -ComObject "UIResource.UIResourceMgr"
    $cacheInfo = $resman.GetCacheInfo()
    $cacheinfo.GetCacheElements() | ForEach-Object { $cacheInfo.DeleteCacheElement($_.CacheElementID) }
}
$cred = Get-Credential
Invoke-Command -ComputerName $computer -Credential $cred -ScriptBlock ${function:DeleteCCMCache}