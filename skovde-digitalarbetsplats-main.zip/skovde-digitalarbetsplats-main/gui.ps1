<# This form was created using POSHGUI.com  a free online gui designer for PowerShell
.NAME
    Untitled
#>

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = '400,270'
$Form.text                       = "Form"
$Form.TopMost                    = $false

$TextBox1                        = New-Object system.Windows.Forms.TextBox
$TextBox1.multiline              = $false
$TextBox1.width                  = 264
$TextBox1.height                 = 20
$TextBox1.location               = New-Object System.Drawing.Point(14,96)
$TextBox1.Font                   = 'Microsoft Sans Serif,10'

$Search                          = New-Object system.Windows.Forms.Button
$Search.text                     = "Search"
$Search.width                    = 60
$Search.height                   = 30
$Search.location                 = New-Object System.Drawing.Point(14,148)
$Search.Font                     = 'Microsoft Sans Serif,10'

$Cancel                          = New-Object system.Windows.Forms.Button
$Cancel.text                     = "Cancel"
$Cancel.width                    = 60
$Cancel.height                   = 30
$Cancel.location                 = New-Object System.Drawing.Point(218,149)
$Cancel.Font                     = 'Microsoft Sans Serif,10'

$Datornamn                       = New-Object system.Windows.Forms.Label
$Datornamn.text                  = "Computername"
$Datornamn.AutoSize              = $true
$Datornamn.width                 = 25
$Datornamn.height                = 10
$Datornamn.location              = New-Object System.Drawing.Point(14,63)
$Datornamn.Font                  = 'Microsoft Sans Serif,10'

$Form.controls.AddRange(@($TextBox1,$Search,$Cancel,$Datornamn))




#Write your logic code here

[void]$Form.ShowDialog()