param(
    [Parameter(Mandatory = $true)]
    [string] $File,
    [Parameter(Mandatory = $true)]
    [string] $OutputPath,
    [Parameter(Mandatory = $true)]
    [string] $OutFile
)
$users = Get-content $File

Import-module Microsoft.Graph.Users
Import-module Microsoft.Graph.Identity.SignIns
$appid = 'f133d0fc-37a5-4140-ad70-e25469b4b41a'
$tenantid = '4c98088a-8771-4b89-86fa-342cf75f4e28'
$secret = '2-O8Q~xQOyZf~SqGoR8rh12NzDMhsFudWBk-2a9O'
 
$body = @{
    Grant_Type    = "client_credentials"
    Scope         = "https://graph.microsoft.com/.default"
    Client_Id     = $appid
    Client_Secret = $secret
}
 
$connection = Invoke-RestMethod `
    -Uri https://login.microsoftonline.com/$tenantid/oauth2/v2.0/token `
    -Method POST `
    -Body $body
 
$token = $connection.access_token
Connect-MgGraph -AccessToken $token

foreach ($UPN in $users) {
    $user = Get-mguser -UserId $UPN
    $AuthInfo = [System.Collections.ArrayList]::new()
    $UserAuthMethod = $null
    $UserAuthMethod = Get-MgUserAuthenticationMethod -UserId $user.id -ErrorAction SilentlyContinue
    if (!$UserAuthMethod) {
        Write-Host -ForegroundColor Yellow "No AuthenticationMethod found for $UPN..."
        Break
    }
    else {
        $object = [PSCustomObject]@{
            # DisplayName            = $user.Displayname
            userPrincipalName      = $user.userPrincipalName
            #UserType               = $user.UserType
            #AccountEnabled         = $user.AccountEnabled
            # id                     = $user.id
            #AuthMethods            = $UserAuthMethod
            #AuthMethodsCount       = ($UserAuthMethod).count
            #Phone                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.phoneAuthenticationMethod") { "Yes" } Else { "No" }
            MicrosoftAuthenticator = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod") { "Yes" } Else { "No" }
            #Email                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.emailAuthenticationMethod") { "Yes" } Else { "No" }
            HelloForBusiness       = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod") { "Yes" } Else { "No" }
            #fido2                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.fido2AuthenticationMethod") { "Yes" } Else { "No" }
            #Password               = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.passwordAuthenticationMethod") { "Yes" } Else { "No" }
            #passwordless           = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.passwordlessMicrosoftAuthenticatorAuthenticationMethod") { "Yes" } Else { "No" }
        }
        [void]$AuthInfo.Add($object)
        $AuthInfo | Export-Csv -Path "$OutputPath\$OutFile.csv" -Encoding "UTF8" -Delimiter ';' -Append
    }
}
Start-Process "$OutputPath\$OutFile.csv"