#Variable for SharePoint Online Admin Center URL
$AdminSiteURL = "https://samarbete-admin.sharepoint.com"
$CSVFile = "C:\Temp\OneDrives.csv"
  
#Connect to SharePoint Online Admin Center
Connect-SPOService -Url $AdminSiteURL
 
#Get All OneDrive Sites usage details and export to CSV
Get-SPOSite -IncludePersonalSite $true -Limit all -Filter "Url -like '-my.sharepoint.com/personal/'" | Select URL, Owner, StorageQuota, StorageUsageCurrent, LastContentModifiedDate | Export-Csv -Path $CSVFile -NoTypeInformation
Get-SPOSite -IncludePersonalSite $true -limit all  

Connect-PnPOnline -Url "https://samarbete.sharepoint.com"
Get-PnPTenantSite -IncludeOneDriveSites -Filter "Url -like '-my.sharepoint.com/personal/' -and Owner -eq 'adam.nilsson@skovde.se'"


Connect-SPOService -Url "https://samarbete-admin.sharepoint.com"


$Users = Get-ADUser -filter { Company -eq "Skövde" -and extensionAttribute1 -eq "Student" -and Userprincipalname -notlike "DEV-*" -and enabled -eq "true"} -Properties Userprincipalname, DisplayName
$Result = $null
$Result = @()
ForEach ($User in $Users) {
    $userUPN = $User.Userprincipalname
    $UserDisplayname = $User.DisplayName
    $UserURL = $User.SamAccountName
    
    # $OneDrive = Get-SPOSite -IncludePersonalSite $True -Limit All -Filter "Url -like '-my.sharepoint.com/personal/' -and Owner -eq '$($userUPN)'"
    try {
        Write-Host "Getting $userUPN OneDrive sites..."
        $OneDrive = Get-SPOSite -Id "https://samarbete-my.sharepoint.com/personal/$($UserURL)_skovde_se"
        $OneDrive = [PSCustomObject]@{
            Email       = $OneDrive.Owner
            DisplayName = $UserDisplayname
            URL         = $OneDrive.URL
            QuotaGB     = [Math]::Round($OneDrive.StorageQuota / 1024, 3) 
            UsedGB      = [Math]::Round($OneDrive.StorageUsageCurrent / 1024, 3)
            PercentUsed = [Math]::Round(($OneDrive.StorageUsageCurrent / $OneDrive.StorageQuota * 100), 3)
        }
        $Result += $OneDrive
    }
    catch {
        Write-Host "No OneDrive for User $userUPN" -fore red
    }    
}
$Result | ft DisplayName, Email, URL, UsedGB, QuotaGB, PercentUsed -AutoSize
$Result | Export-Csv -Path C:\temp\onedrive.csv -NoTypeInformation -Encoding UTF
# 
$Mbxs = $users | Get-EXOMailbox
$j = $Mbxs.Count
$Result = @()
For ($i = 0; $i -lt $j; $i++){
    $Stats = $Mbxs[$i] | Get-EXOMailboxStatistics
    $MbxInfo = [PSCustomObject] @{
        UPN                     = $Mbx.UserPrincipalName
        DisplayName             = $Stats.DisplayName
        TotalItemSize           = $Stats.totalitemsize.value.ToBytes()
        ItemCount               = $Stats.ItemCount
        TotalDeletedItemSize    = $Stats.TotalDeletedItemSize.value.ToBytes()
    }
    $Pct = [int]($i / $j * 100)
    Write-Progress -Activity "Retrieving stats." -Status "$Pct% Complete:" -PercentComplete ($Pct)
    $Result += $MbxInfo
}
Write-Host
$Result | ft UPN,DisplayName,TotalItemSize,ItemCount,TotalDeletedItemSize -AutoSize