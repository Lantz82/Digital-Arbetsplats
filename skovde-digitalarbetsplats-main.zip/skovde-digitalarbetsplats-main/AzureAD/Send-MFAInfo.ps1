
# $users = Get-adgroupmember -identity "User-MFA-NotEnabled"
$users = "adni0510"
foreach ($user in $users) {
    $u = Get-aduser -identity $user -prop mail
    $body = "
    Hej!
    Du behöver aktivera din MFA-app. Hur du gör detta kan du se i guiden nedan
    https://guider.skovde.se/5286.guide
    
    Ta gärna kontakt med Servicedesk IT om du har några frågor.
    0500-49 85 01"
    $To = $u.mail
    $options = @{
        'SmtpServer' = "smtp.skovde.se" 
        'To'         = $To
        #'CC'         = $CC
        'From'       = "Servicedesk-IT@skovde.se"
        'Subject'    = "Du behöver aktivera din MFA-app" 
        'Body'       = "$body"
    }
    Send-MailMessage @options -Encoding UTF8
}