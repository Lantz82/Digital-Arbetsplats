Connect-AzureAD
$users = Import-Csv -Path "C:\temp\Users.csv"

$results = $Users | ForEach-Object {
    $user = Get-AzureADUser -ObjectId $_.UserPrincipalName

    $licenses = Get-AzureADUser -ObjectId peter.lantz@skovde.se | select AssignedLicenses 
    [PSCustomObject]@{
        UserPrincipalName = $user.UserPrincipalName
        AssignedLicenses  = $licenses.AccountSkuId
    }
}

$results | Export-Csv -Path "C:\temp\UsersLicenses.csv" -NoTypeInformation

Connect-MsolService
$results = $LovUsers | ForEach-Object {
    Get-MsolUser -UserPrincipalName $_.UserPrincipalName | Format-List DisplayName, Licenses
} 
$results | out-file c:\temp\LOV.csv
| Export-Csv -Path "C:\temp\UsersLicenses.csv" -NoTypeInformation