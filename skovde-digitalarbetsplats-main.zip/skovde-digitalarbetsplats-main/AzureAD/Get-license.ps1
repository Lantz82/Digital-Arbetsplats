# Must be run in Powershell 5.1 or else you can't get account creation date
# Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

$maximumfunctioncount = 8192

# Install-Module Microsoft.Graph -Scope CurrentUser -Force -AllowClobber
Import-Module Microsoft.Graph
Connect-MgGraph -Scopes "Directory.Read.All", "User.Read.All", "AuditLog.Read.All"
Select-MgProfile -Name "Beta"

# Uncomment the license SKU

# F3 License
# $LicenseSku = 'SPE_F1'

# Office 365 A1 
# $LicenseSku = 'STANDARDWOFFPACK_FACULTY'

# Office 365 A3 
# $LicenseSku = 'ENTERPRISEPACKPLUS_FACULTY'

# Office 365 E3 
# $LicenseSku = 'ENTERPRISEPACK'

# Office 365 E1
# $LicenseSku = 'STANDARDPACK'

# Use this to check for the license SKU
# Get-MgSubscribedSku -All -Select SkuPartNumber, SkuId, SkuPartNumber, ConsumedUnits | Format-List

# Get the assigned users details & exports as a CSV file
$licenseDetails = Get-MgSubscribedSku -All | Where-Object SkuPartNumber -eq $LicenseSku
Get-MgUser -Filter "assignedLicenses/any(x:x/skuId eq $($licenseDetails.SkuId) )" -ConsistencyLevel eventual -All | Export-Csv -Path "C:\temp\LiceneUsers.csv"

# Imports the above CSV file
$UserCSVExtract = Import-Csv -Path "C:\temp\LiceneUsers.csv"

# This is the final CSV file that is created with the user UPN + last sign-in date + account creation date
$FinalCSVName = 'c:\temp\License ' + $LicenseSku + '.csv'

$Result = @()
foreach ($user in $UserCSVExtract) {
    $usersignindate = Get-MgUser -UserId $user.ID -Select SignInActivity | Select-Object -ExpandProperty SignInActivity
    $userprops = [ordered]@{
        UserPrincipalName   = $user.UserPrincipalName
        LastSignInDateTime  = $usersignindate.LastSignInDateTime
        AccountCreationDate = $user.CreatedDateTime
    }

    $userObj = new-object -Type PSObject -Property $userprops
    $Result += $userObj | Export-csv -Path $FinalCSVName -Append
}
$Result



# 
Import-Module AzureAD
Connect-AzureAD
foreach ($user in $users) {
    Get-AzureADUserLicense -ObjectId $user -AssignedLicenses
}

Get-AzureADUser -ObjectId adam.nilsson@skovde.se | select *
$Users = Get-aduser -filter { (Office -eq "BUF") -and (Enabled -eq $true) } | select -ExpandProperty Userprincipalname

foreach ($user in $users) {
    Get-MsolUser -UserPrincipalName $user | Where-Object { $_.Licenses.AccountSkuId -match "ENTERPRISEPACKPLUS_FACULTY" } | Select-Object UserPrincipalName
}

Get-MsolUser | Where-Object { $_.Licenses.AccountSkuId -eq "your_license_sku_id" } | Select-Object UserPrincipalName, Licenses

Get-MSOLUser -All | where { $_.isLicensed -eq $true } | select DisplayName, userprincipalname, islicensed, { $_.Licenses.AccountSkuId } | Export-CSV c:\O365UserList.csv –NoTypeInformation


# Install the Azure AD module if not already installed
# You can run this command if the module is not installed:
# Install-Module -Name AzureAD

# Import the Azure AD module
Import-Module AzureAD

# Connect to your Azure AD tenant
Connect-AzureAD

# Specify the license name you want to retrieve
$targetLicenseName = "ENTERPRISEPACKPLUS_FACULTY"

# Get a list of users
$users = Get-AzureADUser -All $true

# Loop through each user and check for the target license
foreach ($user in $users) {
    # Get the user's licenses
    $userLicenses = Get-AzureADUserLicense -ObjectId $user.ObjectId

    # Loop through each license and check if the target license exists
    foreach ($license in $userLicenses) {
        if ($license.SkuPartNumber -like $targetLicenseName) {
            Write-Output "User $($user.DisplayName) has the $targetLicenseName license."
            # If you want to retrieve additional information about the license, you can access properties like $license.SkuId, $license.SkuPartNumber, etc.
        }
    }
}

# Disconnect from Azure AD
Disconnect-AzureAD

function Get-KBG-LicensReport {
    Import-Module AzureAD
    Connect-AzureAD
    $date = Get-Date -Format yyyy-MM-dd
    # AzureAD Group: KBG-LIC-A3F
    Get-AzureADGroupMember -ObjectId "cc7c0ea0-c5ed-422d-8807-c740b861dddb" -All $true | Where-Object { $_.Userprincipalname -like "*karlsborg.se" } | select -ExpandProperty Userprincipalname | Out-File C:\Temp\$Date-A3-Karlsborg-Personal.csv
    # AzureAD Group: KBG-LIC-A3S
    Get-AzureADGroupMember -ObjectId "3540db29-3a2d-4213-96c6-5216fac6f7d6" -All $true |  Where-Object { $_.Userprincipalname -like "*edu.karlsborg.se" } | select -ExpandProperty Userprincipalname | Out-File C:\Temp\$Date-A3-Karlsborg-Elev.csv
}

#Converts to array
$Report = @("C:\Temp\$Date-A3-Karlsborg-Personal.csv")
$AnotherReport = "C:\Temp\$Date-A3-Karlsborg-Elev.csv"
$Report += $AnotherReport

# $file = 
$body = "
Rapport se bifogad fil
MVH"
$To = "adam.nilsson@skovde.se"
$options = @{
    'SmtpServer'  = "smtp.skovde.se" 
    'To'          = $To
    #'CC'         = $CC
    'From'        = "Servicedesk-IT@skovde.se"
    'Subject'     = "$Date-A3-Karlsborg-Rapport" 
    'Body'        = "$body"
    'Attachments' = $report
}
Send-MailMessage @options -Encoding UTF8

