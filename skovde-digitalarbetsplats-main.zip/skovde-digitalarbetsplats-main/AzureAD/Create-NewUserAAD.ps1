Connect-AzureAD
$Users = Import-Csv -Path "C:\Temp\kbg02.csv"

$PasswordProfile = New-Object -TypeName Microsoft.Open.AzureAD.Model.PasswordProfile
$PasswordProfile.Password = "Admin1122!%"

foreach ($user in $users) {
    New-AzureADUser -DisplayName $user.Displayname -UserPrincipalName $user.UserPrincipalName -MailNickName $user.MailNickName -PasswordProfile $PasswordProfile -AccountEnabled $true
}
