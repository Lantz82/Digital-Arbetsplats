Import-Module AzureAD
$Cred = Get-StoredCredential -Target "BitTitanKBG"
Connect-AzureAD -Credential $Cred
$Date = Get-date -format yyyy-MM-dd
$logs = Get-AzureADAuditSignInLogs -Filter "createdDateTime gt $date"
$logs | Group-Object -Property UserPrincipalName | Select-Object -ExpandProperty Name | Out-File C:\Logs\Karlsborgskommun\"$date-AzureADAuditSignInLogs.log"