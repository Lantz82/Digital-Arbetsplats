ConnectMSOL
Get-MsolAccountSku
$user = "test-adni0404@hjo.se"
$E1 = "samarbete:STANDARDPACK"
$E3 = "samarbete:ENTERPRISEPACK"
$A1 = "samarbete:STANDARDWOFFPACK_FACULTY"
$A3 = "samarbete:ENTERPRISEPACKPLUS_FACULTY"
$NewLicens = $A1

$MsolUser = Get-MsolUser -UserPrincipalName $user
$OldLicens = $MsolUser.Licenses
Set-MsolUserLicense -UserPrincipalName $user -RemoveLicenses $OldLicens.AccountSkuId
Start-Sleep 10
Set-MsolUserLicense -UserPrincipalName $user -AddLicenses $NewLicens
Get-MsolUser -UserPrincipalName $user | fl UserPrincipalName,Licenses