Import-Module CredentialManager
$o365admin =  (Get-StoredCredential -Target o365admin)

Connect-AzureAD -Credential $o365admin
Connect-MsolService -Credential $o365admin

$user = 'anna.probin@skovdeenergi.se'
Get-AzureADUser -ObjectId $user | Select *
Get-MsolUser -UserPrincipalName $user | ft DisplayName,Licenses