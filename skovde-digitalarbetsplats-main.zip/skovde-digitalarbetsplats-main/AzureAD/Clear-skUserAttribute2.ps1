Get-aduser "DIST-SBU-Elevhälsan-chefer" -prop * | Set-ADUser -Clear extensionAttribute5 -WhatIf

Get-aduser -Filter {name -eq "DIST-SBU-Elevhälsan-chefer"} -prop * | Set-ADUser -Clear extensionAttribute5 -WhatIf
skUserAttribute2

Get-ADGroup -Filter {Name -like "SK-DL-SBU-Timmersdala*"} -prop extensionAttribute5 | Set-ADGroup -Clear extensionAttribute5

$list =  Get-content "C:\temp\DL-SBU-ROS01.csv"
$list | ForEach-Object {Get-ADGroup -Filter {Name -like $_} -prop extensionAttribute5} | Set-ADGroup -Clear extensionAttribute5


