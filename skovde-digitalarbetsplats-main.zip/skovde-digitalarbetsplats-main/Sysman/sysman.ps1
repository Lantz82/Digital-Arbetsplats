
$CompName = "SKLABB01"
$Mac = "00:50:56:82:A2:F1"
$Uuid = "31E10242-CF4A-D443-BEDC-A9A72E24B025"
$Serial = "VMware-42 02 e1 31 4a cf 43 d4-be dc a9 a7 2e 24 b0 25"
# $AssetTag = "" #Inget fält vi använder(?)
$Description = "Labbdator"
$Model = "VMware7,1"
# $OperatingSystemId = "20" #Sätts via mallen istället
$DeploymentTemplateToUse = "190"
$mycreds = (Get-StoredCredential -Target "SKOVDE\Srvc-SysmanService")
$SysManUrl = "http://srv-ekl-apps01/sysman"

# Ta bort objektet om det redan finns?
Try {

    $Remove = (Invoke-RestMethod -Uri "$($SysManUrl)/api/Client?name=$CompName" -Method Get -Credential $mycreds -ContentType "application/json").id

    IF ($Remove) {
        $Target = "{
          ""targets"": [
            $Remove
              ],
          ""deleteInAd"": true,
          ""disableInAd"": false,
          ""deleteInSccm"": true,
          ""deleteInSysman"": true,
          ""disableInSysMan"": false,
        }"

        Invoke-RestMethod -Method Delete -Body $Target -Uri "$($SysManUrl)/api/Client" -ContentType "application/json" -Credential $mycreds
        Start-Sleep 60
    }
}
Catch {}

# Hämta Hardware model ID
$MIDs = (Invoke-RestMethod -Uri "$($SysManUrl)/api/HardwareModel?name=$Model&Take=1&Skip=0" -Method Get -Credential $mycreds -ContentType "application/json").result.id

$body = @{
    Name        = $CompName
    Mac         = $Mac
    Uuid        = $Uuid
    Serial      = $Serial
    AssetTag    = $AssetTag
    Description = $Description
    Model       = $MIDs
    OverWrite   = $true
}
# Skapa datoroobjektet i Sysman
Invoke-RestMethod -Uri "$($SysManUrl)/api/Client" -Body (ConvertTo-Json $body) -Method Post -ContentType "application/json" -Credential $mycreds

# Hämta datorobjektets ID
$CompIDs = (Invoke-RestMethod -Uri "$($SysManUrl)/api/Client?name=$CompName&Take=1&Skip=0" -Method Get -Credential $mycreds -ContentType "application/json").result.id
            
$body = @{
    ClientId                = $CompIDs
    DeploymentTemplateToUse = $DeploymentTemplateToUse
    ExecuteDate             = [System.DateTime]::Now.ToString("o")
    # OperatingSystemId       = $OperatingSystemId
    InstallationType        = 1
}

# Skapa installationsjobbet
Invoke-RestMethod -Uri "$($SysManUrl)/api/client/Deployment" -Body (ConvertTo-Json $body) -Method PUT -ContentType "application/json" -Credential $mycreds


$Computer = Invoke-RestMethod -Uri "$($SysManUrl)/api/Client?name=$CompName" -Method Get -Credential $mycreds -ContentType "application/json"
$Computer.deployment.deploymentTemplate.name
# $Roller = $dator.roles.name