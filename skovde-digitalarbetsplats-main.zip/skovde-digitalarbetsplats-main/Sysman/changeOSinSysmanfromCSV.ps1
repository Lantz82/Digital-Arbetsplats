<#
    Sets OperatingSystemId in SysMan via API call
    based on CSV file (Name, OSID headers).
    Supports -WhatIf
    Sassan Fanai
    2022-12-02 - Version 0.1
#>

[CmdletBinding(SupportsShouldProcess)]
param (
    [string]$SysManUrl = "https://sysman.kommun.skovde.se/SysMan",
    [string]$CSVFile = "C:\Temp\Sysman\ComputerSysmanImport.csv",
    [string]$LogPath = "C:\Temp\Sysman",
    [string]$Delimeter = ","
)

function WriteLog {
    param(
    [Parameter(Mandatory)]
    [string]$LogText,
    $Component,
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet('Info','Warning','Error','Verbose')]
    [string]$Type,
    [string]$LogFileName,
    [string]$FileName
    )

    switch ($Type)
    {
        "Info"      { $typeint = 1 }
        "Warning"   { $typeint = 2 }
        "Error"     { $typeint = 3 }
        "Verbose"   { $typeint = 4 }
    }

    $time = "$(Get-Date -Format HH:mm:ss).$((Get-Date).Millisecond)+000"
    $date = Get-Date -f "MM-dd-yyyy"
    $ParsedLog = "<![LOG[$($LogText)]LOG]!><time=`"$($time)`" date=`"$($date)`" component=`"$($Component)`" context=`"`" type=`"$($typeint)`" thread=`"$($pid)`" file=`"$($FileName)`">"
    $ParsedLog | Out-File -FilePath "$LogFileName" -Append -Encoding utf8 -WhatIf:$false
}

# Log variables and params
$Self = "SysMan-SetOS.ps1"
$LogFile = "$LogPath\$($Self.Replace(".ps1", ".log"))"

$LogParams =  @{
    FileName = $Self
    LogFileName = $LogFile
    Component = "PowerShellScript"
}

try {
    $Msg = "Importing CSV from [$CSVFile]"
    Write-Output $Msg
    WriteLog $Msg @LogParams -Type Info
    $FullCSV = Import-Csv -Path $CSVFile -Encoding utf8 -Delimiter $Delimeter
    $NumberOfComps = ($FullCSV | Measure-Object).Count
}
catch {
    $Msg = "Problem importing CSV file [$CSVFile]"
    Write-Output $Msg
    WriteLog $Msg @LogParams -Type Error
    Write-Error "Problem importing CSV file [$CSVFile]" -ErrorAction Stop
}

$Comps = 0
foreach ($Line in $FullCSV) {
    $Comps++
    Remove-Variable SysManClient, CompName, OperatingSystemID -ErrorAction Ignore -Force -WhatIf:$false
    $CompName = $($Line.Name)
    $OperatingSystemID = $($Line.OSID)
    $Msg = "$($Line.Name) - Processing $Comps / $NumberOfComps"
    Write-Output $Msg
    WriteLog $Msg @LogParams -Type Info
    try {
        $SysManClient = Invoke-RestMethod -Uri "$($SysManUrl)/api/v2/client/find?name=$($CompName)" -Method GET -ContentType "application/json" -UseDefaultCredentials
    }
    catch {
        $Msg = "$($Line.Name) - could not get client info from SysMan"
        Write-Output $Msg
        WriteLog $Msg @LogParams -Type Error
        continue
    }

    $Msg = "$($Line.Name) - Current OSID [$($SysManClient.operatingSystem.id)] OSName [$($SysManClient.operatingSystem.name)]"
    Write-Output $Msg
    WriteLog $Msg @LogParams -Type Info

    if ($SysManClient.operatingSystem.id -ne $OperatingSystemID) {
        $Msg = "$($Line.Name) - Current OperatingSystemID [$($SysManClient.operatingSystem.id)] is not the same as specified OperatingSystemID [$OperatingSystemID]. Proceeding with ImportComputerDetails API call"
        Write-Output $Msg
        WriteLog $Msg @LogParams -Type Info
        $b3 = @{
            clients = @(
                @{
                    clientName = $CompName
                    operatingSystemId = $OperatingSystemID
                }
            )
            source = "Script"
        } | ConvertTo-Json

        try {
            if ($PSCmdlet.ShouldProcess("$($CompName)","Set OperatingSystemID $($OperatingSystemID)")) {
                $result = Invoke-RestMethod -Uri "$($SysManUrl)/api/v2/client/ImportComputerDetails" -Body $b3 -Method POST -ContentType "application/json" -UseDefaultCredentials
            }
            Start-Sleep 1
            $SysManClient = Invoke-RestMethod -Uri "$($SysManUrl)/api/v2/client/find?name=$($CompName)" -Method GET -ContentType "application/json" -UseDefaultCredentials
            $Msg = "$($Line.Name) - Current OSID [$($SysManClient.operatingSystem.id)] OSName [$($SysManClient.operatingSystem.name)]"
            Write-Output $Msg
            WriteLog $Msg @LogParams -Type Info
            }
        catch {
            $Msg = "$($Line.Name) - ERROR: $($PSItem.Exception.Message)"
            Write-Output $Msg
            WriteLog $Msg @LogParams -Type Error
            continue
        }
    }
    else {
        $Msg = "$($Line.Name) - Current OperatingSystemID [$($SysManClient.operatingSystem.id)] is the same as specified OperatingSystemID [$OperatingSystemID]. Skipping ImportComputerDetails API call"
        Write-Output $Msg
        WriteLog $Msg @LogParams -Type Info
    }
}
