<#
Install-Module CredentialManager
$o365admin =  (Get-StoredCredential -Target tst-adni0510)


New-MoveRequest -Identity adni-labb-room2 -Remote -RemoteHostName webmail.skovde.se -TargetDeliveryDomain samarbete.mail.onmicrosoft.com -BadItemLimit 50
Get-MoveRequest


Add-MailboxPermission –Identity ansa0117 –User adni0510 –AccessRights FullAccess –InheritanceType All –Automapping $false

Get-MailboxPermission -Identity ansa0117

Remove-MailboxPermission -Identity ansa0117 -User adni0510 -AccessRight FullAccess -InheritanceType All

Get-MailboxDatabase | Get-MailboxStatistics | Where { $_.DisconnectReason -eq "Disabled" }


Enable-RemoteMailbox -Identity 'HJ-FN-Stadsbibliotek' -RemoteRoutingAddress 'HJ-FN-Stadsbibliotek@samarbete.onmicrosoft.com'

HJ-FN-Stadsbibliotek@samarbete.onmicrosoft.com

$password = get-content "C:\Script\cred.txt" | convertto-securestring
$UserCredential = new-object -typename System.Management.Automation.PSCredential -argumentlist "adni0510-adm@samarbete.onmicrosoft.com", $password
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $exadmin -Authentication Basic -AllowRedirection
Install-PSSession $Session -DisableNameChecking -AllowClobber

New-AddressList -Name "Långgatan" -DisplayName "Långatan 18" -RecipientFilter {((Department -eq 'Långgatan') -and (((RecipientType -eq 'UserMailbox') -and (ResourceMetaData -like 'ResourceType:*') -and (ResourceSearchProperties -ne $null))))}

Get-AddressList

Get-AddressList -Identity "Långgatan" | Format-List Name,RecipientFilterType,RecipientFilter,IncludedRecipients,Conditional*
$lang = Get-AddressList -Identity "Långgatan"; Get-Recipient -ResultSize unlimited -RecipientPreviewFilter $lang.RecipientFilter | select Name,PrimarySmtpAddress,HiddenFromAddressListsEnabled

Get-InboxRule -Identity 'HJ-FN-AoS-Arbete och Socialtjänst'

$mailbox = read-Host 'Mailbox address:'
Get-InboxRule -Mailbox $mailbox | Select Name, Description, Enabled | FL


Install-Module -Name SkypeOnlineConnector
Install-Module -Name MicrosoftTeams
$socSession = New-CsOnlineSession -Credential $mycred
Install-PSSession $socSession -AllowClobber

$user = 'mathias.mellberg@skovdeenergi.se'
Grant-CsTeamsUpgradePolicy -PolicyName IslandsWithNotify -Identity $user

$objUsers = Get-CSOnlineUser | select UserPrincipalName, teamsupgrade*
$objusers | ConvertTo-Html | Out-File "$env:USERPROFILE\desktop\TeamsUpgrade.html"

Get-CSOnlineUser -user adam.nilsson@skovde.se

New-CsOnlineSession -Credential $UserCredential -Verbose

$user = 'test-fn-adni'
New-MoveRequest -Identity $user -Remote -RemoteHostName webmail.skovde.se -TargetDeliveryDomain samarbete.mail.onmicrosoft.com -RemoteCredential $UserCredential -BadItemLimit 50
Get-MoveRequest | where status -eq 'InProgress'

Set-MailboxFolderPermission sk-rs-svo-garage3":\calendar" -user Default -AccessRights Reviewer

Install-Module ServerManager
Add-WindowsFeature -Name "RSAT-AD-Powershell" -IncludeAllSubFeature

Install-Module ActiveDirectory

$acctName = "TeamsAutomation@samarbete.onmicrosoft.com"
$sfboSession = New-CsOnlineSession -UserName $acctName
Install-PSSession $sfboSession

Get-DistributionGroup -Identity 'dist-lonnen'
New-DistributionGroup -Name 'adni-test0303' -DisplayName 'adni-test0303' -Alias 'adni-test0303' -PrimarySmtpAddress

Set-DistributionGroup -Identity adni-test0303 -EmailAddresses
Add-DistributionGroupMember -identity 'adni-test0303' -member 'test-adni0404'


$KlassTeams = Get-UnifiedGroup -ResultSize Unlimited | where { $_.Alias -like "Section*" }
$PersonalTeams = Get-UnifiedGroup -ResultSize Unlimited | where { $_.Alias -like "Team_*" }

$politik = Get-Mailbox -resultsize unlimited | where {($_.PrimarySmtpAddress -like "*@politiker.hjo.se")} | select DisplayName, PrimarySmtpAddress
$politik | Out-File C:\temp\politiker-hjo.csv


New-MoveRequest -Identity maer112001 -Remote -RemoteHostName webmail.skovde.se -TargetDeliveryDomain samarbete.mail.onmicrosoft.com -RemoteCredential (Get-Credential)  -BadItemLimit 50
Get-MoveRequest -MoveStatus Inprogress | Get-MoveRequestStatistics | ft alias, statusdetail, TotalmailboxSize, percentcomplete, bytestrans* -AutoSize

Get-Mailbox 'test-fn-adni04' | fl ExchangeGuid


Add-MailboxPermission -Identity Mailboxname  -User Username -AccessRight FullAccess  -Automapping $false

Add-MailboxFolderPermission -Identity "cindy.petersson@skovde.se:\kalender" -User "CMGO365Sync@samarbete.onmicrosoft.com" -AccessRights Reviewer
get-mailbox cindy.petersson@skovde.se

get-mailbox SK-RS-UTR-Robot 


$mailbox = Get-Mailbox -resultsize unlimited | where {($_.PrimarySmtpAddress -like "*@skovdeenergi.se")} | select PrimarySmtpAddress
$mailbox | Out-File C:\temp\skovdeenergi.csv


Get-Mailbox -SoftDeletedMailbox | Select-Object Name,ExchangeGuid | fl

Get-Mailbox -Identity SK-FN-SEAB-Faktura | Format-List ExchangeGuid
Get-Mailbox -SoftDeletedMailbox | FL Name,DistinguishedName,ExchangeGuid,PrimarySmtpAddress

New-MailboxRestoreRequest -SourceMailbox edc589c0-fc24-4a0e-a428-bce6422a1e02 -TargetMailbox 551277c4-5ffa-4d02-ad9f-bf6c890d2618 -AllowLegacyDNMismatch


Get-Mailbox SK-FN-SEAB-Faktura | fl ExchangeGuid


get-aduser SK-RS-MÖS-BIL-Ford Kuga KLU957 -Properties *

#Connect Exchange Online
$exchSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $o365admin -Authentication Basic -AllowRedirection
Install-PSSession $exchSession -DisableNameChecking -AllowClobber

# Connect SkypeOnline
$sfbSession = New-CsOnlineSession -Credential $o365admin
Install-PSSession $sfbSession -AllowClobber

# Connect AzureAD
Connect-AzureAD -Credential $o365admin
$group = Get-AzureADGroup -SearchString "SK-SSV-TM-Team Champions"
$members = Get-AzureADGroupMember -ObjectId $group.ObjectId -All $true | Where-Object {$_.ObjectType -eq "User"}
$members | ForEach-Object {Grant-CsTeamsAppSetupPolicy -PolicyName "HR App Setup Policy" -Identity $_.EmailAddress}

$group = Get-UnifiedGroup -Identity SK-SSV-TM-TeamChampions@samarbete.onmicrosoft.com
$members = Get-UnifiedGroupLinks -Identity SK-SSV-TM-TeamChampions@samarbete.onmicrosoft.com -LinkType Members
$members | ForEach-Object {Grant-CsTeamsAppSetupPolicy -PolicyName "Team-champs"}

jost0329@kommun.skovde.se

$team = Get-Team -DisplayName "Enhet Teknik"
New-TeamChannel -GroupId $team.GroupId -DisplayName "NEW-channel"
$team | New-TeamChannel -DisplayName "NYARE" - 


get-aduser skthak -prop skUserAttribute2 | Set-ADUser -Clear skUserAttribute2

$lo = Get-ADUser -Filter {skUserAttribute2 -eq "NOSYNC"} -SearchBase "OU=Personnel,OU=Hjo,OU=Top,DC=kommun,DC=skovde,DC=se" -prop skUserAttribute2
$lo.Count
$g = Get-ADGroupMember -Identity "ORG-SSE-Avdelning Skövde VA" -Recursive

Install-Csv -Path \\tst-adni0510\share$\dubbla.csv | foreach {get-aduser $_.name} | select UserPrincipalName | Export-CSV c:\tmp\allinfo.csv -NoTypeInformation
Install-Csv -Path \\tst-adni0510\share$\dubbla.csv | ForEach {Get-ADUser -Filter {mail -eq $_.mail} -Properties name, emailAddress, SAMAccountName | Select Name, emailAddress, SamAccountName | Export-CSV c:\tmp\allinfo.csv -NoTypeInformation}

Set-AzureADUser -ObjectId "d95b489c-877e-4f37-ac61-1455f5a58778" -UserPrincipalName " jofr111201@tibro.se"
Set-MsolUserPrincipalName -UserPrincipalName "jofr1112016570@samarbete.onmicrosoft.com" -NewUserPrincipalName "Johan.Fransson@tibro.se"



Get-ADUser -filter {displayname -like "Linda Batshon*"}
Get-aduser adni0510 -Properties * | select "*sip*"


Add-ADGroupMember -Identity 'U-Apps-ClaroReadPro7.3.7.i' -Members (Get-ADGroupMember -Identity 'Apps-SvenskTalteknologi-ClaroRead-TI' -Recursive)

$u = get-aduser -Filter {skUserAttribute2 -eq "NOSYNC"} -prop skUserAttribute2 -SearchBase 'OU=Personnel,OU=Tibro,OU=Top,DC=kommun,DC=Skovde,DC=se'
$u | Set-ADUser -Clear skUserAttribute2


get-aduser jofr111201 -prop skUserAttribute2 | Set-ADUser -Clear skUserAttribute2


Connect-AzureAD -Credential $o365admin
Connect-MsolService -Credential $o365admin
Get-AzureADUser -ObjectId 'antonia.lagerin_tibro.se#EXT#@samarbete.onmicrosoft.com' | Select *
Get-MsolUser -UserPrincipalName 'antonia.lagerin@tibro.se' | ft DisplayName,Licenses

Get-CalendarProcessing "TI-RS-RUM-Socialkontoret-Blåa rummet:\kalender"


Get-MailboxFolderPermission -Identity "TI-RS-RUM-Socialkontoret-Blåa rummet:\calendar"

| FL AllB*,AllR*,BookInP*,Req*,Res*
Get-Mailbox "sk-rs-stadshus-rum-sessionssalen" | Format-List Name,AuditEnabled


$guests = Get-AzureADUser -Filter "UserType eq 'Guest'" -All $true | Where-Object {$_.mail -like "*@tibro.se"}
$guests | %{Remove-AzureADUser -ObjectId $_.UserPrincipalName}
Remove-AzureADUser -ObjectId 'anneli.koivuniemi_tibro.se#EXT#@samarbete.onmicrosoft.com'

Get-Mailbox TI-RS-RUM-BUN-Näringslivetshus-Björken | fl ExchangeGuid

$pass = Read-Host "Enter Password" -AsSecureString

Set-Mailbox -Identity “SEAB-RS-RUM-TEAMSRUMMET@skovdeenergi.se” -EnableRoomMailboxAccount $true -RoomMailboxPassword $pass


Connect-EXOPSSession 
Connect-MsolService
Install-Module SkypeOnlineConnector
$skype = New-CsOnlineSession
Install-PSSession $skype -AllowClobber

Enable-CsMeetingRoom -Identity "SEAB-RS-RUM-TEAMSRUMMET@samarbete.onmicrosoft.com" -SipAddressType "EmailAddress" -RegistrarPool "sippoolDB41E03.infra.lync.com"
Get-MsolUser -UserPrincipalName "SEAB-RS-RUM-TEAMSRUMMET@samarbete.onmicrosoft.com"



$users = Get-Mailbox -ResultSize unlimited 

$users = get-aduser -Filter {mail -like "*@skovdeenergi.se"} -prop mail
get-aduser -Filter {mail -like "*@skovdeenergi.se"} -prop mail | %{get-mailbox $_.mail}

foreach ($user in $users) {
    $email = (Get-Mailbox $user.mail).EmailAddresses | Where-Object {$_.ProxyAddressString -like '*@skovde.se'}
}
foreach ($user in $users) {
    $email = (Get-Mailbox $user.mail).EmailAddresses | Where-Object {$_.ProxyAddressString -like '*@skovde.se'}
    Set-Mailbox $user.mail -EmailAddresses @{remove="$($email.smtpaddress)"} -WhatIf
}


Get-CsMeetingRoom -id "Adams-labb500@samarbete.onmicrosoft.com"
Enable-CsMeetingRoom -Identity "SEAB-RS-RUM-TEAMSRUMMET@samarbete.onmicrosoft.com" -SipAddressType "EmailAddress" -RegistrarPool sippoolDB41E03.infra.lync.com
Disable-CsMeetingRoom -Identity "SEAB-RS-RUM-TEAMSRUMMET@samarbete.onmicrosoft.com"



Get-AzureADMSDeletedGroup
Restore-AzureADMSDeletedDirectoryObject -Id 36984938-b6bd-4325-8ba6-4f0414d0cd68
Get-AzureADGroup -ObjectId 36984938-b6bd-4325-8ba6-4f0414d0cd68

$RES = "adam-labb222"
New-Mailbox -Equipment -Name $RES -ResourceCapacity '4' -DisplayName $RES -Alias $RES -FirstName $RES -LastName "" -Initial "" -PrimarySmtpAddress "$RES@skovde.se"


Get-TransportConfig | Select *MaxRecip*
Get-ReceiveConnector -Identity "ReceiveConnectorName" | Select *MaxRecip*

Get-TransportConfig | fl maxreceivesize,maxsendsize

Get-MailboxPlan | fl name,maxsendsize,maxreceivesize,isdefault

Get-Mailbox fredrik.edholm@skovde.se | fl mailboxplan,maxsendsize,maxreceivesize

Get-Mailbox -ResultSize unlimited -Filter {RecipientTypeDetails -eq "SharedMailbox"} | Get-MailboxPermission -Identity Firstname.Lastname@domain.com | select identity, user, accessrights, displayname
Get-Recipient -ResultSize Unlimited | where{$_.RecipientTypeDetails -eq "SharedMailbox"} | ft name, manager

Get-Mailbox -ResultSize unlimited | Get-MailboxPermission -user "adam.nilsson@skovde.se" | Where {($.AccessRights -eq "FullAccess") -and -not ($.User -eq "NT AUTHORITY\SELF")} | Format-Table Identity,User
Get-MailboxFolderPermission -User "adam.nilsson@skovde.se"


Get-ADGroupMember -Identity fldrti-t-tibrosoc-socpoolvakans -Recursive | Where-Object { $_.objectClass -eq 'user' } | Get-ADUser -Properties DisplayName, Name | Select DisplayName, Name | Export-Csv -NoTypeInformation -Encoding UTF8 -Path C:\temp\lista.csv



Set-Location "\\kommun.skovde.se\ConfigMgr\Content\application\DinaFastigheter"
Copy-Item -Path "\\kommun.skovde.se\ConfigMgr\Content\application\DinaFastigheter\Minhyra.exe.lnk" -Destination "$env:UserProfile\desktop"


Enable-RemoteMailbox -Identity anpr072501 -RemoteRoutingAddress 'anpr072501@samarbete.mail.onmicrosoft.com'


robocopy "\\tst-adni0510\share$" c:\dummy /l /xj /e /nfl /ndl /njh /r:0 /mt:64

$adniadm =  (Get-StoredCredential -Target adni0510-adm)
$ExchangeSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://srv-exc04/PowerShell/ -Authentication Kerberos -Credential $adniadm
Install-PSSession $ExchangeSession -DisableNameChecking


$users = get-content C:\temp\list.csv
$adniadm =  (Get-StoredCredential -Target adni0510-adm)
ConnectExO
foreach ($user in $users) {
    New-MoveRequest -Identity "Socialnamnden@skovde.se" -Remote -RemoteHostName webmail.skovde.se -TargetDeliveryDomain samarbete.mail.onmicrosoft.com -RemoteCredential $adniadm -BadItemLimit 50
    Write-host -ForegroundColor Yellow "Migrating $user to Exchange Online."
}



$us = get-mailuser -ResultSize Unlimited | ?{$_.ExternalEmailAddress -like "*@samarbete.mail.onmicrosoft.com"} | %{Get-MsolUser -UserPrincipalName $_.UserPrincipalName} | ?{$_.islicensed -eq "True"}
$hjo = Get-mailbox -ResultSize unlimited | ?{$_.EmailAddresses -like "*@hjo.se"}

$u = Get-mailuser "Anette.Andersson1@hjo.se" 
| fl ExternalEmailAddress

$us | %{get-mailuser -Identity $_.Name} | fl PrimarySmtpAddress
$us | %{Get-MsolUser -UserPrincipalName $_.UserPrincipalName} | ft userprincipalname,islicensed 
>> C:\temp\users2.csv


Set-adUser -Identity "FUNK11012109481601" -UserPrincipalName "info@miljoskaraborg.se"


New-MailboxExportRequest -Mailbox "test-adni05101" -FilePath "\\tst-adni0510\share$\PST\test-adni05101.pst"
Enable-RemoteMailbox -Identity "joan0201" -RemoteRoutingAddress "joan0201@samarbete.mail.onmicrosoft.com"


Write-Host "Running installation script
***************************************************
*          DreamFactory Dev Team (c) 2019         *
*                                                 *
* Package name: SMSEagle software update: 3.4     *
* Package version: 1.0                            *
* Package description:                            *
*   - Check our webpage for full information:     *
*     https://www.smseagle.eu/software-updates    *
***************************************************"



$name = "SK-RS-KAVELBRO-BUSS-Renault OBH 855"
$group = "SK-DL-SBU-Kavelbro Personal sektor Caroline Hägglund, enhet 881"
$group = "SK-DL-SBU-Kavelbro Personal sektor Sofia Hottöfjäll, enhet 882"
Set-CalendarProcessing -Identity $Name -BookInPolicy $group 
Get-CalendarProcessing -id  $name

$o365admin = (Get-StoredCredential -Target o365admin)
Connect-SPOService -Url "https://gymnasiumskovde-admin.sharepoint.com" -Credential $cred

$cred = Get-Credential "adni0510-adm@gymnasiumskovde.se"
Revoke-SPOUserSession -User "andu1226@edu.skovde.se" -Confirm:$false


Enable-RemoteMailbox -Identity anod021101 -RemoteRoutingAddress "anod021101@samarbete.onmicrosoft.com"
#>

$file = "C:\Temp\DL-SBU-ROS01.csv"
$dist = Get-DistributionGroup -filter { name -like "SK-DL-RÖS*" } | select name
$dist | Export-Csv $file -Encoding UTF8 -NoTypeInformation -Append
Sleep 5
$dist2 = Get-Content -Encoding UTF8 $file
$dist2.Replace('","', ",").TrimStart('"').TrimEnd('"') | Out-File $file -Force -Confirm:$false


Set-RemoteMailbox chwi101601 -PrimarySmtpAddress "Charlotta.Widman@tibro.se"
Enable-remotemailbox chwi101601 -pri


Enable-RemoteMailbox -Identity "chwi101601" -RemoteRoutingAddress "chwi101601@samarbete.mail.onmicrosoft.com"

-PrimarySmtpAddress "Charlotta.Widman@tibro.se" -WhatIf


Get-UnifiedGroup -ResultSize Unlimited | Where-Object { $_.AccessType -eq 'Private' } | Set-UnifiedGroup -HiddenFromAddressListsEnabled $true


$oldGUID = get-mailbox "yasa1268" -SoftDeletedMailbox
$newGUID = get-mailbox "yasa120801"
New-MailboxRestoreRequest -SourceMailbox "bba1a93b-b4ff-4cf1-bad6-f6479021e39f" -TargetMailbox "d1d79f57-f945-42c9-8495-0de2eb48a647" -AllowLegacyDNMismatch -verbose
Get-MailboxRestoreRequest


Install-Module -Name ActiveDirectory
Install-Module -Name CredentialManager
Install-Module -Name AzureAD
Install-Module -Name MSOnline
Install-Module -Name SkypeOnlineConnector
Install-Module -Name MicrosoftTeams


New-DistributionGroup -name "SK-DL-SSV-Kvalitetsnätverk" -DisplayName "SK-DL-SSV-Kvalitetsnätverk" -Alias "SK-DL-SSV-Kvalitetsnatverk" -PrimarySmtpAddress "SK-DL-SSV-Kvalitetsnatverk@skovde.se" -OrganizationalUnit "kommun.skovde.se/Top/Skovde/Exchange"

Add-ADGroupMember -Identity 'SK-DL-SSV-Vunätverk-1-2016718091' -Members (Get-ADGroupMember -Identity 'SK-DL-VUnätverk-1-174721318' -Recursive)


Get-GlobalAddressList | update-GlobalAddressList


$users = Get-ADGroupMember -Identity "org-ssb" -Recursive
$users | Get-aduser -Properties mail | select mail >> C:\Temp\org-ssv-mail.csv


Get-ADGroupMember -Identity $group -Recursive | foreach { get-aduser $_.name -prop mail, description, office } | select mail, description, office | Export-Csv -Path $file -NoTypeInformation -Encoding UTF8

$u = get-content C:\temp\teams.txt
$u | foreach { get-aduser $_.userprincipalname }

$u | foreach { get-mailbox $_ } | select WindowsEmailAddress | Export-Csv -Path C:\temp\teams4.csv -NoTypeInformation -NoClobber -Append
Out-file c:\temp\teams2.txt -Append
Export-Csv -Path C:\temp\teams2.csv -NoTypeInformation


$dist = Get-DistributionGroup -Filter { (name -like "SK-DL-SBU*") -and (grouptype -eq "Universal, SecurityEnabled") } | select name | Export-Csv "C:\temp\DL-SBU-REST002.csv" -Encoding UTF8


Get-Mailbox -RecipientTypeDetails UserMailbox, SharedMailbox -ResultSize Unlimited | Get-MailboxPermission -User "SK-FN-SBU-Procapita_gymn_Vux"
Get-MailboxPermission -Identity "SK-FN-SBU-Procapita_gymn_Vux" | Select user, accessrights


New-DistributionGroup "Skövde Energi konferensrum" –RoomList
Remove-DistributionGroup SkoevdeEnergi@samarbete.onmicrosoft.com
Add-DistributionGroupMember -Identity "Skövde Energi konferensrum" -Member "SK-RS-RUM-Skövdenät-Ljuspunkten"
Get-DistributionGroup -Identity "Skövde Energi konferensrum"

Set-DistributionGroup -DisplayName "Skövde Energi konferensrum"

Get-DistributionGroup | Where { $_.RecipientTypeDetails -eq "RoomList" } | Format-Table DisplayName, Identity, PrimarySmtpAddress


Get-IRMConfiguration
Test-IRMConfiguration -Sender "adam.nilsson@skovde.se"

get-mailbox adam.nilsson@skovde.se | fl Audit*
udittOwner, AuditAdmin, AuditDeligate


Get-AzureADDevice -filter { displayname -like "*adnroid*" }

Get-AzureADDevice -All $true | where { $_.displayname -like "*android*" }
Set-AzureADDevice 

function ConnectExchangeOnline () {
    # Connect Exchange Online
    $o365cred = Credential
    $sessExchange = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $o365cred -Authentication Basic -AllowRedirection
    Import-PSSession $sessExchange -DisableNameChecking -AllowClobber
}



$credential = Get-Credential
$credential.Password | ConvertFrom-SecureString | Set-Content "$PSHome\passwords\srvc-exchange.txt"


#>

$encrypted = Get-Content "$PSHome\passwords\srvc-exchange.txt" | ConvertTo-SecureString
$credential = New-Object System.Management.Automation.PsCredential("srvc-exchange@samarbete.onmicrosoft.com", $encrypted)





$group = New-DistributionGroup "Room 221 Booking Allowed"
$members = @()
$members += "karina@contoso.com", "tony@contoso.com"
$members = $members | Get-Mailbox
Add-DistributionGroupMember -Identity $group -Members $members -BypassSecurityGroupManagerCheck:$true

$resurs = "Teamsrum"
$group = "SEAB-DL-Personal"
Set-CalendarProcessing -Identity $resurs -AutomateProcessing AutoAccept -BookInPolicy $group -AllBookInPolicy $false
Get-CalendarProcessing $resurs | fl book*


Get-MailboxFolderStatistics -Identity "adam.nilsson@skovde.se" | where-object { $_.FolderType -eq "Calendar" } | select-Object Name






# Ny sökväg 2019-01-21
xcopy \\srv-tk-apps21\cadra_share\Cadra2013\Databas\Skovde.sqlite D:\MG_Data\Database\ /Y

Robocopy "\\srv-tk-apps21\cadra_share\Cadra2013\Databas\Skovde.sqlite" "D:\MG_Data\Database\" /B
Stop-service -Name "InfrastructureMapServer2015"
Restart-service -Name "IISAdmin"
Start-service -Name "InfrastructureMapServer2015"
"D:\MG_Data\FDOConnection\CadxxExportGeoJSON.exe" / Cadra /Run
"D:\MG_Data\FDOConnection_Opto\CadxxExportGeoJSON.exe" / Cadra /Run



$newRoom = "SK-RS-STADSHUS-RUM-Routern@samarbete.onmicrosoft.com"
$name = "Routern"
$pass = "AAbb1122"
$license = "samarbete:STANDARDPACK"
$regpool = "sippoolDB41E03.infra.lync.com"
New-Mailbox -MicrosoftOnlineServicesID $newRoom -Name $name -Room -RoomMailboxPassword (ConvertTo-SecureString -String $pass -AsPlainText -Force) -EnableRoomMailboxAccount $true
Start-Sleep -Seconds 30
Set-MsolUser -UserPrincipalName $newRoom -PasswordNeverExpires $true -UsageLocation "SE"
Set-MsolUserLicense -UserPrincipalName $newRoom -AddLicenses $license
Start-Sleep -Seconds 600
Enable-CsMeetingRoom -Identity $newRoom -SipAddressType "EmailAddress" -RegistrarPool $regpool

Get-CsOnlineUser -Identity $newRoom
Set-CsMeetingRoom -Identity $newRoom -SipAddressType "EmailAddress" -RegistrarPool $regpool

$name = "253-2010 Gruppkonto"
get-mailbox -filter "name -like '253-2010 Gruppkonto'" -ResultSize:Unlimited

Get-mailbox -Filter 


Get-UnifiedGroup -ResultSize Unlimited | Where-Object { $_.AccessType -eq 'Private' } | Set-UnifiedGroup -HiddenFromAddressListsEnabled $true


Set-Mailbox -Identity "Hubben" -EnableRoomMailboxAccount $true -RoomMailboxPassword (ConvertTo-SecureString -String "AAbb1122" -AsPlainText -Force)


Enable-CsMeetingRoom -Identity "SK-RS-STADSHUS-RUM-Hubben@skovde.se" -SipAddressType "EmailAddress" -RegistrarPool $regpool



$Mailboxes = Get-Mailbox -ResultSize Unlimited -Filter { (EmailAddresses -like "*tibro.se") }
Foreach ($Mailbox in $Mailboxes) {
    Add-MailboxFolderPermission -Identity $Mailbox":\Calendar" -User "CMGO365Sync" -Accessrights Reviewer
    Add-MailboxFolderPermission -Identity $Mailbox":\Kalender" -User "CMGO365Sync" -Accessrights Reviewer
    Set-MailboxFolderPermission -Identity $Mailbox":\Calendar" -User Default -Accessrights Reviewer
    Set-MailboxFolderPermission -Identity $Mailbox":\Kalender" -User Default -Accessrights Reviewer
}




$body = $us | Select-Object UserPrincipalName | Out-String
$options = @{
    'SmtpServer' = "smtp.skovde.se" 
    'To'         = "adam.nilsson@skovde.se" 
    'From'       = "Servicedesk-IT@skovde.se" 
    'Subject'    = "TEST" 
    'Body'       = "testar" 
}
Send-MailMessage @options

enable-RemoteMailbox -Identity "kalle.j.svensson@skovde.se" -RemoteRoutingAddress "kasv031602@samarbete.mail.onmicrosoft.com"



$users = "Lars Börjesson", "Anna-Lena Nilsson", "Lars Karlsson", "Jonas Kedén", "Anton Hall"
Lars K

$sam = $users | % { Get-Aduser -filter { displayname -like $_ } } | Select-Object -ExpandProperty SamAccountName

foreach ($usr in $users) {
    Get-ADUser -Filter { Displayname -like $usr } | select SamAccountName
}


Set-DistributionGroup "SK-DL-SMS-Arrangemang" -ManagedBy "test-adni0202@skovde.se" -BypassSecurityGroupManagerCheck
New-ADGroup -Name "RODC Admins" -SamAccountName RODCAdmins -GroupCategory Security -GroupScope Global -DisplayName "RODC Administrators" -Path "CN=Users,DC=Fabrikam,DC=Com" -Description "Members of this group are RODC Administrators"
New-ADGroup -Name "User-Win10-Search-Fix" -GroupCategory Security  -GroupScope Global -Path "OU=Groups,OU=Top,DC=kommun,DC=skovde,DC=se"

ergu0704

Grant-CsTeamsUpgradePolicy -PolicyName UpgradeToTeams -Identity mabl0324@kommun.skovde.se

$cal = "sk-rs-svo-bollen:\calendar"
Get-MailboxFolderPermission -Identity $cal
Add-MailboxFolderPermission -Identity $cal -User "piwa0410" -AccessRights Reviewer
Set-MailboxFolderPermission -Identity "sk-rs-svo-garage5:\kalender" -User Default -AccessRights Reviewer

SK-RS-SMS-AME-RUM-GesällgSammanträdesrummet

SK-RS-SMS-AME-RUM-GesällgKreativaRummet

"garage 3"
sk-rs-svo-garage3@skovde.se


Add-ADGroupMember -Identity 'User-OnedriveFolderRedirect-Samarbete' -Members $users
$users = $HasLicens | % { get-aduser -Filter { mail -eq $_ } } | select -ExpandProperty name

$rtosusers = Get-adgroupmember -id "DL19101506332233"

| Export-Csv -Path "C:\temp\ROSUsers.csv" -NoTypeInformation
| % { get-aduser -Filter { name -eq $_ } } | select -ExpandProperty name

$ros = $rtosusers | % { Get-ADUser -Filter { name -eq $_.name } } | select -ExpandProperty userprincipalname | Out-String

$mailboxar = $ros | % { get-mailbox -Filter -PrimarySmtpAddress -eq $_ }



$members = (Import-Csv -Path "C:\temp\ros002.csv")
$members = get-content "C:\temp\ros03.txt"
$rosusers = Get-ADUser -filter { mail -like "*rtos.se" } | select -ExpandProperty name

foreach ($member in $members) {
    Add-DistributionGroupMember -Identity "SK-DL-RÖS" -Member $member
}


$resourses = @('HJ-RS-BILPOOL-Renault-Elbil-YOY855', 'HJ-RS-BILPOOL-Toyota-NHJ407', 'HJ-RS-BILPOOL-Toyota-Kombi-FXU865', 'HJ-RS-BILPOOL-TOYOTA-DUJ64S', "HJ-RS-BILPOOL-Renault-AME-NXP828", "HJ-RS-BIL-LSSbilen HDC770", "HJ-RS-BIL-Resurs och Biståndsenheten BDK34K")

foreach ($res in $resourses) {
    Set-CalendarProcessing -Identity $res -AutomateProcessing None
}

Get-adgroupmember -id "Comp-Horizon-ITklient" | select -ExpandProperty name | Out-File C:\temp\itklient.txt


$pass = "AAbb1122!!"
Set-Mailbox -Identity "RES-SOF-RUM-Rosenhagascenrummet@kommun.skovde.se" -EnableRoomMailboxAccount $true -RoomMailboxPassword (ConvertTo-SecureString -String $pass -AsPlainText -Force) 
Enable-CsMeetingRoom -Identity "SK-RS-SOF-RUM-Rosenhaga scenrummet" -SipAddressType EmailAddress -RegistrarPool "sippoolne01e01.infra.lync.com"


$user = "Ulrica.Johansson@skovde.se"
Ulrica.Johansson
Johan.Ask
$user
Get-MailboxFolderPermission -Identity $user':\kalender' -User Default
Get-MailboxFolderPermission -Identity $user':\calendar' -User Default

Set-MailboxFolderPermission -Identity $user':\kalender' -User Default -AccessRights "LimitedDetails"
Set-MailboxFolderPermission -Identity $user':\calendar' -User Default -AccessRights "LimitedDetails"

Katarina.Jonsson@skovde.se


$users = Get-adgroupmember -id "DL19101506374706" | % { get-aduser $_.name } | select -ExpandProperty userprincipalname

$SKOU = "OU=Students,OU=Skovde,OU=Top,DC=kommun,DC=skovde,DC=se"
$TIOU = "OU=Students,OU=Tibro,OU=Top,DC=kommun,DC=skovde,DC=se"
$HJOU = "OU=Students,OU=Hjo,OU=Top,DC=kommun,DC=skovde,DC=se"

$SkovdeStudents = Get-ADUser -Filter { extensionAttribute1 -eq 'Student' } -SearchBase $SKOU | Select-Object -ExpandProperty UserPrincipalName
$TibroStudents = Get-ADUser -Filter { extensionAttribute1 -eq 'Student' } -SearchBase $TIOU | Select-Object -ExpandProperty UserPrincipalName
$HjoStudents = Get-ADUser -Filter { extensionAttribute1 -eq 'Student' } -SearchBase $HJOU | Select-Object -ExpandProperty UserPrincipalName

Get-CsUserPolicyAssignment -Identity t081110emjo@tibro.se

$user_ids = Get-Content C:\temp\users_ids.txt

New-CsBatchPolicyAssignmentOperation -PolicyType TeamsMessagingPolicy -PolicyName $null -Identity $TibroStudents -OperationName "Unassign tibro student policy02"
Get-CsBatchPolicyAssignmentOperation

Set-Mailbox adam.nilsson@skovde.se -AuditEnabled $true -AuditLogAgeLimit 365

Search-MailboxAuditLog adam.nilsson@skovde.se -ShowDetails -StartDate 09/01/2021 -EndDate 09/06/2021

Set-CsTeamsMessagingPolicy -Identity 
Grant-CsTeamsMeetingPolicy -Identity fredrik.edholm@skovde.se  -PolicyName $null


Import-Module ActiveDirectory

$path = "\\share-secure\secure\"
$user = KBGLECO1228
$fullPath = $path + $user

if (-not (Test-Path -LiteralPath $fullPath)) {

    try {
        New-Item -Path $fullPath -ItemType Directory 
    }

    catch {
        "Cannot create foler", "fullPath = $fullPath" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber 
        break
    }

    try {
        $acl = Get-Acl $fullPath
        $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("SKOVDE\$user", "Modify", "ContainerInherit,Objectinherit", "none", "Allow")
        $acl.SetAccessRule($accessRule)
        Set-Acl -Path $fullPath -Aclobject $acl
    }

    catch {
        "Cannot set ACL", "user= $user", "fullPath = $fullPath" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber
        break
    }

    try {
        Add-ADGroupMember -Identity User-Netshare-Secure -Members $user
    }

    catch {
        "Cannot add $user to group" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber
        break
    }

}
else {
    "Folder exists", "fullPath = $fullPath" | Out-File -FilePath C:\Temp\Secure_store\lagring-$user.txt -Append -NoClobber 
}


$exo = Get-Mailbox -RecipientTypeDetails SharedMailbox -ResultSize Unlimited
$exo | Get-RecipientPermission -Trustee adam.nilsson@skovde.se
Get-RecipientPermission


$users = Get-ADUser -Filter * -SearchBase "OU=Personnel,OU=Skovde,OU=Top,DC=kommun,DC=skovde,DC=se" -Properties mail | select mail


$Teams = Get-Team | ? { $_.MailNickName -Like "SK-*" -or $_.MailNickName -Like "TM-SK-*" }
$teams | select MailNickName | Export-CSV -Path C:\temp\Teams-skovde2.csv -NoTypeInformation -Encoding UTF8

| Out-File -FilePath C:\temp\sk-teams.txt

Get-MsolUser -UserPrincipalName adam.nilsson@skovde.se | Where-Object { ($_.licenses).AccountSkuId -match "yammer" }


$user = "mathias.mellberg@skovdeenergi.se"


Ulrica.Johansson
Johan.Ask
$user

$user = "mathias.mellberg@skovdeenergi.se"

$SEAB = Get-adgroupmember -id "ORG-SEAB-Skövde Energi" -Recursive | select -ExpandProperty name

$SEAB = Get-exomailbox -resultsize unlimited -Filter { EmailAddresses -like "*skovdeenergi.se" }

$seab | Get-MailboxFolderStatistics -FolderScope Calendar | Where-Object { $_.foldertype -eq "calendar" }

foreach { $user in $seab } {
    Get-MailboxFolderPermission -Identity $user':\kalender' -User Default
    Get-MailboxFolderPermission -Identity $user':\calendar' -User Default
}


$SEAB = Get-exomailbox -resultsize unlimited -Filter { EmailAddresses -like "*skovdeenergi.se" }
foreach ($user in $seab) {
    $mail = $user.PrimarySmtpAddress
    $mail | Out-File C:\temp\SEAB001.txt -Append
    Get-ExoMailboxFolderPermission -Identity $mail':\kalender' -User Default -ErrorAction SilentlyContinue | Out-File C:\temp\SEAB002.txt -Append
    Get-ExoMailboxFolderPermission -Identity $mail':\calendar' -User Default -ErrorAction SilentlyContinue | Out-File C:\temp\SEAB002.txt -Append
}

Get-MailboxFolderPermission -Identity $_':\kalender' -User Default; Get-MailboxFolderPermission -Identity $_':\calendar' -User Default


$Allusers = Get-Mailbox -Resultsize Unlimited

Foreach ($Mailbox in $Allusers) {
    $result += Get-MailboxFolderPermission -Identity $Mailbox":\Calendar" | select identity, User, AccessRights, SharingPermissionFlags
}


$result | Export-Csv -Path c:\users.csv -Encoding ascii -NoTypeInformation


$CmpName = "\`d.T.~Ed/{4844E5B8-AAFA-4632-99D9-B061B7ABE7D4}.{1DE9F85E-7632-4753-871A-09D47C8108C0}\`d.T.~Ed/"
$Mac = "\`d.T.~Ed/{4844E5B8-AAFA-4632-99D9-B061B7ABE7D4}.{B4309FE0-8F6E-4927-A1B1-B376C7961965}\`d.T.~Ed/"
$Uuid = "\`d.T.~Ed/{4844E5B8-AAFA-4632-99D9-B061B7ABE7D4}.{7C316BEF-0AB5-42A6-ADCA-4BC5C1508B37}\`d.T.~Ed/"
$Serial = "\`d.T.~Ed/{4844E5B8-AAFA-4632-99D9-B061B7ABE7D4}.{7427972D-FE98-42E3-BDA1-49A7D2B046BF}\`d.T.~Ed/"
$AssetTag = "\`d.T.~Ed/{4844E5B8-AAFA-4632-99D9-B061B7ABE7D4}.{7427972D-FE98-42E3-BDA1-49A7D2B046BF}\`d.T.~Ed/"
$Description = "\`d.T.~Ed/{2BBD4863-1C0C-4901-832B-F7936CAFBB10}.SR\`d.T.~Ed/"
$Model = "\`d.T.~Ed/{4844E5B8-AAFA-4632-99D9-B061B7ABE7D4}.{12FF1517-BB80-4F14-8A93-9B9ABD5DD967}\`d.T.~Ed/"

###############################################
# Config Start
###############################################

$SysManUrl = "http://srv-ekl-apps01/sysman"
$UsrName = "SKOVDE\Srvc-SysmanService"
$UsrPW = ""
$secpasswd = ConvertTo-SecureString "$UsrPW" -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential ("$UsrName", $secpasswd)

###############################################
# Config End
###############################################

Try {

    $Remove = (Invoke-RestMethod -Uri "$($SysManUrl)/api/Client?name=$CmpName" -Method Get -Credential $mycreds -ContentType "application/json").id

    IF ($Remove) {
        $Target = "{
          ""targets"": [
            $Remove
              ],
          ""deleteInAd"": true,
          ""disableInAd"": false,
          ""deleteInSccm"": true,
          ""deleteInSysman"": true,
          ""disableInSysMan"": false,
        }"

        Invoke-RestMethod -Method Delete -Body $Target -Uri "$($SysManUrl)/api/Client" -ContentType "application/json" -Credential $mycreds
        Start-Sleep 60
    }
}
Catch {}


$MIDs = (Invoke-RestMethod -Uri "$($SysManUrl)/api/HardwareModel?name=$Model&Take=1&Skip=0" -Method Get -Credential $mycreds -ContentType "application/json").result.id

$body = @{
    Name        = $CmpName
    Mac         = $Mac
    Uuid        = $Uuid
    Serial      = $Serial
    AssetTag    = $AssetTag
    Description = $Description
    Model       = $MIDs
    OverWrite   = $true
}

Invoke-RestMethod -Uri "$($SysManUrl)/api/Client" -Body (ConvertTo-Json $body) -Method Post -ContentType "application/json" -Credential $mycreds





Get-ADGroupMember "adni-dl-labb01-1622637738" -Recursive | Foreach-Object { Get-ADUser $($_.samaccountname) -properties mail } | select mail
# | Export-Csv -Path c:\temp\skovde.csv -Encoding utf8})

$users = Get-ADGroupMember "ORG-Skovde-Personnel" -Recursive | Foreach-Object ({ Get-ADUser $($_.samaccountname) -properties mail }) | Select -ExpandProperty mail
            
            
$users | Export-Csv -Path c:\temp\skovde01.csv -Encoding utf8
$users | Out-file -FilePath C:\temp\skovde-01.csv 







$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://srv-exc07.kommun.skovde.se/PowerShell/ -Authentication Kerberos
Import-PSSession $Session
$Servers = "srv-exc04", "srv-exc05", "srv-exc07", "srv-exc08"
foreach ($Server in $Servers) {
    Write-Host -ForegroundColor Yellow "Checking $Server ..."
    $Services = Test-ServiceHealth -Server $Server.ServicesNotRunning
    if ([string]::IsNullOrEmpty($Services.ServicesnotRunning)) {
        Write-Host -ForegroundColor Red "$Server IS DEAD!!"
    }
    else {
        Write-Host -ForegroundColor Green "$Server IS fine!!"
    }
}

$Servers = "srv-exc04", "srv-exc05", "srv-exc07", "srv-exc08"
foreach ($Server in $Servers) {
    Invoke-command -ComputerName $Server {
        Write-Host -ForegroundColor Red $Server
        Test-ServiceHealth
    }
}




Get-WMIObject -ComputerName "tst-adni0510" -Query "SELECT * FROM Win32_Product" | FT


Invoke-Command { Get-EventLog -LogName System -Source DCOM | Where-Object { $_.EventID -match "10036|10037|10038" } | Group-Object -Property EventID -NoElement | Sort-Object -Property Count -Descending } -ComputerName "tst-adni0510" #(Get-Content C:\Path\To\ComputerList.txt)



$Users = get-mailbox 
$data = ForEach ($User in $Users) {
    $id = $user.alias
    Get-CalendarDiagnosticLog -Identity "adam.nilsson@skovde.se" -StartDate "06/01/2022 6:00:00 AM" -EndDate "06/20/2022 5:00:00 PM" 
}

Get-CalendarDiagnosticLog -Identity "adam.nilsson@skovde.se" | select Logdate, NormalizedSubject #| where {$_.NormalizedSubject -like "Patch*"}

get-aduser adni0510

, TI-FN-Tillväxt och TI-FN-Turism

get-mailbox TI-FN-Evenemang


Set-MailboxAutoReplyConfiguration -Identity "adam.nilsson@skovde.se" -AutoReplyState Scheduled -StartTime "07/07/2022 08:00" -EndTime "07/08/2022 12:00" -InternalMessage "Internal auto-reply test date 20 August." -ExternalMessage "External auto-reply test date 20 August."
ExceptIfSenderDomainIs

Set-Transportrule -id "External Email Warning" -ExceptIfSenderDomainIs (Get-content C:\temp\domain.txt)
Get-Transportrule -id "External Email Warning" | select -ExpandProperty ExceptIfSenderDomainIs




Import-module smlets -Force
$Date = Get-Date -Format "yyyy-MM-dd HH:mm"
$Systems = @()
$IRClass = get-scsmclass -name System.WorkItem.Incident$
$IRnr = "\`d.T.~Ed/{946EE941-A3B5-47ED-B483-6E6B84F0EEB7}.Id\`d.T.~Ed/"

$IR = get-SCSMObject -class $IRClass -Filter "ID -eq $IRnr"
$IRTitel = $ir.Title
$IRDesc = $ir.Description


$RelServer = (Get-SCSMRelationshipObject -BySource $IR | Where-Object { $_.relationshipid -eq 'b73a6094-c64c-b0ff-9706-1822df5c2e82' }).TargetObject
$RelServerName = $RelServer.DisplayName
if ($RelServer) {
    $RelSystems = (Get-SCSMRelationshipObject -ByTarget $RelServer | Where-Object { $_.relationshipid -eq '4448664f-b657-407a-cdbe-b7433af0ccdb' }).SourceObject

    foreach ($system in $RelSystems) {
        $SystemName = $system.DisplayName
        $RelTechnician = (Get-SCSMRelationshipObject -BySource $system | Where-Object { $_.relationshipid -eq '7fb647ee-7208-18c2-ef0d-d36b03aff5bb' }).TargetObject
        $TechDisplayname = $RelTechnician.DisplayName
        $SysTech = "System: $SystemName 
Teknikansvarig: $TechDisplayname"
        $Systems += $SysTech
    }
    $FAN = $Systems | Out-String
}
Else {
    $FAN = ""
}

if ($RelServer) {
    $FinnsServer = "YES"
}
Else {
    $FinnsServer = "NO"
}

$uri = 'https://samarbete.webhook.office.com/webhookb2/3827a4a5-d1a6-4b4b-b889-8811cbacafe0@4c98088a-8771-4b89-86fa-342cf75f4e28/IncomingWebhook/f36713938692436c901d183e02b43cd6/ea2021d4-b6a3-43e7-a2e2-2c0f87ab87fb'

$body = ConvertTo-Json -Depth 4 @{
    title           = "$IRnr"
    text            = " "
    sections        = @(
        @{
            activityTitle    = "$IRTitel"
            activitySubtitle = ''
            #activityText = 'A change was evaluated and new results are available.'
            #activityImage = 'http://URL' # this value would be a path to a nice image you would like to display in notifications
        },
        @{
            title = ''
            facts = @(
                @{
                    name  = 'Tid:'
                    value = $Date
                },
                @{
                    name  = 'Beskrivning:'
                    value = "$IRDesc"
                },
                @{
                    name  = 'System:'
                    value = $FAN
                }
            )
        }
    )
    potentialAction = @(@{
            '@context' = 'http://schema.org'
            '@type'    = 'ViewAction'
            name       = $IRnr
            target     = @("http://support/Incident/Edit/$IRnr/")
        })
}


Invoke-RestMethod -uri $uri -Method Post -body $body -ContentType 'application/json; charset=utf-16'


Set-OrganizationConfig -VisibleMeetingUpdateProperties "Body,Location,AllProperties:15"


$users = Get-teamuser -groupid  be1cc29c-ddcd-4ba6-9ad0-d44d4176ecba
$users | ForEach-Object { grant-CsTeamsUpdateManagementPolicy -Identity $_.user -PolicyName "Pilot" -WhatIf }

$cred = Get-Credential
Connect-MsolService -Credential $UserCredential -ErrorAction Stop

$session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://ps.outlook.com/powershell/ -Credential $UserCredential -Authentication Basic -AllowRedirection

Connect-ExchangeOnline -ConnectionUri https://ps.outlook.com/powershell/ -Credential $UserCredential
New-ManagementRoleAssignment -Role "ApplicationImpersonation" -User bittitan@Karlsborgskommun.onmicrosoft.com


Get-ADGroupMember -Identity org-ros -Recursive | where { { $_.objectclass -eq "user" } -and { $_.Enabled -eq "true" } } | ForEach-Object { Get-ADUser $_.name -Properties Mail, Description, Office } | Select-Object Mail, Description, Office


Get-MsolUser -all | Select-Object DisplayName, UserPrincipalName, @{N = "MFA Ready"; E = { if ( $.StrongAuthenticationMethods -ne $null) { "Yes" } else { "No" } } }, @{N = "MFA Admin Enforced"; E = { if ( $.StrongAuthenticationRequirements.State -ne $null) { $_.StrongAuthenticationRequirements.State } else { "Disabled" } } } | ft -AutoSize

Connect-MsolService
Get-MsolUser -All | select DisplayName, BlockCredential, UserPrincipalName, @{N = "MFA Status"; E = { if ( $_.StrongAuthenticationRequirements.State -ne $null) { $_.StrongAuthenticationRequirements.State } else { "Disabled" } } }



# Connect to Azure AD
Connect-AzureAD

# Get the user object
$user = Get-AzureADUser -ObjectId "adam.nilsson@skovde.se"
$ob = Get-AzureADUser -ObjectId b37f5887-c533-4355-8d64-39d7e0258567

# Check if the user has MFA enabled
if ($user.StrongAuthenticationRequirements -contains "MultiFactorAuthentication") {
    Write-Output "MFA is enabled for the user"
}
else {
    Write-Output "MFA is not enabled for the user"
}

# Connect to Azure AD
Connect-MsolService

# Get the user object
$user = Get-MsolUser -UserPrincipalName "adam.nilsson@skovde.se"

# Check if the user has MFA enabled
if ($user.StrongAuthenticationRequirements -contains "StrongAuthenticationRequirement") {
    Write-Output "MFA is enabled for the user"
}
else {
    Write-Output "MFA is not enabled for the user"
}


TM-SK-SBU-Vasterhojd-Allpersonal20221216T1304223684@samarbete.onmicrosoft.com


Get-content C:\tmp\datorer.txt | foreach { Get-ADComputer $_ | Disable-ADAccount }

$secPasswordServiceAccount = ConvertTo-SecureString "998RRt5g" -AsPlainText -Force
#$secPasswordServiceAccount = Get-Content C:\Credentials\SRVC-ORCH-Service.txt | ConvertTo-SecureString
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$creds = New-Object System.Management.Automation.PSCredential($serviceAccount, $secPasswordServiceAccount) 
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$return = Invoke-Command -Session $session -ScriptBlock {
    
    function RemoveSpecialCharacters ([string] $string) {
        $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $string = $string -replace "[àáåäâã]", "a"
        $string = $string -replace "[óòôöõ]", "o"
        $string = $string -replace "[éèëê]", "e"
        $string = $string -replace "[üûúù]", "u"
        $string = $string -replace "[íìîï]", "i"
        $string = $string -replace "ñ", "n"
        $string
    }
    
    Import-Module MicrosoftTeams
    $ErrorActionPreference = "Stop"
    $Kommun = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{D71617FA-573F-4DE5-B792-39CCFBF99829}\`d.T.~Ed/"
    $Office = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.Office\`d.T.~Ed/"
    $UPNN = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.UPN\`d.T.~Ed/"
    $ErrorActionPreference = "Stop"
    $TeamsAdmin = "srvc-teams@samarbete.onmicrosoft.com"
    $TeamName = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{84CAF08C-D52B-4162-8169-AB3323ACBA48}\`d.T.~Ed/"
    $secPassword = ConvertTo-SecureString "e1JRlJRcGF@" -AsPlainText -Force
    $myTeamsCreds = New-Object System.Management.Automation.PSCredential ($TeamsAdmin, $secPassword)
    Connect-MicrosoftTeams -Credential $myTeamsCreds
    $EDU = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{21564C05-C2B2-4811-9BCA-9D81EE5BDF5C}\`d.T.~Ed/"
    $Date = Get-Date -Format FileDateTime

    if ($Kommun -eq "Tibro Kommun") {
        $KommunName = "TI" 
    }
    elseif ($Kommun -eq "Hjo Kommun") {
        $KommunName = "HJ"
    }
    else {
        $KommunName = "SK" 
    }
    $TeamFullName = 'TM-' + $KommunName + '-' + $Office + '-' + $TeamName + $Date
    $TeamNOSpace = $TeamFullName.replace(' ', '')
    $TeamAlias = RemoveSpecialCharacters($TeamNOSpace)
    
    try {       
        if ($EDU -eq "TRUE") {
            $Team = New-Team -MailNickName "$TeamAlias" -displayname "$TeamName" -Description "$TeamName" -Template "EDU_Class" -Owner $UPNN
            Start-Sleep 30
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Member
            #Start-Sleep 10
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Owner
            $Status = "Success"
        }
        else {
            $Team = New-Team -MailNickName "$TeamAlias" -Displayname "$TeamName" -Visibility "Private" -Description "$TeamName" -Owner $UPNN
            Start-Sleep 30
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Member
            #Start-Sleep 10
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Owner
            $Status = "Success"
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        $Status = "Failed"
    }
    finally {
        $return = @($Status, $ErrorMessage, $Team)
        $return
    }

}
$Team = $return.Get(0)
$Status = $return.Get(1)
$ErrorMessage = $return.Get(2)

$Team = Get-Team -mailnickname "TM-KBG-CHEFSGRUPP365@samarbete.onmicrosoft.com"

New-Mailbox -Name "strommen" -Alias "FN-KBG-strommen" –Shared -PrimarySmtpAddress "strommen@mig.samarbete.onmicrosoft.com"
New-Mailbox -Name "Biblioteket" -Alias "FN-KBG-Biblioteket" –Shared -PrimarySmtpAddress "biblioteket@mig.samarbete.onmicrosoft.com"


$users = Import-Csv -Path "C:\temp\KBGMIG\usr\mig-personnel-prod.csv"
$from = "noreply@skovde.se"
$Body = "Fredagen 24/2 påbörjas migreringen av Karlsborgs Office 365 miljö till den gemensamma Office 365 miljö som finns för Hjo, Tibro och Skövde.  

Migreringen beräknas pågå under hela helgen och då kan vissa funktioner vara svåra att nå periodvis. 

Efter själva migreringen är klar behöver du logga in i Office 365-tjänster igen, exempelvis Word, Outlook, Teams etc. Detta gör du med din e-postadress och det lösenord som du använder för att logga in i din dator. 

Saker att tänka på efter migreringen 

Konfigurera om Outlook applikationen i telefonen 
https://guider.skovde.se/6098.guide  

Dela om filer och dokument, i t.ex Onedrive, Teams 

Om du är mötesorganisatör, så kommer du behöva duplicera om dina teamsmöten 
https://guider.skovde.se/6093.guide 

Privata chattar och chatt-grupper kommer inte migreras över, det kommer behöva skapas om.  

Lägg till en signatur i Outlook 
https://guider.skovde.se/6097.guide 

Vi rekommenderar att ni går in och läser Förberedelser på guideportalen innan migreringen börjar och ni hitta frågor och svar samt guider via följande länk Guideportal (https://guider.skovde.se/portal/Karlsborgs%20migrering) 

Om du har frågor kan du vända dig till servicedesk IT på telefonnummer 0500-498501 eller lägga ett ärende i serviceportalen (https://support/) 

Från och med måndag den 27 februari veckan ut kommer det finnas extra stöd och support från IT-avdelningen på plats i Karlsborg. 

Hälsningar  
Karlsborgs kommun i samarbete med IT-avdelningen i Skövde"

foreach ($user in $users) {
    $To = $user.OldUPN
    # $To = $user.OldUPN
    # $CC = "adam.nilsson@skovde.se"
    # $File = ""
    $options = @{
        'SmtpServer' = "smtp.skovde.se" 
        'To'         = "$To"
        # 'CC'          = "$CC"
        'From'       = "$From"
        'Subject'    = "Ytterligare information gällande Office 365 migrering" 
        'Body'       = "$Body"
        # 'Attachments' = "$File"
    }
    Send-MailMessage @options -Encoding UTF8
    Write-Host -ForegroundColor Yellow "Sending to $To"
}


Mellangatan, Room, Mellangatan@karlsborg.se

$resources = Import-Csv "C:\temp\KBGMIG\kbg-resources02.csv"
foreach ($resurs in $resources) {
    New-Mailbox -Name $resurs.DisplayName -Alias $resurs.ALIAS -Room -PrimarySmtpAddress $resurs.smtp
}

New-Mailbox -Name $resurs.DisplayName -Alias $resurs.ALIAS -Room -PrimarySmtpAddress $resurs.smtp
gastlagenhet.kruthus.boknig@mig.samarbete.onmicrosoft.com

Connect-AzureAD

Get-AzureADUser -All $true

| revoke-azureaduserallrefreshtoken



Set-AzureADUser -UserPrincipalName skvdtest@edumig.samarbete.onmicrosoft.com -NewUserPrincipalName skvdtest@samarbete.onmicrosoft.com
Get-AzureADUser -ObjectId skvdtest@mig.samarbete.onmicrosoft.com

# New Sharedmailbox
$Displayname = "FN-KB-KONFERENSRUM-INFOCENTER"

New-Mailbox -Name $Displayname -Alias $Displayname -Shared -PrimarySmtpAddress "$Displayname@karlsborg.se"


Get-Aduser -filter * -SearchBase "OU=Personnel,OU=Tibro,OU=Top,DC=kommun,DC=skovde,DC=se" -prop * | select userprincipalname, skUserMulti01


get-accepteddomain

Connect-AzureAD

# Set the start and end date for the logs you want to retrieve
$startDate = "2022-03-01"
$endDate = "2022-03-07"

# Retrieve the sign-in logs for the specified time range
$logs = Get-AzureADAuditSignInLogs -Filter "createdDateTime ge $startDate and createdDateTime le $endDate"

# Group the logs by user principal name and display the count of sign-ins for each user
$logs | Group-Object -Property UserPrincipalName | Select-Object Name, Count | Sort-Object -Property Count -Descending




# Add-MailboxFolderPermission -Identity "Fyren Kommunhus Bokning":\kalender" -User "Meetio.Bokning" -AccessRights Reviewer
# Add-MailboxFolderPermission -Identity $Mailbox":\Calendar" -User "CMGO365Sync" -AccessRights Reviewer

$users = Get-content C:\tmp\sms.txt
$ADUsers = Get-ADGroupMember org-sms -Recursive
$users | % { Get-aduser -filter { displayname -eq $_ } -SearchBase "OU=Personnel,OU=Skovde,OU=Top,DC=kommun,DC=skovde,DC=se" -prop * } | select -ExpandProperty mail | clip

$users = Get-content C:\temp\SMS.txt


foreach ($Member in $Users) {
    $US = Get-aduser -filter { UserPrincipalName -eq $member }
    Add-ADGroupMember -Identity 'User-WindowsHello' -Members $Us
    Write-Host "Adding member $member"
}

Get-ADGroupMember -id 'User-WindowsHello' -Recursive






Get-DistributionGroupMember 'SK-DL-SBU-Kontoret' | Select Name, PrimarySmtpAddress | Export-CSV c:\temp\WH-SBU01.csv -NoTypeInformation -Append
Get-DistributionGroupMember 'DIST-SBU-Ledningsgrupp' | Select Name, PrimarySmtpAddress | Export-CSV c:\temp\WH-SBU01.csv -NoTypeInformation -Append
Get-DistributionGroupMember 'SK-DL-SBU-Stab' | Select Name, PrimarySmtpAddress | Export-CSV c:\temp\WH-SBU01.csv -NoTypeInformation -Append



$users = Get-adgroupmember -id 'DL19101506482210' -Recursive
$users | % { get-aduser $_ } | select SamAccountName, UserPrincipalName | Export-CSV c:\temp\WH-SBU01.csv -NoTypeInformation -Append


Sk-dl-sbu-stab

Function Get-CMDeviceIP {  
    Param (
        [parameter(Mandatory = $true)]
        $Computer
    ) 
    $SiteCode = "P02" 
    $SiteServer = "srv-sc-cm02.kommun.skovde.se"
    $IP = (Get-WmiObject -Class SMS_R_SYSTEM -Namespace "root\sms\site_$SiteCode" -computerName $SiteServer | Where-Object { $_.Name -eq "$Computer" }).IPAddresses 
    $IP = $IP.replace(":", "") 
    Write-Output "$Computer $IP" 
}

function HuntUser {
    <# 
    .SYNOPSIS 
    Retrieve workstation(s) last logged on by user (SAM Account Name)
  
    .DESCRIPTION 
    The HuntUser function will retrieve workstation(s) by the last logged on user (SAM Account Name). This queries SCCM; accuracy will depend on the last time each workstation has communicated with SCCM.
  
    .EXAMPLE 
    HuntUser dewittj 
    #> 
    Param( [parameter(Mandatory = $true)]
        $SamAccountName,
        #SCCM Site Name
        $SiteName = "P02",
        #SCCM Server Name
        $SCCMServer = "srv-sc-cm02.kommun.skovde.se",
        #SCCM Namespace
        $SCCMNameSpace = "root\sms\site_$SiteName")
  
    function Query {
  
        $i = 0
        $j = 0
  
        foreach ($User in $SamAccountName) {
  
            #   Write-Progress -Activity "Retrieving Last Logged On Computers By SAM Account Name..." -Status ("Percent Complete:" + "{0:N0}" -f ((($i++) / $SAMAccountName.count) * 100) + "%") -CurrentOperation "Processing $($User)..." -PercentComplete ((($j++) / $SAMAccountName.count) * 100)
  
            $Computers = (Get-WmiObject -namespace $SCCMNameSpace -computer $SCCMServer -query "select Name from sms_r_system where LastLogonUserName='$User'").Name
            foreach ($computer in $computers) {
  
                [pscustomobject] @{
          
                    SAMAccountName  = "$User"  
                    "Last Computer" = "$computer"                    
                }
            }
        }
    }
  
    Query
  
}#End HuntUser

$IP = (Get-WmiObject -Class SMS_R_SYSTEM -Namespace "root\sms\site_$SiteCode" -computerName $SiteServer | Where-Object { $_.Name -eq "$Computer" }).IPAddresses
$Computers =

$SCCMNameSpace = "root\sms\site_P02")
  (Get-WmiObject -namespace "root\sms\site_P02" -computer "srv-sc-cm02.kommun.skovde.se" -query "select Name,IPAddresses from sms_r_system where LastLogonUserName='$User'") | Select Name, IPAddresses
$Com
  (Get-WmiObject -namespace "root\sms\site_P02" -computer "srv-sc-cm02.kommun.skovde.se" -query "select Name,IPAddresses from sms_r_system where Name='$Computer'") | Select Name, IPAddresses






# Get-Recipient -Filter {"ManagedBy" -eq 'CN=thah0929,OU=Personnel,OU=Skovde,OU=Top,DC=kommun,DC=skovde,DC=se'} -RecipientTypeDetails GroupMailbox,MailUniversalDistributionGroup,MailUniversalSecurityGroup,DynamicDistributionGroup

Get-mailbox -Filter * -ResultSize unlimited | ? { $_.EmailAddresses -like "*nyttkonto*" }

$TISOCUsers = Get-adgroupmember -id "ORG-TI-SOC" -Recursive | % { Get-AdUser $_.samaccountname -Properties Userprincipalname, samaccountname, skUserMulti01, enabled | Select Userprincipalname, samaccountname, skUserMulti01, enabled }
$TISOCUsers | Export-Excel -Path C:\temp\SOCTIBROLIC.xlsx -AutoSize -TableName F
Export-Csv -Path C:\temp\SOCTIBROLIC.csv -NoTypeInformation

$TISOCUsers | sort skUserMulti01, enabled | Out-File -FilePath C:\temp\TIBROSOCLIC.csv

$Mailbox = @()
$mailbox = foreach ($user in $TISOCUsers) {
    $ADinfo =  Get-ADUser -id $user.samaccountname -Properties Userprincipalname, samaccountname, skUserMulti01 | select Userprincipalname, samaccountname, skUserMulti01
    $Mail = Get-Mailbox $user.samaccountname | select name,servername
        if (!$mail)
            Get-remotemailbox $user.samaccountname
}

$Mailbox | sort Name | select name,ServerName | Export-Csv -Path C:\temp\SOCTIBROmailbox.csv -NoTypeInformation


[PSCustomObject]@{
    "PNumber"            = [string]$ADInfo.EmployeeID
    "DisplayName"        = [string]$ADInfo.DisplayName
}

get-adgroupMember -id 'User-lokal-admin-windows10' -Recursive | ?{($_.SamAccountName -notlike "*-supp") -or ($_.SamAccountName -notlike "*-adm")} | select SamAccountName
$US = get-adgroupMember -id 'User-lokal-admin-windows10' -Recursive| %{Get-Aduser $_ -Properties *} | ?{$_.extensionAttribute1 -eq "personnel"} | select SamAccountName,Userprincipalname,Office | sort Office

$ADM = get-adgroupMember -id 'User-lokal-admin-windows10' -Recursive| %{Get-Aduser $_ -Properties *} | select enabled,SamAccountName,DisplayName,Userprincipalname,Office,@{Name="lastLogon";Expression={[datetime]::FromFileTime($_.'lastLogon')}}| sort Office,lastLogon
$ADM | Export-Csv -Path C:\temp\LokalAdmins.csv -NoTypeInformation -Encoding UTF8
$US | Export-Excel -Path C:\temp\LokalAdmins.xlsx -PivotTableName Lista

Get-ADUser adni0510-supp -Properties lastLogon | Select samaccountname, @{Name="lastLogon";Expression={[datetime]::FromFileTime($_.'lastLogon')}}

$USe = get-adgroupMember -id 'lab-adni0510' -Recursive| %{Get-Aduser $_ -Properties *} | ?{$_.extensionAttribute1 -eq "personnel"} 
$USe | %{Remove-ADGroupMember -Identity "lab-adni0510" -Members $_ -Confirm:$false}

$dev = get-adgroupmember "User-LIC-SKO-EMS" -Recursive | ?{$_.samaccountname -like "DEV-*"}