$RegKey = "HKCU:\\Software\Microsoft\Office\16.0\Outlook\Options\General"
if (-Not(Test-Path "$RegKey")) {
    New-Item -Path $RegKey -Force
}
Set-ItemProperty -Path $RegKey -Name "DelegateWastebasketStyle" -Type Dword -Value 4