Import-Module CredentialManager
$o365admin =  (Get-StoredCredential -Target tst-adni0510)

#Connect Exchange Online
$exchSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $o365admin -Authentication Basic -AllowRedirection
Import-PSSession $exchSession -DisableNameChecking -AllowClobber

$mailbox = Get-ADGroupMember -Identity "EORG-HJO-VOO-ArbetsterapiRehab" -Recursive | Get-ADUser -Properties Mail | Select-Object -ExpandProperty Mail
$resurs = "HJ-RS-Cykel-Rehabcykel RE3"
$mailbox | ForEach-Object {Add-MailboxPermission $resurs -User $_ -AccessRights FullAccess -InheritanceType All -AutoMapping $false}
Get-MailboxPermission $resurs
