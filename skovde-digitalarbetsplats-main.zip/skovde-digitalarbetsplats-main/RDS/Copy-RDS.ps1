# Old environment
$ConnectionBrokerOLD = "srv-rdw01.kommun.skovde.se"
$CollectionNameOLD = "Skövde Extern åtkomst"
# New environment
$ConnectionBrokerNEW = "srv-rdw01.kommun.skovde.se"
$CollectionNameNEW = "Skövde Extern åtkomst 02"
# Export path
$ExportPath = "C:\Temp\RemoteApp\Export.csv"

Get-RDRemoteApp -CollectionName $CollectionNameOLD -ConnectionBroker $ConnectionBrokerOLD | Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8

Get-RDRemoteApp -CollectionName $CollectionNameOLD -ConnectionBroker $ConnectionBrokerOLD 

Import-Csv -Path $path | ForEach-Object {
 
    If ($_.CommandLineSetting -eq "Require" ) {
        Write-Host "This RemoteApp ("$_.Alias") has a Required CMDLine"
        New-RDRemoteApp -CollectionName $CollectionNameNEW -ConnectionBroker $ConnectionBrokerNEW -Alias $_.Alias -DisplayName $_.DisplayName -FilePath $_.FilePath -FileVirtualPath $_.FileVirtualPath -FolderName $_.FolderName -IconPath $_.IconPath -IconIndex $_.IconIndex -CommandLineSetting Require
        Start-Sleep 45
        Write-Host "Now updating RemoteApp " ($_.Alias) ""
        Get-RDRemoteApp -CollectionName $CollectionNameNEW -ConnectionBroker $ConnectionBrokerNEW -Alias $_.Alias | Set-RDRemoteApp -CollectionName $CollectionNameNEW -RequiredCommandLine $_.RequiredCommandline
    }
    else {
        Write-Host "this RemoteApp ("$_.Alias") does not have a Required CMDLine"
        New-RDRemoteApp -CollectionName $CollectionNameNEW -ConnectionBroker $ConnectionBrokerNEW -Alias $_.Alias -DisplayName $_.DisplayName -FilePath $_.FilePath -FileVirtualPath $_.FileVirtualPath -FolderName $_.FolderName -IconPath $_.IconPath -IconIndex $_.IconIndex
    }
 



