# $ErrorActionPreference = 'SilentlyContinue'
c:\windows\sysnative\windowspowershell\v1.0\powershell.exe `
    -NonInteractive -Command
import-module remotedesktop
import-module remoteaccess

$Server = "TST-GOSE09241"
$Konsol = "\`d.T.~Ed/{93D4C1A2-FB52-4907-A9D0-D0335BA2485B}.{8A65DE63-E676-4731-A568-BF878AFC3EB4}\`d.T.~Ed/"
$RDP = "TRUE"
$connBroker = "srv-rdw01.kommun.skovde.se"
$RDSCollection = "Skövde Extern Åtkomst 02"

$appsett = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "RDS-template" -ConnectionBroker $connBroker
try {
    $CheckGroup = Get-ADGroup -Identity "User-RDS-RDP-$server" 
}
catch {}

if (!$CheckGroup) {
    New-ADGroup -Path "OU=Groups,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -Name "User-RDS-RDP-$server" -GroupScope Global
}
Add-ADGroupMember -Identity Srv-RDS-RemotedServers -Members "User-RDS-RDP-$server"
Add-ADGroupMember -Identity User-RDS-SkovdeExternÅtkomst -Members "User-RDS-RDP-$server"
Start-Sleep -Seconds 60
try {
    $CheckRDSApp = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "RDP till $Server" -ConnectionBroker $connBroker
}
catch {}

if (!$CheckRDSApp) {
    New-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "RDP till $Server" -FilePath $appsett.FilePath -FolderName $appsett.FolderName -CommandLineSetting Require -RequiredCommandLine "/v:$server" -UserGroups "User-RDS-RDP-$server" -ConnectionBroker $connBroker
    Start-Sleep -Seconds 60
}
([ADSI]"WinNT://$server/Administrators,group").Add("WinNT://kommun.skovde.se/User-RDS-RDP-$($server)")

$appsett = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "Fjärrstyrning Konsoll" -ConnectionBroker $connBroker
$gruppe = "User-RDS-RC-$server"
New-ADGroup -Path "OU=Groups,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -Name "User-RDS-RC-$server" -GroupScope Global
Add-ADGroupMember Apps-RemoteControl-User "User-RDS-RC-$server"
Add-ADGroupMember Srv-RDS-RemotedServers "User-RDS-RC-$server"
Add-ADGroupMember User-RDS-SkovdeExternÅtkomst "User-RDS-RC-$server"
Start-Sleep -Seconds 10
New-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "Konsoll till $Server" -FilePath $appsett.FilePath -FolderName $appsett.FolderName -CommandLineSetting Require -RequiredCommandLine "$Server" -UserGroups "User-RDS-RC-$server" -ConnectionBroker $connBroker
Start-Sleep -Seconds 10
Get-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "Konsoll till $Server" -ConnectionBroker $connBroker
([ADSI]"WinNT://$server/Administrators,group").Add("WinNT://kommun.skovde.se/User-RDS-RC-$($server)")
}

Get-RDRemoteApp -CollectionName $RDSCollection -ConnectionBroker $connBroker
Remove-RDRemoteApp -CollectionName $RDSCollection -Alias "mstsc(5)" -ConnectionBroker $connBroker

$ErrorActionPreference = 'SilentlyContinue'
c:\windows\sysnative\windowspowershell\v1.0\powershell.exe `
    -NonInteractive -Command {
    import-module remotedesktop
    import-module remoteaccess

    $Server = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{D2017E2E-C87D-4065-AA6A-ED76EF2073D7}\`d.T.~Ed/"
    $Konsol = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{F8E1100A-1F25-4F80-BCEE-182D2596BC86}\`d.T.~Ed/"
    $RDP = "\`d.T.~Ed/{2DBDD9AF-415D-47DA-9FB0-231CEA568D6E}.{FEDDD4F5-0AAB-410D-8FA4-DDB49586DA08}\`d.T.~Ed/"
    $connBroker = "srv-rdw01.kommun.skovde.se";

    if ($RDP -eq "TRUE") {
        Try {
            $appsett = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "Remote Desktop Connection" -ConnectionBroker $connBroker
            $gruppe = "User-RDS-RDP-$server"
            New-ADGroup -Path "OU=Groups,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -Name "User-RDS-RDP-$server" -GroupScope Global
            Add-ADGroupMember Srv-RDS-RemotedServers "User-RDS-RDP-$server"
            Add-ADGroupMember User-RDS-SkovdeExternÅtkomst "User-RDS-RDP-$server"
            Start-Sleep -Seconds 10

            New-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "RDP till $Server" -FilePath $appsett.FilePath -FolderName $appsett.FolderName -CommandLineSetting Require -RequiredCommandLine "/v:$server" -UserGroups "User-RDS-RDP-$server" -ConnectionBroker $connBroker
            Start-Sleep -Seconds 10
            Get-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "RDP till $Server" -ConnectionBroker $connBroker
            ([ADSI]"WinNT://$server/Administrators,group").Add("WinNT://kommun.skovde.se/User-RDS-RDP-$($server)")
        }
        Catch {}
    }
    else {}


    if ($Konsol -eq "TRUE") {
        Try {
            $appsett = Get-RDRemoteApp -CollectionName $RDSCollection -DisplayName "Fjärrstyrning Konsoll" -ConnectionBroker $connBroker
            $gruppe = "User-RDS-RC-$server"
            New-ADGroup -Path "OU=Groups,OU=Partners,OU=Extern,OU=Top,DC=kommun,DC=skovde,DC=se" -Name "User-RDS-RC-$server" -GroupScope Global
            Add-ADGroupMember Apps-RemoteControl-User "User-RDS-RC-$server"
            Add-ADGroupMember Srv-RDS-RemotedServers "User-RDS-RC-$server"
            Add-ADGroupMember User-RDS-SkovdeExternÅtkomst "User-RDS-RC-$server"
            Start-Sleep -Seconds 10

            New-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "Konsoll till $Server" -FilePath $appsett.FilePath -FolderName $appsett.FolderName -CommandLineSetting Require -RequiredCommandLine "$Server" -UserGroups "User-RDS-RC-$server" -ConnectionBroker $connBroker
            Start-Sleep -Seconds 10
            Get-RDRemoteApp -CollectionName $appsett.CollectionName -DisplayName "Konsoll till $Server" -ConnectionBroker $connBroker
            ([ADSI]"WinNT://$server/Administrators,group").Add("WinNT://kommun.skovde.se/User-RDS-RC-$($server)")
        }
        Catch {}
        else {}
    }
}