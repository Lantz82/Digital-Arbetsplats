

Import-Module ActiveDirectory
Get-ADComputer $server | Move-ADObject -TargetPath "OU=SessionHost,OU=RDS,OU=Servers,DC=kommun,DC=skovde,DC=se"
Add-ADGroupMember -Identity "Srv-RDS-HostServers" -Members $server
Add-ADGroupMember -Identity "RD SessionHost ApplicationServer" -Members $server
Enter-PSSession -Computername $server -Credential $cred
Get-WindowsFeature | Where-Object name -Like "rds*"
Install-WindowsFeature RDS-RD-Server -IncludeManagementTools
Restart-Computer -Force