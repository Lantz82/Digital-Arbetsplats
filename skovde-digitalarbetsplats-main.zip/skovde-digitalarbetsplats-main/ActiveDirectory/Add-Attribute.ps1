
$name = "SK-DL-SSV-Chefsforum"
Get-ADGroup -Filter {name -eq $name} -Properties "extensionAttribute5" | Set-ADGroup -Add @{"extensionAttribute5"="NOSYNC"}
Get-ADGroup -Filter {name -eq $name} -Properties "extensionAttribute5"

get-adgroup $name | Set-ADGroup -Add @{"extensionAttribute5"="NOSYNC"}


$groups = Get-Content -Encoding UTF8 "C:\temp\SK-DL-SBU004.csv"
Foreach ($group in $groups) {
    Get-ADGroup -Filter {name -eq $group} -Properties "extensionAttribute5" | Set-ADGroup -Add @{"extensionAttribute5"="NOSYNC"}
    Get-ADGroup -Filter {name -eq $group} -Properties "extensionAttribute5"
}

# skUserAttribute9 för licens, E1; etc.

get-aduser "caan0131" -prop skUserAttribute2 | Set-ADUser -Replace @{"skUserAttribute2"="SYNCSAMARBETE"}
# Rensar Licens; samarbete
Get-aduser "josu0916" -prop skUSerMulti01 | set-aduser -clear skUSerMulti01


#
$name = "SK-DL-SSV-Chefsforum"
Get-DistributionGroup -Identity $name
.\Exchange\Recreate-DistributionGroup.ps1 -Group $name -CreatePlaceHolder
Get-ADGroup -Filter {name -eq $name} -Properties "extensionAttribute5" | Set-ADGroup -Add @{"extensionAttribute5"="NOSYNC"}
Start-AzureSync.ps1
.\Exchange\Recreate-DistributionGroup.ps1 -Group $name -Finalize
Get-ADGroup -Filter {name -eq $name} -Properties "extensionAttribute14" | Set-ADGroup -Add @{"extensionAttribute14"="Azure:$name"}

# skriver lite nytt