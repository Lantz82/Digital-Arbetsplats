$Old = "CompOrg-TI-SOC"
$New = "Comp-DirectAccess"
Get-ADGroupMember -Identity $old -Recursive | ForEach-Object {Add-ADGroupMember -Identity $new -Members $_.distinguishedName}
Get-ADGroupMember -Identity $new | Select-Object Name | Sort-Object Name
