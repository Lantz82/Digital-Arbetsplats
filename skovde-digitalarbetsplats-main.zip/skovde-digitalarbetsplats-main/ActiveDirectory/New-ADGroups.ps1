# $sektor = @("SVO","SSV","SMS","SSB","SBU","SSE","SSO")
# $sektor = @("AOS","BOU","KFT","KSF","SHB","VOO")
# $sektor = @("BUN","KFN","KLK","SHB","SOC")
# $sektor = @("KLF","SOF","BUF","SBF","KFF")
$sektor = @("KBG", "BALT","RTJS","KOMF","MOS","AAS","SSV","SMS","SSB","SBU","SVO","SSO","SSE","SEAB","HJO","TIBRO")
$ou = "OU=Groups,OU=Top,DC=kommun,DC=skovde,DC=se"

foreach ($s in $sektor) {
    $name = "User-Lokal-Admin-$s-SR"
    $description = "Lokal Admin $s-SR"
    $adgroup = $null
    $adgroup = Get-adgroup -id $name -ErrorAction SilentlyContinue
    If ($adgroup) {
        Write-Host -ForegroundColor Yellow "ADGroup: $name already exists..."
    }
    else {
        New-ADGroup -Name $name -DisplayName $name -GroupCategory Security -GroupScope Global -Path $ou -Description $description
        Write-Host -ForegroundColor Green "ADGroup $name created!"
    }
}