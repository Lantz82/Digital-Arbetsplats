Import-Module GroupPolicy
$grp = "Adm-GPOAdmins"
$level = "GpoEdit"
$gpos = get-gpo -All | where { $_.DisplayName -like "*lab*" }
foreach ($gpo in $gpos) {
    $gpname = $gpo.DisplayName	
    set-GPPermissions -Name $gpname -permissionlevel $level -TargetName $grp -targettype Group              
}


Set-GPPermissions -Name "test-edge" -permissionlevel $level -TargetName $grp -targettype Group
