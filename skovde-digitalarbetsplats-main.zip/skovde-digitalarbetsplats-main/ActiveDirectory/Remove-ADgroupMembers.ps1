Import-Module ActiveDirectory

$ADGroups = @("User-Lokal-Admin-KBG-SR", "User-Lokal-Admin-BALT-SR", "User-Lokal-Admin-RTJS-SR", "User-Lokal-Admin-KOMF-SR", "User-Lokal-Admin-MOS-SR", "User-Lokal-Admin-AAS-SR", "User-Lokal-Admin-SSV-SR", "User-Lokal-Admin-SMS-SR", "User-Lokal-Admin-SSB-SR", "User-Lokal-Admin-SBU-SR", "User-Lokal-Admin-SVO-SR", "User-Lokal-Admin-SSO-SR", "User-Lokal-Admin-SSE-SR", "User-Lokal-Admin-SEAB-SR", "User-Lokal-Admin-HJO-SR", "User-Lokal-Admin-TIBRO-SR")
foreach ($Group in $ADGroups) {
    Get-ADGroupMember $Group | ForEach-Object { Remove-ADGroupMember $Group $_ -Confirm:$false }
}