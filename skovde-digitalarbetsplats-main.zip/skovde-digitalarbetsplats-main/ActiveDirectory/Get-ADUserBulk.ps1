$users = Get-content "C:\temp\kbg-upn.txt"
foreach ($user in $users) {
    Get-aduser -filter {userprincipalname -eq $user} -Properties * | select SamAccountName,UserPrincipalName | Export-Csv -Path C:\Temp\KBG-Users01.csv -Encoding UTF8 -Append -NoTypeInformation
}

$OU = "OU=Personnel,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se"

Get-aduser -filter {enabled -eq $true -and -not(extensionAttribute1 -like "*")} -SearchBase $OU -prop mail | select -ExpandProperty mail | Out-file -FilePath C:\temp\KBG-rest.csv

Get-aduser -filter {enabled -eq $true } -SearchBase $OU -prop mail | select -ExpandProperty mail | Out-file -FilePath C:\temp\KBG-visit.csv 
