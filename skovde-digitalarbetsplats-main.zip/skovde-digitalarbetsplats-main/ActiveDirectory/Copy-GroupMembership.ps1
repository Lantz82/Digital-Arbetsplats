param(
    [Parameter(Mandatory = $true)]
    [string] $OldGroup,
    [Parameter(Mandatory = $true)]
    [string] $NewGroup
)
Get-ADGroupMember -Identity $OldGroup | ForEach-Object {Add-ADGroupMember -Identity $NewGroup -Members $_.distinguishedName}
Get-ADGroupMember -Identity $NewGroup | Select-Object Name | Sort-Object Name