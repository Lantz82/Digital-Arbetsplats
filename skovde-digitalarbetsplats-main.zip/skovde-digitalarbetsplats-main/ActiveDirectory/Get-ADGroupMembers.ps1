#requires -version 5.1
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
# 2019-11-05 Adam Nilsson - Initial coding
function Get-ADGruppMembers {
    Param(
        [Parameter(Mandatory = $true)]
        [string]$Group,
        [Parameter(Mandatory = $true)]
        [string]$OutFile
    )
    $ADGroup = Get-ADGroup $Group
    # -Filter {name -eq $Group} 
    if (!$ADGroup) {
        Write-Warning -Message "Could not find the group $group"
    }
    else {
        Get-ADGroupMember -Identity $ADGroup.SamAccountName -Recursive | Where-Object { { $_.objectclass -eq "user" } -and { $_.Enabled -eq "true" } } | ForEach-Object { Get-ADUser $_.name -Properties Mail, Description, Office } | Select-Object Mail | Export-Csv -Path $OutFile -NoTypeInformation -Encoding UTF8 -Delimiter ';' -Append
        Write-Host -ForegroundColor Green "The file $Outfile is now done!"
    }
}

$lovUsers = Get-Adgroupmember -id "user-lov" -Recursive | Where-Object { { $_.objectclass -eq "user" } -and { $_.Enabled -eq "true" } } | ForEach-Object { Get-ADUser $_.name -Properties Mail, Description, Office } | Select-Object userprincipalname,samaccountname

Connect-AzureAD
Get-AzureADUser -ObjectId adam.nilsson@skovde.se | Select-Object -ExpandProperty AssignedLicenses



Connect-AzureAD
$users = Import-Csv -Path "C:\Users.csv"

$results = $lovUsers | ForEach-Object {
    $user = Get-AzureADUser -ObjectId $_.UserPrincipalName
    $licenses = Get-AzureADUserLicenseDetail -ObjectId $user.ObjectId
    [PSCustomObject]@{
        UserPrincipalName = $user.UserPrincipalName
        AssignedLicenses = $licenses.AccountSkuId
    }
}

$results | Export-Csv -Path "C:\temp\UsersLicenses.csv" -NoTypeInformation
