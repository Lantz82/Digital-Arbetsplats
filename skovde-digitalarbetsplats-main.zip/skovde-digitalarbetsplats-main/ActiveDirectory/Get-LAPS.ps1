function Get-LAPS {
    Param(
        [PSObject]
        $Computer
    )
    # Define the AD computer properties to retrieve
    $ADComputerProperties = "ms-mcs-admpwd"
    $SelectADComputerProperties = "ms-mcs-admpwd"

    # Import the ActiveDirectory module
    Import-Module ActiveDirectory

    # Retrieve the specified AD computer and select the desired properties
    $Pass = Get-ADComputer -Identity $Computer -Properties $ADComputerProperties | Select-Object $SelectADComputerProperties

    # Check if the 'ms-mcs-admpwd' property is not empty, and output the value if it's not
    if ($Pass.'ms-mcs-admpwd') {
        Write-Output $Pass.'ms-mcs-admpwd'
    }
    else {
        Write-Output "Hittar inget LAPS lösenord för denna dator"
    }
}