
$NotMFA = ((Get-ADGroup "user-mfa-notenabled" -Properties member).member)
$MFA = ((Get-ADGroup "user-mfa-enabled" -Properties member).member)

((Get-ADGroup "user-mfa-notenabled" -Properties member).member).count
((Get-ADGroup "user-mfa-enabled" -Properties member).member).count

# ((Get-ADGroup "org-ssb" -Properties member).member).count

Function Get-MFAKund {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Company
    )
    $MFA = ((Get-ADGroup "user-mfa-enabled" -Properties member).member)
    if ($Company -eq "all") {
        Write-host Alla: $MFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Skovde,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host Skövde: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Tibro,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host Tibro: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Hjo,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host Hjo: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se" }
        $skMFA+= $mfa | ? { $_ -like "*OU=Politician,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se"}
        Write-host Karlsborg: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=AOS,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host AAS: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=Balthazar,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host BALT: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=MOS,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host MOS: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=ROS,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host RTJS: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=Skovde Energi,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host SEAB: $skMFA.count
        $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=KOMF,OU=Top,DC=kommun,DC=skovde,DC=se" }
        Write-host KOMF: $skMFA.count

    }
    else {
        switch ($Company) {
            "Skövde" {
                $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Skovde,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host Skövde: $skMFA.count
            }
            "Tibro" {
                $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Tibro,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host Tibro: $skMFA.count
            }
            "Hjo" {
                $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Hjo,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host Hjo: $skMFA.count
            }
            "Karlsborg" {
                $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se"}
                $skMFA+= $mfa | ? { $_ -like "*OU=Politician,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se"}
                Write-host Karlsborg: $skMFA.count
            }
            "AAS" {
                $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=AOS,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host AAS: $skMFA.count
            }
            "BALT" {
                $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=Balthazar,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host BALT: $skMFA.count
            }
            "MOS" {
                $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=MOS,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host MOS: $skMFA.count
            }
            "RS" {
                $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=ROS,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host RTJS: $skMFA.count
            }
            "SEAB" {
                $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=Skovde Energi,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host SEAB: $skMFA.count
            }
            "KOMF" {
                $skMFA = $mfa | ? { $_ -like "*OU=Users,OU=KOMF,OU=Top,DC=kommun,DC=skovde,DC=se" }
                Write-host KOMF: $skMFA.count
            }
        }
    }
}

Function Get-NotMFAKommun {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Company
    )
    $MFA = ((Get-ADGroup "user-mfa-notenabled" -Properties member).member)
    switch ($Company) {
        "Skövde" {
            $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Skovde,OU=Top,DC=kommun,DC=skovde,DC=se" }
            $skMFA.count
        }
        "Tibro" {
            $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Tibro,OU=Top,DC=kommun,DC=skovde,DC=se" }
            $skMFA.count
        }
        "Hjo" {
            $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Hjo,OU=Top,DC=kommun,DC=skovde,DC=se" }
            $skMFA.count
        }
        "Karlsborg" {
            $skMFA = $mfa | ? { $_ -like "*OU=Personnel,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se" }
            $skMFA.count
        }
    }
}

function Get-NotMFAUsers {
    param(
        [Parameter(Mandatory = $false)]
        [string] $Company,
        [string] $Office,
        [string] $Department
    )
    $date = get-date -Format "yyyy-MM-dd"
    $NotMFA = ((Get-ADGroup "user-mfa-notenabled" -Properties member).member)
    if ($Company) {
        $NotMFAS = $Notmfa | % { get-aduser $_ -prop Office, Department, Company } | ? { ($_.Company -eq $Company) -and ($_.Userprincipalname -notlike "DEV-*") } | select UserPrincipalName
        Write-Host ($NotMFAS.count) har inte aktiverat MFA i $Company -ForegroundColor Yellow
        $NotMFAS | Export-Csv "C:\temp\$date-$Company-NotMFA.csv" -NoTypeInformation
    }
    elseif ($Department) {
        $NotMFAS = $Notmfa | % { get-aduser $_ -prop Office, Department } | ? { ($_.Office -eq $Office) -and ($_.Department -eq $Department) -and ($_.Userprincipalname -notlike "DEV-*") } | select UserPrincipalName
        Write-Host ($NotMFAS.count) har inte aktiverat MFA i $Department -ForegroundColor Yellow
        $NotMFAS | Export-Csv "C:\temp\$date-$Department-NotMFA.csv" -NoTypeInformation
    }
    else {
        $NotMFAS = $Notmfa | % { get-aduser $_ -prop Office } | ? { ($_.Office -eq $Office) -and ($_.Userprincipalname -notlike "DEV-*") } | select UserPrincipalName
        Write-Host ($NotMFAS.count) har inte aktiverat MFA i $Office -ForegroundColor Yellow
        $NotMFAS | Export-Csv "C:\temp\$date-$office-NotMFA.csv" -NoTypeInformation
    }
}

function Get-MFAUsers {
    param(
        [Parameter(Mandatory = $false)]
        [string] $Company,
        [string] $Office,
        [string] $Department
    )
    $date = get-date -Format "yyyy-MM-dd"
    $MFA = ((Get-ADGroup "user-mfa-enabled" -Properties member).member)
    if ($Company) {
        $MFAS = $mfa | % { get-aduser $_ -prop Office, Department, Company } | ? { ($_.Company -eq $Company) -and ($_.Userprincipalname -notlike "DEV-*") } | select UserPrincipalName
        Write-Host ($MFAS.count) har aktiverat MFA i $Company -ForegroundColor Yellow
        $NotMFAS | Export-Csv "C:\temp\$date-$Company-NotMFA.csv" -NoTypeInformation
    }
    elseif ($Department) {
        $MFAS = $mfa | % { get-aduser $_ -prop Office, Department } | ? { ($_.Office -eq $Office) -and ($_.Department -eq $Department) -and ($_.Userprincipalname -notlike "DEV-*") } | select UserPrincipalName
        Write-Host ($MFAS.count) har aktiverat MFA i $Department -ForegroundColor Yellow
        $NotMFAS | Export-Csv "C:\temp\$date-$Department-NotMFA.csv" -NoTypeInformation
    }
    else {
        $MFAS = $mfa | % { get-aduser $_ -prop Office } | ? { ($_.Office -eq $Office) -and ($_.Userprincipalname -notlike "DEV-*") } | select UserPrincipalName
        Write-Host ($MFAS.count) har aktiverat MFA i $Office -ForegroundColor Yellow
        $MFAS | Export-Csv "C:\temp\$date-$office-NotMFA.csv" -NoTypeInformation
    }
}



$NotMFAS = $Notmfa | % { get-aduser $_ -prop Office, Department, Company } | ? { ($_.Company -like "*Karlsborg*") -and ($_.Userprincipalname -notlike "DEV-*") } | select UserPrincipalName
$NotMFAS | Export-Csv "C:\temp\$date-KBG-NotMFA.csv" -NoTypeInformation
######################################
$not = ((Get-ADGroup "user-mfa-notenabled" -Properties member).member)
$date = Get-date -Format yyyy-MM-dd
$not | % { get-aduser $_ -Properties Mail } | select  Mail | Export-Csv -Path C:\temp\$date-notMFA.csv -Append -Encoding UTF8 -NoTypeInformation
Get-Content C:\temp\$date-notMFA.csv | Where { $_.Replace(" ", "") -ne "" } | Out-File C:\temp\$date-notMFA01.csv


$Users = Get-ADGroupMember -Identity "Org-Karlsborg-Personnel" -Recursive | Where-Object { { $_.objectclass -eq "user" } -and { $_.Enabled -eq "true" } }
$KBG = Get-Aduser -filter * -SearchBase "OU=Personnel,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se" | Where-Object { $_.Enabled -eq "true" }
$KBGPol = Get-Aduser -filter * -SearchBase "OU=Politician,OU=Karlsborg,OU=Top,DC=kommun,DC=skovde,DC=se" | Where-Object { $_.Enabled -eq "true" }


###########################################
$date = get-date -Format "yyyy-MM-dd"
Start-Transcript -Path C:\Logs\$date-WinHello-MFA.log -Append
$users = Get-aduser -filter { (enabled -eq $true) -and (skusermimsource -like 'DB-Employees-MA' -or skUserMimSource -like 'Personec*') -and (UserPrincipalName -NotLike "DEV-*") }

# $users = Get-aduser -filter { (enabled -eq $true) -and (office -eq "SMS")}
$Users = Get-content -Path "C:\temp\SMS01.txt"

Import-module ActiveDirectory
Import-module Microsoft.Graph.Users
Import-module Microsoft.Graph.Identity.SignIns
$appid = 'f133d0fc-37a5-4140-ad70-e25469b4b41a'
$tenantid = '4c98088a-8771-4b89-86fa-342cf75f4e28'
$secret = '2-O8Q~xQOyZf~SqGoR8rh12NzDMhsFudWBk-2a9O'
 
$body = @{
    Grant_Type    = "client_credentials"
    Scope         = "https://graph.microsoft.com/.default"
    Client_Id     = $appid
    Client_Secret = $secret
}
 
$connection = Invoke-RestMethod `
    -Uri https://login.microsoftonline.com/$tenantid/oauth2/v2.0/token `
    -Method POST `
    -Body $body
 
$token = $connection.access_token
Connect-MgGraph -AccessToken $token

foreach ($U in $users) {
    # $UPN = $U.UserPrincipalName
    $UPN = $U
    $user = Get-mguser -UserId $UPN -ErrorAction SilentlyContinue
    if (!$user) {
        Write-Host -ForegroundColor Yello "Could not find user $UPN in AAD"
    }
    else {  
        $AuthInfo = [System.Collections.ArrayList]::new()
        $UserAuthMethod = $null
        $UserAuthMethod = Get-MgUserAuthenticationMethod -UserId $user.id -ErrorAction SilentlyContinue
        if (!$UserAuthMethod) {
            
            # Add-ADGroupMember -identity "User-MFA-notEnabled" -Members $U.SamAccountName
        }
        else {
            $object = [PSCustomObject]@{
                # DisplayName            = $user.Displayname
                userPrincipalName      = $user.userPrincipalName
                #UserType               = $user.UserType
                #AccountEnabled         = $user.AccountEnabled
                # id                     = $user.id
                #AuthMethods            = $UserAuthMethod
                #AuthMethodsCount       = ($UserAuthMethod).count
                #Phone                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.phoneAuthenticationMethod") { "Yes" } Else { "No" }
                MicrosoftAuthenticator = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod") { "Yes" } Else { "No" }
                #Email                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.emailAuthenticationMethod") { "Yes" } Else { "No" }
                HelloForBusiness       = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod") { "Yes" } Else { "No" }
                #fido2                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.fido2AuthenticationMethod") { "Yes" } Else { "No" }
                #Password               = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.passwordAuthenticationMethod") { "Yes" } Else { "No" }
                #passwordless           = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.passwordlessMicrosoftAuthenticatorAuthenticationMethod") { "Yes" } Else { "No" }
            }
            [void]$AuthInfo.Add($object)
            # if ($AuthInfo.MicrosoftAuthenticator -eq "Yes") {
            #     # $User = Get-Aduser -filter { Userprincipalname -eq $UPN }
            #     Write-Host -ForegroundColor Green "Adding $upn to User-MFA-Enabled"
            #     Add-ADGroupMember -identity "User-MFA-Enabled" -Members $U.SamAccountName
            #     Remove-ADGroupMember -identity "User-MFA-notEnabled" -Members $U.SamAccountName -Confirm:$false
            # }
            # elseif ($AuthInfo.MicrosoftAuthenticator -eq "No") {
            #     # $User = Get-Aduser -filter { Userprincipalname -eq $UPN }
            #     Write-Host -ForegroundColor Yello "Adding $upn to User-MFA-notEnabled"
            #     Add-ADGroupMember -identity "User-MFA-notEnabled" -Members $U.SamAccountName
            # }
            $AuthInfo | fl | Out-File c:\temp\SMS.txt -Append
        }
    }
}
Stop-Transcript

# Get MFA status for user
function Get-MFA {
    param(
        [Parameter(Mandatory = $false)]
        [string] $UPN,
        [string] $File
    )
    Import-module ActiveDirectory
    Import-module Microsoft.Graph.Users
    Import-module Microsoft.Graph.Identity.SignIns
    $appid = 'f133d0fc-37a5-4140-ad70-e25469b4b41a'
    $tenantid = '4c98088a-8771-4b89-86fa-342cf75f4e28'
    $secret = '2-O8Q~xQOyZf~SqGoR8rh12NzDMhsFudWBk-2a9O'
 
    $body = @{
        Grant_Type    = "client_credentials"
        Scope         = "https://graph.microsoft.com/.default"
        Client_Id     = $appid
        Client_Secret = $secret
    }
 
    $connection = Invoke-RestMethod `
        -Uri https://login.microsoftonline.com/$tenantid/oauth2/v2.0/token `
        -Method POST `
        -Body $body
 
    $token = $connection.access_token
    Connect-MgGraph -AccessToken $token
    function Get-MFAUser {
        param(
            [Parameter(Mandatory = $false)]
            [string] $UPN
        )
        $user = Get-mguser -UserId $UPN -ErrorAction SilentlyContinue
        if (!$user) {
            Write-Host -ForegroundColor Yellow "Could not find user $UPN in AAD"
        }
        else {  
            $AuthInfo = [System.Collections.ArrayList]::new()
            $UserAuthMethod = $null
            $UserAuthMethod = Get-MgUserAuthenticationMethod -UserId $user.id -ErrorAction SilentlyContinue
            if (!$UserAuthMethod) {
            }
            else {
                $object = [PSCustomObject]@{
                    # DisplayName            = $user.Displayname
                    userPrincipalName      = $user.userPrincipalName
                    #UserType               = $user.UserType
                    #AccountEnabled         = $user.AccountEnabled
                    # id                     = $user.id
                    # AuthMethods            = $UserAuthMethod
                    # AuthMethodsCount       = ($UserAuthMethod).count
                    #Phone                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.phoneAuthenticationMethod") { "Yes" } Else { "No" }
                    MicrosoftAuthenticator = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod") { "Yes" } Else { "No" }
                    #Email                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.emailAuthenticationMethod") { "Yes" } Else { "No" }
                    HelloForBusiness       = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod") { "Yes" } Else { "No" }
                    #fido2                  = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.fido2AuthenticationMethod") { "Yes" } Else { "No" }
                    #Password               = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.passwordAuthenticationMethod") { "Yes" } Else { "No" }
                    #passwordless           = If ($UserAuthMethod.additionalproperties.values -match "#microsoft.graph.passwordlessMicrosoftAuthenticatorAuthenticationMethod") { "Yes" } Else { "No" }
                }
                [void]$AuthInfo.Add($object)
                $AuthInfo
            }
        }
    }
    If ($file) {
        $users = Get-content -path $file
        foreach ($UPN in $users) {
            Get-MFAUser $UPN
        }
    }
    else {
        Get-MFAUser $UPN
    }
}