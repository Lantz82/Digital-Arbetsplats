((Get-ADGroup "user-mfa-notenabled" -Properties member).member).count
((Get-ADGroup "user-mfa-enabled" -Properties member).member).count

Get-ADgroupmember "user-mfa-notenabled"

$WH = ((Get-ADGroup "User-WindowsHello" -Properties member).member)

$users | %(Get-aduser $_)

$users | 
foreach ($u in $users){
    get-aduser -filter {DistinguishedName -eq $u} | select -ExpandProperty userprincipalname | Out-File c:\temp\sms02.txt -Append
    
}


$Group = "User-SM-SO-Karlsborg"
Get-adgroup $group -Properties members
Get-ADgroupmember $Group | %{get-aduser $_ -Properties * } | select displayname, mail, office | Export-Csv -Path C:\temp\kbg.csv -Encoding UTF8 -Append