﻿# Start-AzureSync.ps1
# Copyright (c) 2020, Skövde kommun
# All Rights Reserved
#
# 2020-07-09 Fredrik Lindberg Initial coding
#
param([switch] $Wait);

if ($wait) {
    Invoke-Command -ComputerName "SRv-DIRSYNC01" -ScriptBlock {
        While ((Get-ADSYncScheduler).SyncCycleInProgress) { Write-Host 'Sync already in progress...Waiting 1 min'; Sleep -Seconds 60; }; 
        Write-Host "Starting Sync Cycle";
        Start-ADSyncSyncCycle | Out-Null;
        Sleep -Seconds 10;
        While ((Get-ADSYncScheduler).SyncCycleInProgress) { Write-Host 'Waiting for Sync Cycle to complete. Sleeping 1 min'; Sleep -Seconds 60; };         
    }
}
else {
    Invoke-Command -ComputerName "SRv-DIRSYNC01" -ScriptBlock {
        While ((Get-ADSYncScheduler).SyncCycleInProgress) { Write-Host 'Sync already in progress...Waiting 1 min'; Sleep -Seconds 60; }; 
        Write-Host "Starting Sync Cycle";
        Start-ADSyncSyncCycle | Out-Null;
    }
}
