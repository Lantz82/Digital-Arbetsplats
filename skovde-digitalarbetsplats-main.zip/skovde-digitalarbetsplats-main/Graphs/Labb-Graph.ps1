$apiUrl = 'https://graph.microsoft.com/v1.0/Groups/'
$Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($Tokenresponse.access_token)"} -Uri $apiUrl -Method Get
$Groups = ($Data | select-object Value).Value
$Groups | Format-Table DisplayName, Description -AutoSize


$apiUrl = "https://graph.microsoft.com/beta/groups?`$filter=resourceProvisioningOptions/Any(x:x eq 'Team')"
$Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($Tokenresponse.access_token)"} -Uri $apiUrl -Method Get
$Teams = ($Data | select-object Value).Value | Select-Object displayName, id, description

$apiUrl = "https://graph.microsoft.com/beta/teams/4c5d60e1-fb98-4e7a-b23a-4f5d068f9221/channels"
$Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($Tokenresponse.access_token)"} -Uri $apiUrl -Method Get
$TeamChannels = ($Data | select-object Value).Value

$apiUrl = "https://graph.microsoft.com/beta/teams/4c5d60e1-fb98-4e7a-b23a-4f5d068f9221/channels/19:1140a423dabc4bd78f8edbb52141d59d@thread.skype/messages"
$body = @"
{ 
"body": { 
"content": "Hello team! This is being sent to you from PowerShell!" 
} 
}
"@
Invoke-RestMethod -Headers @{Authorization = "Bearer $($Tokenresponse.access_token)"} -Uri $apiUrl -Body $Body -Method Post -ContentType 'application/json'