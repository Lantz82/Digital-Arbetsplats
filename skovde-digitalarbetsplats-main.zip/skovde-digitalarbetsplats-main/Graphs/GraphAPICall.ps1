# Graph API call in PowerShell using obtained OAuth token (see other gists for more details)
$scope = "User.Read.All Group.Read.All Group.ReadWrite.All"
Connect-PnPonline -scopes $scope
$accessToken = Get-PnPAccessToken

# Specify the URI to call and method
$user = "adni0510@kommun.skovde.se"
$groupid = "37040921-377b-401a-921d-e49acfa724b3"
$uri = "https://graph.microsoft.com/beta/teams/$groupid/channels"
$method = "GET"
$uri = "https://graph.microsoft.com/beta/users/adni0510@kommun.skovde.se/photo/$value"

# Run Graph API query 
$query = Invoke-WebRequest -Method $method -Uri $uri -ContentType "application/json" -Headers @{Authorization = "Bearer $accessToken"} -ErrorAction Stop

($query.Content | ConvertFrom-Json)
$query.Content