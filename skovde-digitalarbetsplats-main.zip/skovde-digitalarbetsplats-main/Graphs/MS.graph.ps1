Connect-PnPonline -scopes "Group.ReadWrite.All"
$accessToken = Get-PnPAccessToken

$headers = @{
	"content-Type" = "application/json"
	Authorization = "Bearer $accessToken"
}

# Create Office365 group
$createGroupRequest = @{
  description = "Adam-test0101"
  displayName = "Adam-test0101"
  groupTypes = @("Unified")
  mailEnabled = $true
  mailNickname = "Adam-test0101"
  securityEnabled = $false
}
$CreateGroupBody = ConvertTo-Json -InputObject $createGroupRequest

$response = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/groups" -Body $CreateGroupBody -Method Post -Headers $headers 
$groupID = $response.id

# Create the Team
$createTeamRequest = @{
    memberSettings = @{
        allowCreateUpdateChannels = $true
    }
    MessagingSettings = @{
        allowUserEditMessages = $true
        allowUserDeleteMessages = $true
    }
    funSettings = @{
        allowGiphy = $true
        giphyContentRating = "strict"
    }
}
$createTeamBody = ConvertTo-Json -InputObject $createTeamRequest

$response = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/groups/$groupID/team" -Body $createTeamBody -Method Put -Headers $headers -UseBasicParsing 
Write-Host $response

# Get User
$User = "adni0510@kommun.skovde.se"
$query = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/users/$user" -ContentType "application/json" -Method Get -Headers $headers 


