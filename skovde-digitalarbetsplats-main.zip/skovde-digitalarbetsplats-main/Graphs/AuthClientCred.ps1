# Application (client) ID, tenant Name and secret
$clientId = "2333fb0d-8ad3-4fba-9f69-f144a1e5188c"
$tenantName = "samarbete.onmicrosoft.com"
$clientSecret = "0p_g6@-22-d70:45_cKu3:3V-G@+_BEi"
$resource = "https://graph.microsoft.com/"

$ReqTokenBody = @{
    Grant_Type    = "client_credentials"
    Scope         = "https://graph.microsoft.com/.default"
    client_Id     = $clientID
    Client_Secret = $clientSecret
}

$TokenResponse = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$TenantName/oauth2/v2.0/token" -Method POST -Body $ReqTokenBody