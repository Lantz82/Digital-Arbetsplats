# Get-Office365Status.ps1
# Get current service status of an Office 365 tenant

# Objects
$tenantId = "4c98088a-8771-4b89-86fa-342cf75f4e28"
$client_id = "2333fb0d-8ad3-4fba-9f69-f144a1e5188c"
$client_secret = '0p_g6@-22-d70:45_cKu3:3V-G@+_BEi'

# Construct URI for OAuth Token
$uri = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token"

# Construct Body for OAuth Token
$body = @{
    client_id     = $client_id
    scope         = "https://manage.office.com/.default"
    client_secret = $client_secret
    grant_type    = "client_credentials"
}

# Get OAuth 2.0 Token
$tokenRequest = try {

    Invoke-RestMethod -Method Post -Uri $uri -ContentType "application/x-www-form-urlencoded" -Body $body -ErrorAction Stop

}
catch [System.Net.WebException] {

    Write-Warning "Exception was caught: $($_.Exception.Message)"
    
}

$token = $tokenRequest.access_token

# Get Office 365 Status
$o365status = try {

    Invoke-RestMethod -Method Get -Uri "https://manage.office.com/api/v1.0/$tenantid/ServiceComms/CurrentStatus" -ContentType "application/json" -Headers @{Authorization = "Bearer $token"} -ErrorAction Stop

}
catch [System.Net.WebException] {

    Write-Warning "Exception was caught: $($_.Exception.Message)"
    
} 

# List service overview status
$o365status.Value | Format-Table WorkloadDisplayName, StatusDisplayName, StatusTime

# List service status for each feature
$o365status.Value | ForEach-Object {

    $_.FeatureStatus | Select-Object FeatureDisplayName, FeatureServiceStatusDisplayName

}