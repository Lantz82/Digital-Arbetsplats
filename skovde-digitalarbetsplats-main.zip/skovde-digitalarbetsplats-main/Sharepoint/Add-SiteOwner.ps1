#Config Variables
$Cred = Get-StoredCredential -Target "BitTitanKBG"
$Teams = Get-content -path C:\temp\KBGMIG\KBG-EDU-rest01.txt
#Parameters
$AdminCenterURL ="https://karlsborgskommun-admin.sharepoint.com"
$SiteOwner = "bittitan@Karlsborgskommun.onmicrosoft.com"
Connect-SPOService -Url $AdminCenterURL -Credential $cred
foreach ($Team in $Teams) {
    $SiteURL = $Team
    Set-SPOUser -Site $SiteURL -LoginName $SiteOwner -IsSiteCollectionAdmin $true
    Write-Host -ForegroundColor Yellow "$Team"
}
