# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)

# $computer = "srv-spse-app02.kommun.skovde.se"
# $session = New-PSSession -Credential $creds -ComputerName $computer

# $Name = "SBU Introduktion2"
# $Owner = "ellu1125"

Import-Module ActiveDirectory
function RemoveSpecialCharacters ([string] $string) {
    $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
    $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
    $string = $string -replace "[àáåäâã]", "a"
    $string = $string -replace "[óòôöõ]", "o"
    $string = $string -replace "[éèëê]", "e"
    $string = $string -replace "[üûúù]", "u"
    $string = $string -replace "[íìîï]", "i"
    $string = $string -replace "ñ", "n"
    $string
}

$LogDate = Get-Date -format yyyy-MM-dd
$LogFile = "C:\Logs\NewSPSite\$LogDate-NewSPSite.log"
function WriteLog {
    Param ([string]$LogString)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $LogMessage = "$Stamp $LogString"
    Add-content $LogFile -value $LogMessage
}
$User = Get-Aduser -Identity $Owner -Properties Office, Company, SamAccountName
$SamAccountName = $User.SamAccountName
$Office = $User.Office
switch ($User.Company) {
    "Skövde" {
        $Company = "SK"
        $Bolag = $false
    }
    "Tibro Kommun" {
        $Company = "TI"
        $Bolag = $false
    }
    "Hjo Kommun" {
        $Company = "HJ"
        $Bolag = $false
    }
    "Karlsborgs Kommun" {
        $Company = "KBG"
        $Bolag = $false
    }
    "Karlsborg Kommun" {
        $Company = "KBG"
        $Bolag = $false
    }
    "Skövde Energi" {
        $Company = "SEAB"
        $Bolag = $true
    }
    "Räddningstjänsten Östra Skaraborg" {
        $Company = "RS"
        $Bolag = $true
    }
    "Avfall & Återvinning Skaraborg" {
        $Company = "AAS"
        $Bolag = $true
    }
    "Balthazar" {
        $Company = "BALT"
        $Bolag = $true
    }
    "Skaraborgs Kommunalförbund" {
        $Company = "KOMF"
        $Bolag = $true
    }
    "Miljösamverkan Östra Skaraborg" {
        $Company = "MOS"
        $Bolag = $true
    }
}

# Fix Office prefix
switch ($Office) {
    "Kommunledningsförvaltningen" {
        $Office = "KLF"
    }
    "Socialförvaltningen" {
        $Office = "SOF"
    }
} 

$NameNOSpace = $Name.replace(' ', '')
$CleanName = RemoveSpecialCharacters($NameNOSpace)

if ($Bolag -eq $true) {
    $siteUrl = "https://mysites.skovde.se/sites/$Company-$CleanName"
}
if ($Bolag -eq $false) {
    $siteUrl = "https://mysites.skovde.se/sites/$Company-$Office-$CleanName"
}

Invoke-Command -ComputerName "srv-spse-app02.kommun.skovde.se" -Credential $creds -Authentication Credssp -ScriptBlock {
    Add-PSSnapin Microsoft.SharePoint.PowerShell
    New-SPSite -Url $args[0] -Template "STS#3" -Name $args[1] -Language "1053" -OwnerAlias $args[2] -QuotaTemplate "standard"
} -ArgumentList ($siteUrl, $Name, $SamAccountName)

WriteLog "New site name:$Name created at url:$siteUrl by user:$SamAccountName" 