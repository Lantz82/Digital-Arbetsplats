# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)

$Name = "\`d.T.~Ed/{E2E5BA1F-D719-49AD-BFF9-E79F66ED148A}.{49F55569-DCEB-44E8-87FF-F28D4831EF73}\`d.T.~Ed/"
$Owner = "\`d.T.~Ed/{E2E5BA1F-D719-49AD-BFF9-E79F66ED148A}.{F97B027F-550B-4E39-8F8C-A1ED9FD4DDFD}\`d.T.~Ed/"
$SR = "\`d.T.~Ed/{A2D36455-4CFB-4EA5-B761-B02E52A1CB74}.Id\`d.T.~Ed/"

Import-Module ActiveDirectory
function RemoveSpecialCharacters ([string] $string) {
    $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
    $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
    $string = $string -replace "[àáåäâã]", "a"
    $string = $string -replace "[óòôöõ]", "o"
    $string = $string -replace "[éèëê]", "e"
    $string = $string -replace "[üûúù]", "u"
    $string = $string -replace "[íìîï]", "i"
    $string = $string -replace "ñ", "n"
    $string
}

# Log function
$LogDate = Get-Date -format yyyy-MM-dd
$LogFile = "C:\Logs\NewSPSite\$LogDate-NewSPSite.log"
function WriteLog {
    Param ([string]$LogString)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $LogMessage = "$Stamp $LogString"
    Add-content $LogFile -value $LogMessage
}

# Get User
$User = Get-Aduser -Identity $Owner -Properties Office, Company, SamAccountName
$SamAccountName = $User.SamAccountName
$Office = $User.Office

# Fix company
switch ($User.Company) {
    "Skövde" {
        $Company = "SK"
        $Bolag = $false
    }
    "Tibro Kommun" {
        $Company = "TI"
        $Bolag = $false
    }
    "Hjo Kommun" {
        $Company = "HJ"
        $Bolag = $false
    }
    "Karlsborgs Kommun" {
        $Company = "KBG"
        $Bolag = $false
    }
    "Karlsborg Kommun" {
        $Company = "KBG"
        $Bolag = $false
    }
    "Skövde Energi" {
        $Company = "SEAB"
        $Bolag = $true
    }
    "Räddningstjänsten Östra Skaraborg" {
        $Company = "RS"
        $Bolag = $true
    }
    "Avfall & Återvinning Skaraborg" {
        $Company = "AAS"
        $Bolag = $true
    }
    "Balthazar" {
        $Company = "BALT"
        $Bolag = $true
    }
    "Skaraborgs Kommunalförbund" {
        $Company = "KOMF"
        $Bolag = $true
    }
    "Miljösamverkan Östra Skaraborg" {
        $Company = "MOS"
        $Bolag = $true
    }
}

# Fix Office prefix
switch ($Office) {
    "Kommunledningsförvaltningen" {
        $Office = "KLF"
    }
    "Socialförvaltningen" {
        $Office = "SOF"
    }
} 

# Fix Url
$NameNOSpace = $Name.replace(' ', '')
$CleanName = RemoveSpecialCharacters($NameNOSpace)

if ($Bolag -eq $true) {
    $siteUrl = "https://mysites.skovde.se/sites/$Company-$CleanName"
}
if ($Bolag -eq $false) {
    $siteUrl = "https://mysites.skovde.se/sites/$Company-$Office-$CleanName"
}

$ErrorMessage = $null
$status = $null
# Run on Sharepoint server
$return = Invoke-Command -ComputerName "srv-spse-app02.kommun.skovde.se" -Credential $creds -Authentication Credssp -ScriptBlock {
    param($siteUrl, $Name, $SamAccountName)
    try {      
        Add-PSSnapin Microsoft.SharePoint.PowerShell
        New-SPSite -Url $siteUrl -Template "STS#3" -Name $Name -Language "1053" -OwnerAlias $SamAccountName -QuotaTemplate "standard" -ErrorAction Stop | Out-Null
        $Status = "Success"
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        $Status = "Failed"
    }
    finally {
        $return = @($Status, $ErrorMessage)
        $return
    }
} -ArgumentList ($siteUrl, $Name, $SamAccountName)

$Status = $return.Get(0)
$ErrorMessage = $return.Get(1)

# Write-Host "Status: $Status"
# Write-Host "Error Message: $ErrorMessage"

# Write log file
if ($status -eq "Failed") {
    WriteLog "$SR FAILED: New site name: $Name created at url: $siteUrl by user: $SamAccountName ErrorMessage: $ErrorMessage"
    $Status = "Failed"
} else {
    WriteLog "$SR SUCCESS: New site name: $Name created at url: $siteUrl by user: $SamAccountName"
    $Status = "Success"
}