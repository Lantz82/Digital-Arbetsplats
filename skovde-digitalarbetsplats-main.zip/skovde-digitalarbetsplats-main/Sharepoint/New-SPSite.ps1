

# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$encrypted = Get-Content "C:\Credentials\SRVC-ORCH-Service01.txt" | ConvertTo-SecureString
$creds = New-Object System.Management.Automation.PsCredential($serviceAccount, $encrypted)
$computer = "srv-spse-app02.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$return = Invoke-Command -Session $session -ScriptBlock {
    $Name = "SBU Introduktion"
    $Owner = "ellu1125"
    Import-Module ActiveDirectory

    function RemoveSpecialCharacters ([string] $string) {
        $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $string = $string -replace "[àáåäâã]", "a"
        $string = $string -replace "[óòôöõ]", "o"
        $string = $string -replace "[éèëê]", "e"
        $string = $string -replace "[üûúù]", "u"
        $string = $string -replace "[íìîï]", "i"
        $string = $string -replace "ñ", "n"
        $string
    }

    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewSPSite\$LogDate-NewSPSite.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }

    function New-SPSESite {
        # Add-PSSnapin Microsoft.SharePoint.PowerShell
        $template = "STS#3" #Gruppwebbplats
        $Language = "1053" #sv-se

        $User = Get-Aduser -Identity $Owner -Properties Office, Company, SamAccountName
        $SamAccountName = $User.SamAccountName
        $Office = $User.Office
        # Get company prefix
        switch ($User.Company) {
            "Skövde" {
                $Company = "SK"
                $Bolag = $false
            }
            "Tibro Kommun" {
                $Company = "TI"
                $Bolag = $false
            }
            "Hjo Kommun" {
                $Company = "HJ"
                $Bolag = $false
            }
            "Karlsborgs Kommun" {
                $Company = "KBG"
                $Bolag = $false
            }
            "Karlsborg Kommun" {
                $Company = "KBG"
                $Bolag = $false
            }
            "Skövde Energi" {
                $Company = "SEAB"
                $Bolag = $true
            }
            "Räddningstjänsten Östra Skaraborg" {
                $Company = "RS"
                $Bolag = $true
            }
            "Avfall & Återvinning Skaraborg" {
                $Company = "AAS"
                $Bolag = $true
            }
            "Balthazar" {
                $Company = "BALT"
                $Bolag = $true
            }
            "Skaraborgs Kommunalförbund" {
                $Company = "KOMF"
                $Bolag = $true
            }
            "Miljösamverkan Östra Skaraborg" {
                $Company = "MOS"
                $Bolag = $true
            }
        }

        # Fix Office prefix
        switch ($Office) {
            "Kommunledningsförvaltningen" {
                $Office = "KLF"
            }
            "Socialförvaltningen" {
                $Office = "SOF"
            }
        } 
        # Cleanup name
        $NameNOSpace = $Name.replace(' ', '')
        $CleanName = RemoveSpecialCharacters($NameNOSpace)

        if ($Bolag -eq $true) {
            $siteUrl = "https://mysites.skovde.se/sites/$Company-$CleanName"
        }
        else {
            $siteUrl = "https://mysites.skovde.se/sites/$Company-$Office-$CleanName"
        }
        # Create a new site using the New-SPSite cmdlet
        New-SPSite -Url $siteUrl -Template $template -Name $Name -Language $Language -OwnerAlias $SamAccountName -QuotaTemplate "standard"

        # Output a message to indicate that the site has been created
        WriteLog "New site name:$Name created at url:$siteUrl by user:$SamAccountName" 
        # Write-Host "New site name:$Name created at url:$siteUrl by user:$SamAccountName"
    }
    Return $Name
}
$Name = $Return



<# 
        [string]$Company = @{
            "Skövde"                            = "SK"
            "Tibro Kommun"                      = "TI"
            "Hjo Kommun"                        = "HJ"
            "Karlsborgs Kommun"                 = "KBG"
            "Karlsborg Kommun"                  = "KBG"
            "Skövde Energi"                     = "SEAB"
            "Räddningstjänsten Östra Skaraborg" = "RS"
            "Avfall & Återvinning Skaraborg"    = "AAS"
            "Balthazar"                         = "BALT"
            "Skaraborgs Kommunalförbund"        = "KOMF"
            "Miljösamverkan Östra Skaraborg"    = "MOS"
        }[$User.Company]

$User = Get-Aduser -identity $Owner -properties *
$Office = $User.Office
$SamAccountName = $User.Samaccountname

# Get company prefix
if ($User.Company -eq "Skövde") {
    $Company = "SK"
    $Bolag = $false
}
elseif ($User.Company -eq "Tibro Kommun") {
    $Company = "TI"
    $Bolag = $false
}
elseif ($User.Company -eq "Hjo Kommun") {
    $Company = "HJ"
    $Bolag = $false
}
elseif (($User.Company -eq "Karlsborgs Kommun") -or ($User.Company -eq "Karlsborg Kommun")) {
    $Company = "KBG"
    $Bolag = $false
}
elseif ($User.Company -eq "Skövde Energi") {
    $Company = "SEAB"
    $Bolag = $true
}
elseif ($User.Company -eq "Räddningstjänsten Östra Skaraborg") {
    $Company = "RS"
    $Bolag = $true
}
elseif ($User.Company -eq "Avfall & Återvinning Skaraborg") {
    $Company = "AAS"
    $Bolag = $true
}
elseif ($KUser.Company -eq "Balthazar") {
    $Company = "BALT"
    $Bolag = $true
}
elseif ($User.Company -eq "Skaraborgs Kommunalförbund") {
    $Company = "KOMF"
    $Bolag = $true
}
elseif ($User.Company -eq "Miljösamverkan Östra Skaraborg") {
    $Company = "MOS"
    $Bolag = $true
}

# Get Office prefix
If ($Office -eq "Kommunledningsförvaltningen") {
    $Office = "KLF"
}
If ($Office -eq "Socialförvaltningen") {
    $Office = "SOF"
}
#>