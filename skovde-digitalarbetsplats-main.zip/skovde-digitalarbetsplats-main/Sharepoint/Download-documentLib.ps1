Function Download-SPOFiles {
    [CmdletBinding()]
    param(
          [Parameter(Position=0,mandatory=$true)]
          [string]$localPath,
          [string]$url,
          [string]$File
    )
    $driveLtr = "Y"
    $LogDate = Get-Date -format yyyy/MM/dd
    $LogFile = "$localPath\$LogDate-Download-SPOFiles.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }
    # $Cred = Get-StoredCredential -Target "BitTitanKBG"
    $Cred = Get-Credential
    If ($File) {
        $Teams = Get-content -Path $File
        foreach ($URL in $Teams) {
            Write-Host -ForegroundColor Yellow "$URL"
            Writelog "Team $URL"
            Connect-PnPOnline -Url $url -Credentials $cred -CreateDrive -DriveName $driveLtr
            $siteItems =  (gci ($driveLtr + ':')) | ?{$_.GetType().Name -eq 'Folder'}
            New-Item -ItemType directory -path ($localPath + (Get-PSDrive $driveLtr).CurrentLocation) -force | Out-Null
            $siteItems | ForEach-Object { 
                Copy-Item ((Get-PSDrive $driveLtr).Name + ":\" + (Get-PSDrive $driveLtr).CurrentLocation + "\" + $_.Name) -Destination ($localPath + (Get-PSDrive $driveLtr).CurrentLocation) -recurse -container
                }
            Get-PSDrive $driveLtr | Remove-PSDrive
            }
    }
    else {
        Write-Host -ForegroundColor Yellow "$URL"
        Writelog "Team $URL"
        Connect-PnPOnline -Url $url -Credentials $cred -CreateDrive -DriveName $driveLtr
        $siteItems =  (gci ($driveLtr + ':')) | ?{$_.GetType().Name -eq 'Folder'}
        New-Item -ItemType directory -path ($localPath + (Get-PSDrive $driveLtr).CurrentLocation) -force | Out-Null
        $siteItems | ForEach-Object { 
            Copy-Item ((Get-PSDrive $driveLtr).Name + ":\" + (Get-PSDrive $driveLtr).CurrentLocation + "\" + $_.Name) -Destination ($localPath + (Get-PSDrive $driveLtr).CurrentLocation) -recurse -container
            }
        Get-PSDrive $driveLtr | Remove-PSDrive
        }
}