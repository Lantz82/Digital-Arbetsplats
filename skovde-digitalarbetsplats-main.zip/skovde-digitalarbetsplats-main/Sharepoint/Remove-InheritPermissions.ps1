Connect-PnPOnline -Url https://samarbete.sharepoint.com/sites/Karlsborgkommun
#Get all list items in batches
$ListName = "Information och kommunikation"
$ListItems = Get-PnPListItem -List $ListName -PageSize 500
#Iterate through each list item
ForEach ($ListItem in $ListItems) {
    #Check if the Item has unique permissions
    $HasUniquePermissions = Get-PnPProperty -ClientObject $ListItem -Property "HasUniqueRoleAssignments"
    If ($HasUniquePermissions) {       
        # Write-Host "Setting Inherit on $listItem.ID"
        Set-PnPListItemPermission -List $ListName -Identity $ListItem.ID -InheritPermissions

    }
}