# About the folder

Folder is used a staging area for code snippets and functions still under development, before push to master branch it will be deleted so nothing important should be stored under this folder.