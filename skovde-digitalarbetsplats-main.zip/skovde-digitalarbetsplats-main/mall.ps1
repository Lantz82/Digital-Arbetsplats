<#
.SYNOPSIS
  Install script for deployment 
.DESCRIPTION
  This script starts the install of Intel Wireless drivers and writes a log file.
.NOTES
  Version:        1.0
  Author:         Philip Håkans
  Creation Date:  2019-11-11
  Purpose/Change: Initial script development

  ChangeLog:
  2019-11-11:     Initial script development.

  
.EXAMPLE
  N/A
#>

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$pathOnLocalComputer = "C:\Temp\testFolder"
$pathToInstallMedia = "\\kommun.skovde.se\configmgr\Content\application\hw\sp96200_7265_8265"
$logFile = "C:\Temp\testFolder\Logs\$(gc env:computername).log"
$registryPath = "HKLM:\Software\IntelWireless"
$name = "Driver"
$value = "Installed 21.10.0.5"
$date = Get-Date

#------------------------------------------------------------[Functions]-----------------------------------------------------------

Function Write-Log ($logstring)
{
    <#
    .SYNOPSIS
        Adds content (string) to a logfile
    .DESCRIPTION
        Writes error messages or whatever string to a logfile
    #>
    New-Item -ItemType File -Path $logFile -Force
    Add-Content $logFile -Value $date, $logstring
}

#------------------------------------------------------------[Script]--------------------------------------------------------------

try { 
    if(!($pathOnLocalComputer | Test-Path -ErrorAction Stop)) { 
        New-Item -ItemType Directory -Path $pathOnLocalComputer -Force -ErrorAction Stop
    } else {
        Write-Log "$pathOnLocalComputer already exists."
    }
} catch {
    Write-Log "Could not create " + $pathOnLocalComputer
}

try { 
    Set-Location $pathOnLocalComputer;
    Copy-Item -Path $pathToInstallMedia -Recurse -ErrorAction Stop
    #Get-ChildItem -Recurse -Filter *.inf | ForEach-Object { pnputil.exe /add-driver *.inf /subdirs /install }
    Write-Log "Files successfully copied."
    
    try {
        if (!(Test-Path $registryPath -ErrorAction Stop)) {
            New-Item -Path $registryPath -Force -ErrorAction Stop | Out-Null 
        }
    } catch {
        Write-Log $_.Exception.Message
    }
}
catch {
    Write-Log $_.Exception.Message | Format-List -Force
    Write-Host "Log written."
}
