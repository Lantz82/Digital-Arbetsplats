#Patch rapport efter månadspatchar. Hämtar servrar som har status Unknown eller Error och postar detta i Sysapp-teamet via Webhook.
#StatusType: 1 Success, 2 InProgress, 3 RequirementsNotMet, 4 Unknown, 5 Error
$ReportDay = Get-content "C:\Logs\ServerPatch\ReportDay.txt"
$Today = Get-Date -Format "yyyy-MM-dd"

if ($Today -eq $ReportDay) {

    $StatusError = Get-WmiObject -ComputerName srv-sc-cm02 -Namespace root\sms\site_P02 -Query "select SYS.ResourceID,SYS.ResourceType,SYS.Name,SYS.SMSUniqueIdentifier,SYS.ResourceDomainORWorkgroup,SYS.Client from sms_r_system as sys inner join SMS_SUMDeploymentAssetDetails as offer on sys.ResourceID=offer.ResourceID WHERE AssignmentID = '16782344' AND StatusType = 5"
    $StatusCompliant = Get-WmiObject -ComputerName srv-sc-cm02 -Namespace root\sms\site_P02 -Query "select SYS.ResourceID,SYS.ResourceType,SYS.Name,SYS.SMSUniqueIdentifier,SYS.ResourceDomainORWorkgroup,SYS.Client from sms_r_system as sys inner join SMS_SUMDeploymentAssetDetails as offer on sys.ResourceID=offer.ResourceID WHERE AssignmentID = '16782344' AND StatusType = 1"
    $date = Get-Date -Format "yyy-MM-dd" 
    $ServerError = $StatusError.Name -join "; <br/>"

    $JSONBody = [PSCustomObject][Ordered]@{
        "@type"      = "MessageCard"
        "@context"   = "http://schema.org/extensions"
        "summary"    = "$date Patchrapport"
        "themeColor" = '0078D7'
        "title"      = "$date Patchrapport"
        "text"       = "✔ $($StatusCompliant.Count) servrar har status compliant<br/>
        ❌ $($StatusError.Count) servrar har status failed och behöver kontrolleras av teknikansvarig. Se lista nedan <br/><br/> $ServerError"
    }
    $TeamMessageBody = ConvertTo-Json $JSONBody -Depth 8
    
    $parameters = @{
        # Sysapp
        "URI"         = 'https://samarbete.webhook.office.com/webhookb2/f5f19574-bec5-405d-a7b3-93ef01268926@4c98088a-8771-4b89-86fa-342cf75f4e28/IncomingWebhook/aff8cc50c6be48a8a0c4c2dacccfc4ae/b37f5887-c533-4355-8d64-39d7e0258567'
        # Adams-portal
        # "URI"         = 'https://samarbete.webhook.office.com/webhookb2/37040921-377b-401a-921d-e49acfa724b3@4c98088a-8771-4b89-86fa-342cf75f4e28/IncomingWebhook/2175ac10e10746b7b0feae3cce9fbe29/b37f5887-c533-4355-8d64-39d7e0258567'
        "Method"      = 'POST'
        "Body"        = $TeamMessageBody
        "ContentType" = 'application/json;charset=UTF-8'
    }
    Invoke-RestMethod @parameters
	
	    $parameters = @{
        # Kundstöd
        "URI"         = 'https://samarbete.webhook.office.com/webhookb2/943d1d4e-4457-445a-8cd0-7f6ea71cb0e4@4c98088a-8771-4b89-86fa-342cf75f4e28/IncomingWebhook/589614bb1bda4a8da81c216512fe2670/b37f5887-c533-4355-8d64-39d7e0258567'
        "Method"      = 'POST'
        "Body"        = $TeamMessageBody
        "ContentType" = 'application/json;charset=UTF-8'
    }
    Invoke-RestMethod @parameters
}
else {
    Exit
}