$Servers = Get-Content -Path 'C:\temp\hosts.txt'

foreach ($Server in $Servers){
    Get-Hotfix -ComputerName $Server | Where-Object {$_.InstalledOn -gt ((Get-Date).AddDays(-30))} | Select-Object -Property Source, Description, HotFixID, InstalledOn | Format-Table -AutoSize | Out-File -Encoding utf8 -FilePath 'C:\temp\Recent_Updates.txt' -Append -ErrorAction SilentlyContinue
}



Invoke-Command -ComputerName $Servers -ScriptBlock {
    Get-HotFix | Where-Object {$_.InstalledOn -gt ((Get-Date).AddDays(-30))} | Select-Object -Property PSComputerName, Description, HotFixID, InstalledOn
} | Format-Table -AutoSize | Out-File -Encoding utf8 -FilePath 'C:\temp\Recent_Updates.txt' -Append -ErrorAction SilentlyContinue