#Get device objects targeted by the deployment "Auto-Update-Group" (Assignment ID) and failed status
#StatusType: 1 Success, 2 InProgress, 3 RequirementsNotMet, 4 Unknown, 5 Error

$failedupdates = Get-WmiObject -ComputerName srv-sc-cm02 -Namespace root\sms\site_P02 -Query "select SYS.ResourceID,SYS.ResourceType,SYS.Name,SYS.SMSUniqueIdentifier,SYS.ResourceDomainORWorkgroup,SYS.Client from sms_r_system as sys inner join SMS_SUMDeploymentAssetDetails as offer on sys.ResourceID=offer.ResourceID WHERE AssignmentID = '16778397' AND StatusType = 5 OR AssignmentID = '16778397' AND StatusType = 4" 
$computers = $failedupdates.Name
$date = Get-Date

#invoke install updates available in software center for each device.

foreach ($computer in $computers) {
    "Computer: $computer Date: $date" | Out-File -FilePath C:\Temp\RB-Errorlog\Update.txt -Append -NoClobber
    $application = Get-WmiObject -Namespace "root\ccm\clientSDK" -Class CCM_SoftwareUpdate -ComputerName $computer
    Invoke-WmiMethod -Namespace "root\ccm\clientsdk" -Class CCM_SoftwareUpdatesManager -Name InstallUpdates -ArgumentList (,$application) -ComputerName $computer
}

"######################################" | Out-File -FilePath C:\Temp\RB-Errorlog\Update.txt -Append -NoClobber