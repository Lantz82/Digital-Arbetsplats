$bundles = Get-Content -Path "C:\temp\bundles.csv"
foreach ($bundle in $bundles) {
    Write-Host -ForegroundColor Yellow "Bundle: $bundle starting!"
    New-Item -Path "C:\Temp\ZenApps\" -Name "$bundle.bat" -Force
    New-Item -Path "\\KBG-ADM-01\ZenApps\$bundle\" -ItemType Directory 
    Add-Content "C:\Temp\ZenApps\$bundle.bat" -Value "zac cc"
    Add-Content "C:\Temp\ZenApps\$bundle.bat" -Value "zac ref"
    Add-Content "C:\Temp\ZenApps\$bundle.bat" -Value "zac cc"
    Add-Content "C:\Temp\ZenApps\$bundle.bat" -Value "zac bin `"$($bundle)`""
    Add-Content "C:\Temp\ZenApps\$bundle.bat" -Value "robocopy `"C:\Program Files (x86)\Novell\ZENworks\cache\zmd\ZenCache`" `"\\KBG-ADM-01\ZenApps\$($bundle)`" /R:2 /W:1 /E"
    Invoke-Item "C:\Temp\ZenApps\$bundle.bat"
    Wait-Process -Name "cmd"
    Write-Host -ForegroundColor Yellow "Bundle: $bundle done!"
}