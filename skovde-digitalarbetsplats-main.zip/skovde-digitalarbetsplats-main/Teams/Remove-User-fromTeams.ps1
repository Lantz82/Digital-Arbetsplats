$publicTeams2 = Get-Team -Visibility "public"

$kids = Get-content C:\temp\kids.txt

Foreach ($kid in $kids) {
    foreach ($team in $publicTeams) {
        Remove-TeamUser -GroupId $team.GroupId -User $kid
        Write-Output "$($kid) is removed from team $($team.DisplayName)"
    }
}

$publicTeams | Set-Team -Visibility "Private"

Get-UnifiedGroup -ResultSize Unlimited | Where-Object {$_.AccessType -eq "Public"} | Set-UnifiedGroup –AccessType Private