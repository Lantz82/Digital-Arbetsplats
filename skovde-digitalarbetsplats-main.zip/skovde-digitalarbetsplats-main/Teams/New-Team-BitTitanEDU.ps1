Import-Module MicrosoftTeams
Connect-MicrosoftTeams

$TeamName = "Sljd"
$TeamAlias = "TM-KBG-Sljd"

$Teams = Import-Csv -Path "C:\temp\KBGMIG\KBG-edu01.csv"
foreach ($Team in $Teams) {
    New-Team -MailNickName $Team.TeamAlias -displayname $Team.TeamName -Description $Team.TeamAlias -Template "EDU_Class" -Owner "bittitan@samarbete.onmicrosoft.com"
}

