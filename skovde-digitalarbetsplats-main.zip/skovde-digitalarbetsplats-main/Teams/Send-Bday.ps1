# Skickar till IT-avdelningen General kanalen om någon har födelsedag
$AllMembers = Get-adgroupmember -id "USER-Org-KOS-IT-avdelning" -Recursive | % { Get-aduser $_ -prop EmployeeID }
$AllMembersPNR = $AllMembers | Select -ExpandProperty EmployeeID
$Birthday = Get-Date -Format "MMdd"
$global:BirthdayChildren = @()

$BirthdayChildren = $null
foreach ($Pnr in $AllMembersPNR ) {
    if ($Pnr.SubString(4, 4) -eq $Birthday) {
        $Child = Get-ADUser -filter ("EmployeeID -eq $($Pnr)") -Property DisplayName
        $BirthdayChildren += " <b>$($Child.displayname) <b/><br/> "
    }
}
if ($BirthdayChildren) {
    $JSONBody = [PSCustomObject][Ordered]@{
        "@type"      = "MessageCard"
        "@context"   = "http://schema.org/extensions"
        "summary"    = "Grattis!"
        "themeColor" = '0078D7'
        "title"      = "Grattis! 🎈🎁"
        "text"       = "Idag säger vi grattis till $BirthdayChildren <br/> HURRA HURRA HURRA! 🎈🎂🎁"
    }
    $TeamMessageBody = ConvertTo-Json $JSONBody -Depth 8
        
    $parameters = @{
        "URI"         = 'https://samarbete.webhook.office.com/webhookb2/37040921-377b-401a-921d-e49acfa724b3@4c98088a-8771-4b89-86fa-342cf75f4e28/IncomingWebhook/b9e299ef174548f2ad8bba9b8845000d/b37f5887-c533-4355-8d64-39d7e0258567'
        "Method"      = 'POST'
        "Body"        = $TeamMessageBody
        "ContentType" = 'application/json;charset=UTF-8'
    }
    Invoke-RestMethod @parameters
}
else {
    Exit
}
