# Connect to Microsoft Teams
Connect-MicrosoftTeams

# Specify the display name of the team
$teamDisplayName = 'Karlsborg etableringsprojekt'

# Get information about the specified team
$team = Get-Team -DisplayName $teamDisplayName -ErrorAction SilentlyContinue

if ($team) {
    Write-Host "Team '$teamDisplayName' found:"
    Write-Host "Team Id: $($team.GroupId)"
    Write-Host "Archived: $($team.Archived)"
    Write-Host "Team Visibility: $($team.Visibility)"

    if ($team.Archived) {
        # If the team is archived, retrieve the timestamp
        $archiveTimestamp = Get-TeamArchivedState -GroupId $team.GroupId
        Write-Host "Archive Timestamp: $($archiveTimestamp.ArchiveDateTime)"
    }
} else {
    Write-Host "Team '$teamDisplayName' not found."
}

# Disconnect from Microsoft Teams
Disconnect-MicrosoftTeams
