Connect-MicrosoftTeams
$team = Get-Team -DisplayName "Västerhöjd - All personal"
$Path = "C:\temp\teams.txt"
get-content -Path $Path | foreach { Write-Host $_ }
get-content -Path $Path | foreach { Add-TeamUser -GroupId $team.GroupId -user $_ }


$teams = Import-Csv -Path C:\Temp\edu-teams2.CSV
foreach ($team in $teams) {
    Add-TeamUser -GroupId $team.TeamId -User "jorgen.lindberg@karlsborg.se"
    Add-TeamUser -GroupId $team.TeamId -User "jorgen.lindberg@karlsborg.se" -role Owner
}