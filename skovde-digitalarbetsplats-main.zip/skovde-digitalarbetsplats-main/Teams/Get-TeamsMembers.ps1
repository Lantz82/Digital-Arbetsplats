# $user = 'adam.nilsson@skovde.se'


Connect-MicrosoftTeams -TenantId "8efa1a61-9f4f-44b5-baf9-2f166d6e4f20"
$MailnickName = "itenheten"
$OldTeam = Get-Team -MailNickName $MailnickName
$OldUsers = Get-TeamUser -GroupId $Team.GroupId | select user,role
$OldUsers | Export-Csv -Path "C:\Temp\TM-KBG-$MailnickName.csv" -NoTypeInformation -Encoding UTF8 -Delimiter ","

Connect-MicrosoftTeams -TenantId "8efa1a61-9f4f-44b5-baf9-2f166d6e4f20" -Credential $KBGCreds


# ForEach-Object {get-mailbox $_.user}

Add-TeamUser -GroupId $team.GroupId -User $user -Role Owner
Get-TeamUser -GroupId $Team.GroupId | where {$_.User -eq "$user"}

#Parameters
$CSVFile = "C:\Temp\TeamKBGTest.csv"
 
Try {
    #Read the CSV File
    $TeamsData = Import-CSV -Path $CSVFile
 
    #Connect to Microsoft Teams
    Connect-MicrosoftTeams
 
    #Iterate through the CSV 
    ForEach($Team in $TeamsData)
    {
        Try {
            <#Create a New Team
            Write-host -f Yellow "Creating Team:" $Team.TeamName
            $NewTeam = New-Team -DisplayName $Team.TeamName -Owner $Team.Owner -Description $Team.Description -Visibility $Team.Visibility -ErrorAction Stop
            Write-host "`tNew Team '$($Team.TeamName)' Created Successfully" -f Green
            #>
            #Add Members to the Team
            $Team = Get-Team -MailNickName "itenheten"
            Write-Host "`tAdding Team members..." -f Yellow
            $Members = $TeamsData.TeamOwners.Split(";")
            ForEach($Member in $Members)
            {
                Add-TeamUser -User $Member -GroupId $Team.GroupID -Role Owner
                Write-host "`t`tAdded Team Member:'$($Member)'" -f Green
            }
        }
        Catch {
            Write-host -f Red "Error Creating Team:" $_.Exception.Message
        }
    }
}
Catch {
    Write-host -f Red "Error:" $_.Exception.Message
}