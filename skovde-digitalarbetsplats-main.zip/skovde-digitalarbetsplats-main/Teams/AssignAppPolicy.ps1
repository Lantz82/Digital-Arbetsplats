# Connect to Skype for Business Online
ConnectSfBO
ConnectTeams

$Policy = ""
$TeamGroup = Get-Team -DisplayName "Chattbot"
$TeamUsers = Get-TeamUser -GroupId $TeamGroup.GroupId -Role Member
$TeamUsers | ForEach-Object {Grant-CsTeamsAppPermissionPolicy -PolicyName $Policy -Identity $_.User}

Get-CsTeamsAppPermissionPolicy -Identity "MindMeister"
Get-CsTeamsAppPermissionPolicy

<#
# Add single user
$user = "cindy.petersson@skovde.se"
Get-CsOnlineUser -Filter {TeamsAppPermissionPolicy -eq "MindMeister"} | select UserPrincipalName
Get-CsOnlineUser -Identity $user | select TeamsAppPermissionPolicy
Grant-CsTeamsAppPermissionPolicy -PolicyName $Policy -Identity $user

# Connect to Azure AD and Skype Online PowerShell
Connect-AzureAD -Credential $Creds
$group = Get-AzureADGroup -SearchString "Contoso Operations"
$members = Get-AzureADGroupMember -ObjectId $group.ObjectId -All $true | Where-Object {$_.ObjectType -eq "User"}
$members | ForEach-Object {Grant-CsTeamsAppSetupPolicy -PolicyName "Operations" -Identity $_.EmailAddress}

# List the users with a policy
Get-CsOnlineUser -Filter {TeamsAppSetupPolicy -eq "Operations"} | select UserPrincipalName
#>
