Import-Module -Name MicrosoftTeams
# Check if allready connected to Teams
try { $null = Get-CsTenant } catch { Connect-MicrosoftTeams }

$HjoTeams = Get-Team | Where-Object { $_.MailNickName -like "TM-HJ*" -or $_.MailNickName -like "HJ*" }

$Report = $null
$Report = @()
foreach ($Team in $hjoTeams) {
    # $TeamUsers = Get-TeamUser -GroupId $Team.GroupId | select user,role
    $TeamOwner = Get-TeamUser -GroupId $Team.GroupId | Where-Object { $_.Role -eq "Owner" } | Select -ExpandProperty User | Out-string
    $TeamMember = Get-TeamUser -GroupId $Team.GroupId | Where-Object { $_.Role -eq "Member" } | Select -ExpandProperty User | Out-string
    $TeamInfo = [PSCustomObject]@{
        Team   = $Team.DisplayName
        Owner  = $TeamOwner
        Member = $TeamMember
    }
    $Report += $TeamInfo
}
$report | Export-Excel -Path C:\temp\HjoTeams.xlsx -AutoSize