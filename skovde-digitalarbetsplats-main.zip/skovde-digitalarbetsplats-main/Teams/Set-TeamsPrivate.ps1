Import-Module -name MicrosoftTeams
Import-Module -name Credentialmanager

$Creds = (Get-storedcredentials -Target 'srvc-teams')
Connect-MicrosoftTeams -Credential $Creds
$pubTeam = Get-Team -Visibility "Public" | Where-Object Visibility -eq 'Public'
$pubTeam | Select-Object GroupId, DisplayName, Visibility | Export-Csv -Path C:\Logs\Teams-public.csv -NoTypeInformation -Encoding UTF8 -Force
$pubTeam | Set-Team -Visibility "Private"