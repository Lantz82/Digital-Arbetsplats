# Set script parameters
[CmdletBinding()]
param (
    [int]$InactivityPeriod = 30,
    [switch]$ExportCSV,
    [string]$ExportFilePath = "$env:TEMP\$(Get-Date -Format "yyyy_MM_dd")InactiveTeams.csv"
)

# Check or install Microsoft Graph Reports module
if ($null -eq (Get-Module -ListAvailable Microsoft.Graph.Reports)) {
    try {
        Write-Output "Microsoft Graph Reports module not found. Trying to install"
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null
        Install-Module Microsoft.Graph.Reports -Force | Out-Null
        Write-Output "Microsoft Graph Reports module installed"
    }
    catch {
        Write-Output "Unable to install Microsoft Graph Reports module. $($Error[0].Exception.Message)"
        Return
    }
}

# Connect to M365
try {
    Write-Output "Connecting Microsoft Graph"
    Select-MgProfile -Name "beta"
    Connect-MgGraph -Scopes Reports.Read.All | Out-Null
}
catch {
    Write-Output "Unable to connect to M365. $($Error[0].Exception.Message)"
    Return
}

# Get activity report
try {
    Get-MgReportTeamActivityDetail -Period 'ALL' -OutFile "$env:Temp\teamsactivityreport.json"
}
catch {
    Write-Output "Unable to get activity report. $($Error[0].Exception.Message)"
    Return
}

# Read the report for filtering
$AllTeamActivity = (Get-Content -Raw "$env:Temp\teamsactivityreport.json" | ConvertFrom-Json).Value 

# Check each team and build a report 
$FinalReport = @()
foreach ($SingleTeamActivity in $AllTeamActivity) {
    if ($SingleTeamActivity.lastActivityDate) {
        $lastActivityDate = Get-Date -Date $SingleTeamActivity.lastActivityDate
        if ($lastActivityDate -le $((Get-Date).AddDays(-$InactivityPeriod))) {
            $TeamActivityObject = [PSCustomObject]@{
                TeamId           = $SingleTeamActivity.teamId
                TeamName         = $SingleTeamActivity.teamName
                LastActivityDate = $SingleTeamActivity.lastActivityDate
            }
            $FinalReport += $TeamActivityObject
        }
    }
    else {
        $TeamActivityObject = [PSCustomObject]@{
            TeamId           = $SingleTeamActivity.teamId
            TeamName         = $SingleTeamActivity.teamName
            LastActivityDate = "No activity found"
        }
        $FinalReport += $TeamActivityObject
    }
}

# Print result to the screen
Write-Output $FinalReport | Format-Table

# Export result to CSV file if needed
if ($ExportCSV) {
    $FinalReport | Export-Csv -Path $ExportFilePath -NoTypeInformation
    Write-Output "Report saved to $ExportFilePath"
}

# Stop before closing powershell window
Read-Host "Script completed. Press 'Enter' to finish"