param (
    [Parameter(Mandatory)]
    $UPN
)

Import-Module -Name MicrosoftTeams

# Check if allready connected to Teams
try { $null = Get-CsTenant } catch { Connect-MicrosoftTeams }

Write-Host -ForegroundColor Yellow "Fetching all Teams $UPN is a member of ..."
$Teams = Get-Team -User $UPN

$UserOwner = $Teams | ForEach-Object {
    $team = $_
    $owner = Get-TeamUser -GroupId $_.GroupId | Where-Object { $_.User -like $UPN -and $_.Role -eq "Owner" }
    if ($owner) {
        $team.Displayname + "`n"
    }
}

$AllTeams = $Teams.Displayname -join "`n"

Write-Host "All Teams $UPN is a member of: 
$AllTeams

All Teams $UPN is an owner: 
$UserOwner"
