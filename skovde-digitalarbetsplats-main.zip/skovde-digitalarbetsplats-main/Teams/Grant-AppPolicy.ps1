Import-Module CredentialManager
Import-Module SkypeOnlineConnector
$o365admin =  (Get-StoredCredential -Target tst-adni0510)

#Connect Exchange Online
$exchSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $o365admin -Authentication Basic -AllowRedirection
Import-PSSession $exchSession -DisableNameChecking -AllowClobber

# Connect SkypeOnline
$sfbSession = New-CsOnlineSession -Credential $o365admin
Import-PSSession $sfbSession

# Get Members & Assign Policy
$members = Get-UnifiedGroupLinks -Identity "SK-SSV-TM-TeamChampions@samarbete.onmicrosoft.com" -LinkType Members
$members | ForEach-Object {Grant-CsTeamsAppSetupPolicy -PolicyName "Team-champs" -Identity $_.name}
