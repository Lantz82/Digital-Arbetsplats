Write-host  -ForegroundColor Yellow "Closing Teams and clearing cache"
Stop-Process -Name Teams
Remove-Item -path "$env:APPDATA\Microsoft\Teams\Cache\*" -recurse
Remove-Item -path "$env:APPDATA\Microsoft\Teams\blob_storage\*" -recurse
Remove-Item -path "$env:APPDATA\Microsoft\Teams\databases\*" -recurse
Remove-Item -path "$env:APPDATA\Microsoft\Teams\GPUcache\*" -recurse
Remove-Item -path "$env:APPDATA\Microsoft\Teams\IndexedDB\*" -recurse
Remove-Item -path "$env:APPDATA\Microsoft\Teams\Local Storage\*" -recurse
Remove-Item -path "$env:APPDATA\Microsoft\Teams\tmp\*" -recurse
Write-host  -ForegroundColor Yellow "Done!"