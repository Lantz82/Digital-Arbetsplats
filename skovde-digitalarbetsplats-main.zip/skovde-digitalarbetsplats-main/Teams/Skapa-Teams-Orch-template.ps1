$secPasswordServiceAccount = ConvertTo-SecureString "" -AsPlainText -Force
#$secPasswordServiceAccount = Get-Content C:\Credentials\SRVC-ORCH-Service.txt | ConvertTo-SecureString
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$creds = New-Object System.Management.Automation.PSCredential($serviceAccount, $secPasswordServiceAccount) 
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer

$return = Invoke-Command -Session $session -ScriptBlock {
    
    function RemoveSpecialCharacters ([string] $string) {
        $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $string = $string -replace "[àáåäâã]", "a"
        $string = $string -replace "[óòôöõ]", "o"
        $string = $string -replace "[éèëê]", "e"
        $string = $string -replace "[üûúù]", "u"
        $string = $string -replace "[íìîï]", "i"
        $string = $string -replace "ñ", "n"
        $string
    }
    
    Import-Module MicrosoftTeams
    $ErrorActionPreference = "Stop"
    $Kommun = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{D71617FA-573F-4DE5-B792-39CCFBF99829}\`d.T.~Ed/"
    $Office = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.Office\`d.T.~Ed/"
    $UPNN = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.UPN\`d.T.~Ed/"
    $ErrorActionPreference = "Stop"
    $TeamsAdmin = "srvc-teams@samarbete.onmicrosoft.com"
    $TeamName = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{84CAF08C-D52B-4162-8169-AB3323ACBA48}\`d.T.~Ed/"
    $secPassword = ConvertTo-SecureString "e1JRlJRcGF@" -AsPlainText -Force
    $myTeamsCreds = New-Object System.Management.Automation.PSCredential ($TeamsAdmin, $secPassword)
    Connect-MicrosoftTeams -Credential $myTeamsCreds
    $EDU = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{21564C05-C2B2-4811-9BCA-9D81EE5BDF5C}\`d.T.~Ed/"
    $Date = Get-Date -Format FileDateTime

    if ($Kommun -eq "Tibro Kommun") {
        $KommunName = "TI" 
    }
    elseif ($Kommun -eq "Hjo Kommun") {
        $KommunName = "HJ"
    }
    else {
        $KommunName = "SK" 
    }
    $TeamFullName = 'TM-' + $KommunName + '-' + $Office + '-'  + $TeamName + $Date
    $TeamNOSpace = $TeamFullName.replace(' ', '')
    $TeamAlias = RemoveSpecialCharacters($TeamNOSpace)
    
    try {       
        if ($EDU -eq "TRUE") {
            $Team = New-Team -MailNickName "$TeamAlias" -displayname "$TeamName" -Description "$TeamName" -Template "EDU_Class" -Owner $UPNN
            Start-Sleep 30
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Member
            #Start-Sleep 10
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Owner
            $Status = "Success"
        }
        else {
            $Team = New-Team -MailNickName "$TeamAlias" -Displayname "$TeamName" -Visibility "Private" -Description "$TeamName" -Owner $UPNN
            Start-Sleep 30
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Member
            #Start-Sleep 10
            #Add-TeamUser -GroupId $Team.GroupId -User $UPNN -Role Owner
            $Status = "Success"
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        $Status = "Failed"
    }
    finally {
        $return = @($Status, $ErrorMessage, $Team)
        $return
    }

}
$Team = $return.Get(0)
$Status = $return.Get(1)
$ErrorMessage = $return.Get(2)