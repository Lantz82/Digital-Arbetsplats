$KBGEDUTeams = Get-Team -Visibility "Hiddenmembership" | ?{$_.Description -like "TM-KBG-*" }
$KBGEDUTeams.count

$KBGEDUTeams = Get-Team -Visibility "Hiddenmembership" | ?{$_.MailNickName -like "TM-KBG-*" }
$KBGEDUTeams.count
$KBGEDUTeams | ?{$_.DisplayName -like "Exp0823_*" } | select GroupId,DisplayName | Export-Csv C:\temp\_KBG05.csv -NoTypeInformation -Encoding UTF8

$HJEDUTeams = Get-Team -Visibility "Hiddenmembership" | ?{$_.Description -like "HJ-TM*" }
$HJEDUTeams.count
$HJEDUTeams | select GroupId,DisplayName | Export-Csv C:\temp\_HJ.csv -NoTypeInformation -Encoding UTF8
$CSV = Import-csv C:\temp\_HJ2.csv

$KBGEDUTeams | select GroupId,DisplayName | Export-Csv C:\temp\_KBG2.csv -NoTypeInformation -Encoding UTF8
$CSV = Import-csv C:\temp\_KBG06.csv

foreach ($team in $CSV) {
    Get-Team -groupid $team.GroupId | Set-Team -DisplayName $Team.DisplayName
    Write-Host Setting $Team.Displayname
}