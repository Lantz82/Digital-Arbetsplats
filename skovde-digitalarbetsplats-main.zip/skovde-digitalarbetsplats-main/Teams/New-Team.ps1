#requires -version 5.0
# Copyright (c) 2019, Skövde Kommun
# All rights reserved
#
# 2019-09-26 Adam Nilsson - Initial coding
param(
    [Parameter(Mandatory=$true)]
    [string] $Displayname,
    [Parameter(Mandatory=$true)]
    [string] $Kommun,
    [Parameter(Mandatory=$true)]
    [string] $Office,
    [Parameter(Mandatory=$true)]
    [string] $User
)

ConnectTeams
If ($Kommun -eq "Tibro"){
    $KommunName = "TI"
} 
ElseIf ($Kommun -eq "Hjo"){
    $KommunName = "HJ"
}
Else {
    $KommunName = "SK"
}
$TeamFullName = $KommunName+'-'+$Office+'-TM-'+$Displayname
$TeamNOSpace = $TeamFullName.replace(' ','')
$MailNickName = RemoveDiacritics $TeamNOSpace

Write-Host -ForegroundColor Yellow "Creating Team $MailNickName, please wait..."
$Team = New-Team -MailNickName $MailNickName -Displayname $Displayname -Visibility "private" -Description $MailNickName
Write-Host -ForegroundColor Yellow "Adding $user as owner, please wait..."
Start-Sleep 12
Add-TeamUser -GroupId $Team.GroupId -User $User -Role Owner
Start-Sleep 10
Remove-TeamUser -GroupId $Team.GroupId -User "adni0510-adm@samarbete.onmicrosoft.com"
Write-Host -ForegroundColor Green "New Team $MailNickName is now created!"