# Get stored creds
$serviceAccount = "SKOVDE\SRVC-ORCH-Service"
$secPasswordServiceAccount = ConvertTo-SecureString "" -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential($serviceAccount, $secPasswordServiceAccount)

# Runnin the script on mgmt20, more modules and newer PowerShell Version
$computer = "srv-mgmt20.kommun.skovde.se"
$session = New-PSSession -Credential $creds -ComputerName $computer
$return = Invoke-Command -Session $session -ScriptBlock {
    
    function RemoveSpecialCharacters ([string] $string) {
        $string = $string -replace "(?-i)[ÀÁÅÄÂÃ]", "A"
        $string = $string -replace "(?-i)[ÒÓÔÖÕ]", "O"
        $string = $string -replace "[àáåäâã]", "a"
        $string = $string -replace "[óòôöõ]", "o"
        $string = $string -replace "[éèëê]", "e"
        $string = $string -replace "[üûúù]", "u"
        $string = $string -replace "[íìîï]", "i"
        $string = $string -replace "ñ", "n"
        $string
    }
    $LogDate = Get-Date -format yyyy-MM-dd
    $LogFile = "C:\Logs\NewTeam\$LogDate-NewTeam.log"
    function WriteLog {
        Param ([string]$LogString)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $LogMessage = "$Stamp $LogString"
        Add-content $LogFile -value $LogMessage
    }
    Import-Module MicrosoftTeams
    $ErrorActionPreference = "Stop"
    $Kund = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{D71617FA-573F-4DE5-B792-39CCFBF99829}\`d.T.~Ed/"
    $Office = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.Office\`d.T.~Ed/"
    $UPNN = "\`d.T.~Ed/{99E3333D-9CFE-4338-95AD-1DB1E091FC26}.UPN\`d.T.~Ed/"
    $ErrorActionPreference = "Stop"
    $TeamName = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{84CAF08C-D52B-4162-8169-AB3323ACBA48}\`d.T.~Ed/"
    $TeamsAdmin = "srvc-teams@samarbete.onmicrosoft.com"
    $secPassword = ConvertTo-SecureString "" -AsPlainText -Force
    $myTeamsCreds = New-Object System.Management.Automation.PSCredential ($TeamsAdmin, $secPassword)
    Connect-MicrosoftTeams -Credential $myTeamsCreds
    $EDU = "\`d.T.~Ed/{9B8EED99-6BF9-4BD5-A3D1-8816692433D4}.{21564C05-C2B2-4811-9BCA-9D81EE5BDF5C}\`d.T.~Ed/"
    $Date = Get-Date -Format FileDate

    # Manual variables for testning
    # $TeamName = "TEST01"
    # $Kund = "Skövde Energi"
    # $Office = "SEAB"
    # $UPNN = "adam.nilsson@skovde.se"
    # $EDU = ""

    # TODO: Change to Switch instead
    if ($Kund -eq "Tibro Kommun") {
        $KundName = "TI" 
    }
    elseif ($Kund -eq "Hjo Kommun") {
        $KundName = "HJ"
    }
    elseif (($Kund -eq "Karlsborgs Kommun") -or ($Kund -eq "Karlsborg Kommun")) {
       $KundName = "KBG"
    }
    elseif ($Kund -eq "Skövde Energi") {
        $KundName = "SEAB"
        $Bolag = $true
    }
    elseif ($Kund -eq "Räddningstjänsten Östra Skaraborg") {
        $KundName = "RS"
        $Bolag = $true
    }
    elseif ($Kund -eq "Avfall & Återvinning Skaraborg") {
        $KundName = "AAS"
        $Bolag = $true
    }
    elseif ($Kund -eq "Balthazar") {
        $KundName = "BALT"
        $Bolag = $true
    }
    elseif ($Kund -eq "Skaraborgs Kommunalförbund") {
        $KundName = "KOMF"
        $Bolag = $true
    }
    elseif ($Kund -eq "Miljösamverkan Östra Skaraborg") {
        $KundName = "MOS"
        $Bolag = $true
    }
    else {
        $KundName = "SK" 
    }
    If ($Office -eq "Kommunledningsförvaltningen"){
        $Office = "KLF"
        }
    If ($Office -eq "Socialförvaltningen"){
        $Office = "SOF"
        }
    If ($Bolag) {
        $TeamFullName = 'TM-' + $KundName + '-' + $TeamName + $Date
        $TeamNOSpace = $TeamFullName.replace(' ', '')
        $TeamAlias = RemoveSpecialCharacters($TeamNOSpace)
    }
    else {
        $TeamFullName = 'TM-' + $KundName + '-' + $Office + '-' + $TeamName + $Date
        $TeamNOSpace = $TeamFullName.replace(' ', '')
        $TeamAlias = RemoveSpecialCharacters($TeamNOSpace)
    }

    try {       
        if ($EDU -eq "TRUE") {
            $Team = New-Team -MailNickName "$TeamAlias" -displayname "$TeamName" -Description "$TeamName" -Template "EDU_Class" -Owner $UPNN
            Start-Sleep 30
            $Status = "Success"
        }
        else {
            $Team = New-Team -MailNickName "$TeamAlias" -Displayname "$TeamName" -Visibility "Private" -Description "$TeamName" -Owner $UPNN
            Start-Sleep 30
            $Status = "Success"
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        $Status = "Failed"
    }
    finally {
        $return = @($Status, $ErrorMessage, $Team)
        $return
    }
    WriteLog "New Team $TeamAlias by $UPNN"
}
$Team = $return.Get(0)
$Status = $return.Get(1)
$ErrorMessage = $return.Get(2)