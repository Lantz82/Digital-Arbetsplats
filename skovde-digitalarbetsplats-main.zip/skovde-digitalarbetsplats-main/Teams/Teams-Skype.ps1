$password = get-content "C:\Script\cred.txt" | convertto-securestring
$UserCredential = new-object -typename System.Management.Automation.PSCredential -argumentlist "adni0510-adm@samarbete.onmicrosoft.com", $password

Import-Module -Name SkypeOnlineConnector
Import-Module -Name MicrosoftTeams
$socSession = New-CsOnlineSession -Credential $UserCredential
Import-PSSession $socSession -AllowClobber

$user = 'erik.gustavsson@skovde.se'
Grant-CsTeamsUpgradePolicy -PolicyName IslandsWithNotify -Identity $user

$objUsers = Get-CSOnlineUser | select UserPrincipalName, teamsupgrade*
$objusers | ConvertTo-Html | Out-File "$env:USERPROFILE\desktop\TeamsUpgrade.html"